<?php
    session_start();
    // delete question
    require 'connect_database.php';
    $ques_id=$_REQUEST['ques_id'];
    $user_id=$_SESSION['userID'];
    $select_pic="SELECT question_picture FROM question WHERE question_id='$ques_id'";
    $selecting_pic=mysqli_query($con,$select_pic);
    while($row=mysqli_fetch_array($selecting_pic)){
        $ques_pic=$row['question_picture'];
    }
    $delete_ques="DELETE FROM question WHERE question_id='$ques_id' AND user_id='$user_id'";
    $deleting_ques=mysqli_query($con,$delete_ques);
    if($deleting_ques){
        unlink('question_photo/'.$ques_pic);
        header('Location:../jom_coding/content_admin_question.php');
    }else{
        header('Location:../jom_coding/content_admin_question.php?error=deleteaccesserror');
    }