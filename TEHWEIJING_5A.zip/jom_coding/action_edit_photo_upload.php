<?php

require 'action_edit_question.php';
$target_dir = "question_photo/";
$target_file = $target_dir . basename($_FILES["question_photo_upload"]["name"]);
$file=basename($_FILES["question_photo_upload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$content=$_POST['content'];
$answer=$_POST['answer'];
$id=$_REQUEST['ques_id'];
$topic=$_POST['topic'];
$level=$_POST['level'];
if($_POST['type']=="OBJ"){
  $select=$_POST['select'];
}else{
  $select="-";
}
// check if image file is a actual image or fake image
if(isset($_POST["change"])) {
  $check = getimagesize($_FILES["question_photo_upload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
    header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=uploaderror');
  }
}

// check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
  header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=uploaderror');
}

// check file size
if ($_FILES["question_photo_upload"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
  header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=uploaderror');
}

// check if $uploadOk is set to 0 by an error,if no file was chosen (error won't be shown) 
if ($uploadOk == 0) {
  if($file=="" && $ques_pic!='-'){
    $update_sql="UPDATE question SET question_topic='$topic',question_level='$level',question_content='$content',question_answer='$answer',question_select='$select',question_picture='$ques_pic' WHERE question_id='$id'";
    $update_ques=mysqli_query($con,$update_sql);
    if($update_ques){
      header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=none');
    }
  }else if($ques_pic=="-" && $file!=""){
    echo "Sorry, there was an error uploading your file.";
    header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=uploaderror');
  }
  else if($ques_pic=="-" && $file==""){
    $update_sql="UPDATE question SET question_topic='$topic',question_level='$level',question_content='$content',question_answer='$answer',question_select='$select',question_picture='$ques_pic' WHERE question_id='$id'";
    $update_ques=mysqli_query($con,$update_sql);
    if($update_ques){
      header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=none');
    }
  }
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["question_photo_upload"]["tmp_name"], $target_file)) {
    if($file!='-'){
      unlink('question_photo/'.$ques_pic);
    }
    $update_sql="UPDATE question SET question_topic='$topic',question_level='$level',question_content='$content',question_answer='$answer',question_select='$select',question_picture='$file' WHERE question_id='$id'";
    $update_ques=mysqli_query($con,$update_sql);
    if($update_ques){
      echo "The file ". htmlspecialchars( basename( $_FILES["question_photo_upload"]["name"])). " has been uploaded.";
      header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=none');
    }else{
      header('Location:../jom_coding/edit_ques_page.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'&error=uploaderror');
    }
  }
}

?>