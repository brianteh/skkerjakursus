<?php  
    // fetch data from question for variuos usage in action_edit_question_full.php
    require "connect_database.php";
    $list="SELECT * FROM question WHERE question_id=".$_REQUEST['ques_id'];
    $result=mysqli_query($con,$list);
    while($row=mysqli_fetch_array($result)){
        $ques_id=$row['question_id'];
        $ques_topic=$row['question_topic'];
        $ques_content=$row['question_content'];
        $ques_level=$row['question_level'];
        $ques_select=$row['question_select'];
        $ques_type=$row['question_type'];
        $ques_answer=$row['question_answer']; 
        $ques_pic=$row['question_picture'];
    }
    
    
?>