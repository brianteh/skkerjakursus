<?php
    require "connect_database.php";
    // handling answer for custom quiz, random in question sequence and answer sequence
    $quiz_acquire="SELECT quiz_content FROM quiz WHERE quiz_pin_number=".$_SESSION['quiz_code'];
    $quiz_extract=mysqli_query($con,$quiz_acquire);
    if(!$quiz_extract){
        echo "<script>alert('Invalid quiz code!');window.location='content_quiz.php';</script>";
        exit();
    }
    if(empty($_SESSION['quiz_code']) || strlen($_SESSION['quiz_code'])>10){
        echo "<script>alert('Invalid quiz code!');window.location='content_quiz.php';</script>";
        exit();
    }
    while($row=mysqli_fetch_array($quiz_extract)){
        $quiz_content=$row['quiz_content'];

    }
    $quiz_array=preg_split("/,/",$quiz_content);
    $quiz_string="";
    for($i=0;$i<count($quiz_array);$i++){
        if($i==count($quiz_array)-1){
            $quiz_string=$quiz_string."'".$quiz_array[$i]."'";   
        }
        else{
            $quiz_string=$quiz_string."'".$quiz_array[$i]."',";
        }
    }
    $quiz_collect="SELECT * FROM question WHERE question_id IN (".$quiz_string.")";
    $show_quiz=mysqli_query($con,$quiz_collect);
    $list_of_all=array();
    $list_of_content=array();
    $list_of_answer=array();
    $list_of_type=array();
    $list_of_select=array();
    $list_of_picture=array();
    $list_of_id=array();
    $list_of_time_limit=array();
    date_default_timezone_set('Asia/Colombo');
    while($row=mysqli_fetch_array($show_quiz)){
        $question_id=$row['question_id'];
        $question_content=$row['question_content'];
        $question_answer=$row['question_answer'];
        $question_type=$row['question_type'];
        $question_select=$row['question_select'];
        $question_picture=$row['question_picture'];
        $question_time_limit=$row['question_time_limit'];
        array_push($list_of_all,$question_content.">".$question_answer.">".$question_type.">".$question_select.">".$question_picture.">".$question_id.">".$question_time_limit);
        
    }
    shuffle($list_of_all);
    foreach($list_of_all as $i){
        $list=preg_split("/>/",$i);
        array_push($list_of_content,$list[0]);
        array_push($list_of_answer,$list[1]);
        array_push($list_of_type,$list[2]);
        array_push($list_of_select,$list[3]);
        array_push($list_of_picture,$list[4]);
        array_push($list_of_id,$list[5]);
        array_push($list_of_time_limit,$list[6]);
    }
    $_SESSION['question_list']=$list_of_content;
    $_SESSION['question_answer']=$list_of_answer;
    $_SESSION['question_type']=$list_of_type;
    $_SESSION['question_select']=$list_of_select;
    $_SESSION['question_picture']=$list_of_picture;
    $_SESSION['question_seq']=$list_of_id;
    $_SESSION['question_time_limit']=$list_of_time_limit;
    $_SESSION['timer']=time();
    $_SESSION['current_answer_list']=array();

    
   