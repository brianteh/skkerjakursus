<?php
session_start();
// processes question search request
if(isset($_POST['search_question'])){
    $_SESSION['search_question']=$_POST['search_question'];
}else{
    $_SESSION['search_question']="";
}

header("Location:../jom_coding/content_admin_quiz.php");