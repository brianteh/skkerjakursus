<?php
    session_start();
    // processes and grab data for student report
    $string=explode("---->",$_POST['stu_stat']);
    $_SESSION['chose_student_quiz']=$string[1];
    $_SESSION['quiz_title']=$string[0];
    $_SESSION['chose_student_index']=$_POST['index'];
    echo "success";