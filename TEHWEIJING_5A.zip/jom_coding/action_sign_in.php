<?php
    require "connect_database.php";
    
if(isset($_POST['sign_in_btn'])){
    $in_uid=$_POST['uid'];
    $password=$_POST['password'];
    if (empty($in_uid) || empty($password)){
        header("Location:../jom_coding/content_sign_in.php?error=emptyfields");
        exit();
    }
    else{
        $sql="SELECT * FROM pme_user WHERE username=? OR user_email=? ";
        $stmt=mysqli_stmt_init($con);
        if(!mysqli_stmt_prepare($stmt,$sql)){
            header("Location:../jom_coding/content_sign_in.php?error=sqlerror");
            exit();
        }
        else{
            mysqli_stmt_bind_param($stmt,"ss",$in_uid,$in_uid);
            mysqli_stmt_execute($stmt);
            $usernameCheck=mysqli_stmt_get_result($stmt);
            if($row = mysqli_fetch_assoc($usernameCheck)){
                $pwdCheck=password_verify($password,$row['user_password']);
                if($pwdCheck==false){
                    header("Location:../jom_coding/content_sign_in.php?error=invalidpwd");
                    exit();

                }
                else if($pwdCheck==true){
                    session_start();
                    //update:should make it available for multiple account to sign in ,by using list 
                    //$_SESSION['user_list']=array();
                    $_SESSION['userID']=$row['user_id'];
                    $_SESSION['username']=$row['username'];
                    $_SESSION['user_email']=$row['user_email'];
                    $_SESSION['form']=$row['user_form'];
                    $_SESSION['acc_status']=$row['acc_status'];
                    $_SESSION['profile_pic']=$row['user_pic'];
                    $_SESSION['temp_pic']=$_SESSION['profile_pic'];
                    $_SESSION['toggle-music']=true;
                    if($_SESSION['acc_status']=="admin"){
                        $_SESSION['chosen_quiz_content']=array();
                    }
                    //$_SESSION['music_list']=array('cyberpunk','chilling','nature');
                    //$_SESSION['theme_list']=array('space','colourful','nature');
                    //array_push($_SESSION['user_list'],$"all session above");
                    $_SESSION['log_status']=1;
                    header("Location:../jom_coding/content_home.php");
                    echo "<script type=text/javascript>alert('Login Successful');</script>";
                    exit();

                }
                else{
                    header("Location:../jom_coding/content_sign_in.php?error=invalidpwd");
                    exit();

                }

            }
        }
    }

    

}
else{
    header("Location:../jom_coding/content_sign_in.php");
}