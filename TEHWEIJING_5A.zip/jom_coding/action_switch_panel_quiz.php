<?php
    session_start();
    // set orientation of specific quiz statistics panel
    if($_SESSION['quiz_main']==0){
        $_SESSION['quiz_main']=1;
    }else if($_SESSION['quiz_main']==1){
        $_SESSION['quiz_main']=2;
    }else if($_SESSION['quiz_main']==2){
        $_SESSION['quiz_main']=0;
    }
    echo "success";