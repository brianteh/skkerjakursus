<?php
session_start();
// set theme
$_SESSION['theme']=$_POST['theme'];