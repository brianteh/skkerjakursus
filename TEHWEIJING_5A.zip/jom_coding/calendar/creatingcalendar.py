from csv import writer
import sys
year=int(sys.argv[1])

def leap_year():
    with open('calendar.csv', 'a+', newline='') as file:
        f=writer(file)
        month=1
        #jan
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #feb
        for i in range(1,30):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #mac
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #apr
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #may
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #jun
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #jul
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #aug
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #sep
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #oct
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-{month}-0{i}'])
            else:
                f.writerow([f'{year}-{month}-{i}'])
        month+=1
        #nov
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-{month}-0{i}'])
            else:
                f.writerow([f'{year}-{month}-{i}'])
        month+=1
        #dec
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-{month}-0{i}'])
            else:
                f.writerow([f'{year}-{month}-{i}'])
              
    
def non_leap_year():
    with open('calendar.csv','a+', newline='') as file:
        f=writer(file)
        month=1
        #jan
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #feb
        for i in range(1,29):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #mac
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #apr
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #may
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #jun
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #jul
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #aug
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #sep
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-0{month}-0{i}'])
            else:
                f.writerow([f'{year}-0{month}-{i}'])
        month+=1
        #oct
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-{month}-0{i}'])
            else:
                f.writerow([f'{year}-{month}-{i}'])
        month+=1
        #nov
        for i in range(1,31):
            if(i<10):
                f.writerow([f'{year}-{month}-0{i}'])
            else:
                f.writerow([f'{year}-{month}-{i}'])
        month+=1
        #dec
        for i in range(1,32):
            if(i<10):
                f.writerow([f'{year}-{month}-0{i}'])
            else:
                f.writerow([f'{year}-{month}-{i}'])
if(year%4==0):
    if(year%100==0):
        if(year%400==0):
            leap_year()
        else:
            non_leap_year()
    else:
        leap_year()
else:
    non_leap_year()
