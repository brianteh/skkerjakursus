<?php
// connect to database
// for local host
$servername="localhost" ;
$DBusername="root";
$DBpassword="";
$DB="login";

// for web hosting 
/*$servername="fdb28.awardspace.net" ;
$DBusername="3734433_pme";
$DBpassword="pme1234!A@S#D";*/

$con = mysqli_connect($servername,$DBusername,$DBpassword) or die("Unable to connect");

//mysqli_select_db($con,"3734433_pme");
mysqli_select_db($con,$DB);


