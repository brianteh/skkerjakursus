<?php 
session_start();
if(!isset($_SESSION['userID'])){
    $_SESSION['userID']="null";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physics Made Easy</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/admin.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <style>
        body{
            background-image:url('image/background7.jpg');
            height:1080px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .autocomplete-items{
            z-index:1100;
            background-color: whitesmoke;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row head_admin" style="width:100%;z-index:1000;position:fixed;">
        <div class="col-sm-1"><center><a href="content_home.php"><img class="logo" src="image/physics.jpg" autofocus="off"></a></center></div>
        <div class="col-sm-8"></div>
        <div class="col-sm-2" style="margin-top:10px;"><center><input id="search_field" class="search_field" type="text" placeholder="Type in any keywords"></center></div>
        <div class="col-sm-1" style="margin-top:10px;"><button id="search_btn" class="search_btn">Search</button></div>
    </div>
    <script src="js/filterfaq.js"></script>
        <br><br><br><br>
        <div class="row">
            <div class="col-sm-1"></div>
            <div id="note_content" class="col-sm-10" style="border:2px solid white;background-color:white;box-shadow: 0 5px 15px rgba(0, 0, 0, 0.63);height:800px;width:1000px;overflow:auto;">
            <div>
            <?php
            // printing output of note content
                require 'connect_database.php';
                $id=$_REQUEST['note_id'];
                $grab_note_chosen="SELECT * FROM note WHERE note_id='$id'";
                $grabbing_note_chosen=mysqli_query($con,$grab_note_chosen);
                if($grabbing_note_chosen){
                    while($row=mysqli_fetch_array($grabbing_note_chosen)){
                        $content=$row['note_content'];
                        $topic=$row['note_topic'];
                        $title=$row['note_title'];
                        $status=$row['note_status'];
                        $user_id=$row['user_id'];
                        if($status=="public"){
                            ?>
                            <div id="note_size"><?php echo $content;?></div>
                            <?php
                        }else if($_SESSION['userID']!="null" && $_SESSION['userID']==$user_id){
                            ?>
                            <div id="note_size"><?php echo $content;?></div>
                            <?php
                        }else{
                            echo "<script type='text/javascript'>alert('This note is private');window.history.back();</script>";
                        }
                    }

                }
            ?>  
            </div>  
            </div>
            <div class="col-sm-1">
                <i id="toggle_btn" class="fas fa-toggle-off" style="color:white;cursor:pointer;" onclick="toggle_background();"></i>
                <span id="emoji">&#x1F31E;</span>
                <br><br><br><br><br><br><br><br>
                <i class="fas fa-plus" style="color:white;position:relative;top:-80px;right:-33px;"></i>
                <div style="transform:rotate(-90deg);"><input id="zoom" type="range" min="0" max="100" value="0"></div>
                <i class="fas fa-minus" style="color:white;position:relative;bottom:-30px;right:-33px;"></i> 
            </div>
            <script>
                var background=document.getElementById('note_content');
                var toggle_btn=document.getElementById('toggle_btn');
                var emoji=document.getElementById("emoji");
                var slider=document.getElementById("zoom");
                var note=document.getElementById("note_size");
                slider.onmouseleave=function(){
                    const num=1+(slider.value/100);
                    note.style.fontSize=num+"rem";
                }
                var state=true;
                function toggle_background(){
                    if(state){
                        toggle_btn.className="fas fa-toggle-on";
                        background.style.backgroundColor="black";
                        background.style.border="2px solid black";
                        emoji.innerHTML="&#x1F319;";
                        state=false;
                    }else{
                        toggle_btn.className="fas fa-toggle-off";
                        background.style.backgroundColor="white";
                        background.style.border="2px solid white";
                        state=true;
                        emoji.innerHTML="&#x1F31E;";
                    }
                }
            </script>
        </div>
    </div>
    
    
</body>
</html>