<?php
    session_start();
    if(!isset($_SESSION['log_status'])){
        $_SESSION['log_status']=0;
    }
    $_SESSION['ques_count']=0;
    if($_SESSION['log_status']==0){
        header("Location:../jom_coding/content_sign_in.php");
    }
    
    $_SESSION['page_type']=1;
    
    require "tabs.php";
?> 
     

<main>
   <?php
        require "main_quiz.php";
   ?> 
</main>

<?php
    require "footer.php";
?>