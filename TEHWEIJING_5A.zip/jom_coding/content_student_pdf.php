<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/admin.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <title>Print Result</title>
</head>
<body>
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
        <?php 
            require 'connect_database.php';
            $id=$_GET['user_id'];
            $grab_student_info="SELECT * FROM pme_user WHERE user_id='$id'";    
            $grabbing_student_info=mysqli_query($con,$grab_student_info);
            if($grabbing_student_info){
                while($row=mysqli_fetch_array($grabbing_student_info)){
                    $form=$row['user_form'];
                    $name=$row['username'];
                    $email=$row['user_email'];
                }
            }
        ?>
        <br><br>
        <h1>Student Info:</h1>
        <h3>FORM:   <?php echo $form;?></h3><hr/>
        <h3>NAME:   <?php echo $name;?></h3><hr/>
        <h3>EMAIL:   <?php echo $email;?></h3><hr/>
        <h1>Quiz Topic:</h1><Label style="color:#1c1c1c;font-size:1.5rem;"><?php echo $_SESSION['quiz_title'];?></Label>
        <table border="0" class="table">
            <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                <th>Date</th>
                <th>Time Used</th>
                <th>Result</th>
            </tr>
        <?php
            require 'connect_database.php';
            $pin=$_SESSION['chose_student_quiz'];
            // grab record of quiz
            $id=$_GET['user_id'];
            $grab_student_results="SELECT * FROM result WHERE user_id='$id' AND quiz_pin_number='$pin' ORDER BY date_time ASC";
            $grabbing_student_results=mysqli_query($con,$grab_student_results);
            if($grabbing_student_results){
                while($row=mysqli_fetch_array($grabbing_student_results)){
                    $date=$row['date_time'];
                    $time_used=$row['result_time_used'];
                    $accuracy=$row['result_accuracy'];
                    
        ?>
            <tr>
                <td><?php echo $date;?></td>
                <td><?php echo $time_used;?></td>
                <td><?php echo $accuracy;?></td>
            </tr>
        <?php 
                }
            }
        ?>
        </table>
        
        
        </div>
        <div class="col-sm-2"></div>
    </div>
    <footer style="margin-top:500px;">
        <center>Copyright © Physics Made Easy.Co</center>
    </footer>
    <script>
        // print as pdf
        window.print();
    </script>
</body>
</html>