<div class="row">
    <div class="col-sm-2" style="color:white;font-size:1.3rem;">
        Topic: <br><br>
        Title: <br><br>
        Keyword Tag: 
    </div>
    <div class="col-sm-10">
        <textarea id="note_topic" cols="80" rows="2"></textarea><br>
        <textarea id="note_title" cols="80" rows="2"></textarea><br>
        <textarea id="note_keyword" cols="80" rows="2"></textarea><br>
    </div>
</div>
<!-- FUNCTIONS FOR NOTE EDITING TOOLS-->
<div style="width:auto;color:white;" id='edit_container'>
    <button onclick="execCmd('bold');"><i class="fas fa-bold"></i></button>
    <button onclick="execCmd('italic');"><i class="fas fa-italic"></i></button>
    <button onclick="execCmd('underline');"><i class="fas fa-underline"></i></button>
    <button onclick="execCmd('strikeThrough');"><i class="fas fa-strikethrough"></i></button>
    <button onclick="execCmd('justifyLeft');"><i class="fas fa-align-left"></i></button>
    <button onclick="execCmd('justifyCenter');"><i class="fas fa-align-center"></i></button>
    <button onclick="execCmd('justifyRight');"><i class="fas fa-align-right"></i></button>
    <button onclick="execCmd('justifyFull');"><i class="fas fa-align-justify"></i></button>
    <button onclick="execCmd('cut');"><i class="fas fa-cut"></i></button>
    <button onclick="execCmd('copy');"><i class="fas fa-copy"></i></button>
    <button onclick="execCmd('indent');"><i class="fas fa-indent"></i></button>
    <button onclick="execCmd('outdent');"><i class="fa fa-dedent"></i></button>
    <button onclick="execCmd('subscript');"><i class="fas fa-subscript"></i></button>
    <button onclick="execCmd('superscript');"><i class="fas fa-superscript"></i></button>
    <button onclick="execCmd('undo');"><i class="fas fa-undo"></i></button>
    <button onclick="execCmd('redo');"><i class="fa fa-repeat"></i></button>
    <button onclick="execCmd('insertUnorderedList');"><i class="fas fa-list-ul"></i></button>
    <button onclick="execCmd('insertOrderedList');"><i class="fas fa-list-ol"></i></button>
    <button onclick="execCmd('insertParagraph');"><i class="fas fa-paragraph"></i></button>
    <select onchange="execCommandWithArg('formatblock',this.value);">
        <option value="H1">H1</option>
        <option value="H2">H2</option>
        <option value="H3">H3</option>
        <option value="H4">H4</option>
        <option value="H5">H5</option>
        <option value="H6">H6</option>
    </select>
    <button onclick="execCmd('insertHorizontalRule');"><i class="fas fa-ruler-horizontal"></i></button>
    <button onclick="execCmd('createLink',prompt('Enter Url',''));"><i class="fas fa-link"></i></button>
    <button onclick="execCmd('unlink');"><i class="fas fa-unlink"></i></button>
    <button id='source_btn' class="source_off" onclick="toggleSource();" title="on for HTML raw"><i class="fas fa-code"></i></button>
    <button onclick="toggleEdit();" id='edit_btn'>Edit <i class="fas fa-toggle-on"></i></button>
    <br>
    <select onchange="execCommandWithArg('fontName',this.value);">
        <option value="Arial" style="font-family:Arial;">Arial</option>
        <option value="Comic Sans MS" style="font-family:Comic Sans MS;">Comic Sans MS</option>
        <option value="Courier" style="font-family:Courier;">Courier</option>
        <option value="Georgia" style="font-family:Georgia;">Georgia</option>
        <option value="Tahoma" style="font-family:Tahoma;">Tahoma</option>
        <option value="Times New Roman" style="font-family:Times New Roman;">Times New Roman</option>
        <option value="Verdana" style="font-family:Verdana;">Verdana</option>
    </select>
    <select onchange="execCommandWithArg('fontSize',this.value);">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
    </select>
    Font color:<input type="color" onchange="execCommandWithArg('foreColor',this.value);"/>
    <button onclick="execCommandWithArg('insertImage',prompt('Enter image url:\n ~start with \'note_photo/imageName.extensionName\' >> if you are trying to add uploaded image\n ~image address >> if you are trying to add image from the Internet','note_photo/'));"><i class="fa fa-file-image-o"></i></button>
    <button onclick="execCmd('selectAll');">Select All</button>
</div>
<iframe id='editor' name="richTextField" contenteditable="true" style="height:500px;width:882px;"></iframe>
<script type="text/javascript">
    var showSourceCode=false;
    var editMode=true;
    var content=richTextField.document.getElementsByTagName('body')[0].innerHTML;
    var edit_btn=document.getElementById('edit_btn');
    var source_btn=document.getElementById('source_btn');
    richTextField.document.designMode='On';
    function execCmd(command){
        richTextField.document.execCommand(command,false,null);
    }
    function execCommandWithArg(command,arg){
        richTextField.document.execCommand(command,false,arg);
    }
    // change format of content (HTML raw / HTML processed)
    function toggleSource(){
        if(showSourceCode){
            richTextField.document.getElementsByTagName('body')[0].innerHTML=richTextField.document.getElementsByTagName('body')[0].textContent;
            source_btn.className='source_off';
            showSourceCode=false;
        }else{
            richTextField.document.getElementsByTagName('body')[0].textContent=richTextField.document.getElementsByTagName('body')[0].innerHTML;
            source_btn.className='source_on';
            showSourceCode=true;
        }
    }
    // enable or disable editing
    function toggleEdit(){
        if(editMode){
            richTextField.document.designMode='Off';
            edit_btn.children[0].className='fas fa-toggle-off';
            editMode=false;
        }else{
            richTextField.document.designMode='On';
            edit_btn.children[0].className='fas fa-toggle-on';
            editMode=true;
        }
    }
    function saveNote(){
        var request = new XMLHttpRequest();
        var url = "action_save_note.php";
        var note_topic=document.getElementById('note_topic').value;
        var note_title=document.getElementById('note_title').value;
        var note_keyword=document.getElementById('note_keyword').value;
        var note_content = richTextField.document.getElementsByTagName('body')[0].innerHTML;
        var $POST = "ncontent="+note_content+"&ntopic="+note_topic+"&ntitle="+note_title+"&nkeyword="+note_keyword+"";
        request.open("POST", url, true);
        request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var someCallback = request.responseText;
                if(someCallback=="success"){
                    document.getElementById("status").className='status status_success';
                    document.getElementById("status").textContent ="Success";
                    document.getElementById('note_topic').value="";
                    document.getElementById('note_title').value="";
                    document.getElementById('note_keyword').value="";
                    richTextField.document.getElementsByTagName('body')[0].textContent="";
                }else{
                    document.getElementById("status").className = 'status status_error';
                    document.getElementById("status").textContent ="Error";
                }
                
            }
        }
        request.send($POST);
    }
    
</script>
<div id="status" class="status_off" style="padding:15px;width:40%;"></div>
