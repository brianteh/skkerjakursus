<div id="edit_question" style="display:none;width:100%;height:100%;background-color:black;"></div>
<div id="delete_question" style="display:none;width:100%;height:100%;background-color:grey;"></div>

<div class="row content_admin">
    <div class="col-sm-2 nav_tab">
    
        <div class="row"><span class="" id="create_quiz"><center><i class="	far fa-calendar"></i> Create Quiz</center></span></div>
        <div class="row"><span class="" id="create_question"><center><i class="fab fa-accusoft"></i> Create Question</center></span></div>
        <div class="row"><span class="" id="create_note"><center><i class="fas fa-graduation-cap"></i> Create Note</center></span></div>
        <div class="row"><span class="" id="statistics"><center><i class="fas fa-chart-bar"></i> Statistics</center></span></div>
       
        <script>
            
            var create_quiz=document.getElementById("create_quiz");
            var create_question=document.getElementById("create_question");
            var create_note=document.getElementById("create_note");
            var statistics=document.getElementById("statistics");
            var tabz=document.getElementsByClassName("tabz");
            var pages=document.getElementsByClassName("pages");

            create_quiz.onclick=function(){
                create_quiz.className="active_tabz";
                create_question.className="";
                create_note.className="";
                statistics.className="";
                pages[0].style.display="block";
                pages[1].style.display="none";
                pages[2].style.display="none";
                pages[3].style.display="none";
                
            }
            create_question.onclick=function(){
                create_quiz.className="";
                create_question.className="active_tabz";
                create_note.className="";
                statistics.className="";
                pages[0].style.display="none";
                pages[1].style.display="block";
                pages[2].style.display="none";
                pages[3].style.display="none";
              
            }
            create_note.onclick=function(){
                create_quiz.className="";
                create_question.className="";
                create_note.className="active_tabz";
                statistics.className="";
                pages[0].style.display="none";
                pages[1].style.display="none";
                pages[2].style.display="block";
                pages[3].style.display="none";
            }
            statistics.onclick=function(){
                create_quiz.className="";
                create_question.className="";
                create_note.className="";
                statistics.className="active_tabz";
                pages[0].style.display="none";
                pages[1].style.display="none";
                pages[2].style.display="none";
                pages[3].style.display="block";
            }
        </script>
        
    </div>
  
    <div class="col-sm-10 main_content pages" style="display:block;">
        <br>
        <Label style="color:white;font-size:1.5rem;"><i class="fas fa-edit"></i> Create your own Quiz:</Label>    
            <form method='POST' action="action_create_quiz.php">
            <span class="quiz_text">Quiz PIN:</span> <input name="quiz_pin" type="text">
            <span class="quiz_text">Quiz Level:</span> <input name="quiz_level" type="text">
            <span class="quiz_text">Quiz Name:</span> <input name="quiz_name" type="text"><br>
            <span class="quiz_text">Quiz Directory:</span>
        
            <table border="0" class="table">
                        <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                            <th>Question ID</th>
                            <th>Question Topic </th>
                            <th>Question Content</th>
                            <th>Question Level</th>
                            <th>Action</th>
                        </tr>
                    <?php 
                    $chosen_quiz_string="";
                    if(count($_SESSION['chosen_quiz_content'])){
                    for($i=0;$i<count($_SESSION['chosen_quiz_content']);$i++){
                        if($i==count($_SESSION['chosen_quiz_content'])-1){
                        $chosen_quiz_string=$chosen_quiz_string."'".$_SESSION['chosen_quiz_content'][$i]."'";   
                        }
                        else{
                        $chosen_quiz_string=$chosen_quiz_string."'".$_SESSION['chosen_quiz_content'][$i]."',";
                        }
                    }
                    }

                    if(!empty($_SESSION['chosen_quiz_content'])){
                        require "connect_database.php";
                        $list="SELECT * FROM question WHERE question_id IN (".$chosen_quiz_string.")";
                        $result=mysqli_query($con,$list);
                        while($row=mysqli_fetch_array($result)){
                            $a=$row['question_id'];
                            $b=$row['question_topic'];
                            $c=$row['question_content'];
                            $d=$row['question_level'];
                    ?>
                        <tr border="0" style="background-color:white;">
                            <td><?php echo $a; ?></td>
                            <td><?php echo $b; ?></td>
                            <td><?php echo $c; ?></td>
                            <td><?php echo $d; ?></td>
                            <td><a href="action_deleteques_from_quiz.php?ques_id=<?php echo $a;?>"><i class="fa fa-close"></i></a></td>
                        </tr>
                    <?php
                        }
                    }else{
                        echo "<tr>It's Empty!</tr>";
                    }
                
                    ?> 
                    </table>
            <button type="submit"><i class="fa fa-angle-right"></i> Create Quiz <i class="fa fa-angle-left"></i></button>
            
            
            </form> 
            <br><br>
            <Label style="color:white;font-size:1.5rem;"><i class="fas fa-folder-open"></i> Available Quiz:</Label>
            <form method="POST" action="action_search_quiz.php">
                <input name="search_quiz" type="text" placeholder="Search">
                <div class="available">
                <table border="0" class="table">
                    <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                        <th>Quiz Pin</th>
                        <th>Quiz Name </th>
                        <th>Quiz Content</th>
                        <th>Quiz Level</th>
                        <th>Action</th>
                    </tr>
                <?php 
                if(!isset($_SESSION['search_quiz'])){
                    $_SESSION['search_quiz']="";
                }
                $search_quiz=$_SESSION['search_quiz'];
                if(!empty($search_quiz)){
                    require "connect_database.php";
                    $list="SELECT * FROM quiz WHERE quiz_pin_number LIKE '%$search_quiz%' OR quiz_name LIKE '%$search_quiz%' OR quiz_level LIKE '%$search_quiz%'";
                    $result=mysqli_query($con,$list);
                    while($row=mysqli_fetch_array($result)){
                        $a=$row['quiz_pin_number'];
                        $b=$row['quiz_name'];
                        $c=$row['quiz_content'];
                        $d=$row['quiz_level'];
                ?>
                    <tr border="0" style="background-color:white;">
                        <td><?php echo $a; ?></td>
                        <td><?php echo $b; ?></td>
                        <td><?php echo $c; ?></td>
                        <td><?php echo $d; ?></td>
                        <td><a href="action_addquiz_to_quiz.php?quiz_content=<?php echo $c;?>"><i class="fas fa-folder-plus"></i></a></td>
                    </tr>
                <?php
                    }
                }else{
                    echo "<tr>It's Empty!</tr>";
                }
                ?> 
                </table>
                </div>
            </form>
            <br><br>
       
            <Label style="color:white;font-size:1.5rem;"><i class="	far fa-folder-open"></i> Available Question:</Label>
            <form method="POST" action="action_search_question.php">
                <input name="search_question" type="text" placeholder="Search">
                <div class="available">
                <table border="0" class="table">
                    <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                        <th>Question ID</th>
                        <th>Question Topic </th>
                        <th>Question Content</th>
                        <th>Question Level</th>
                        <th>Action</th>
                    </tr>
                <?php 
                if(!isset($_SESSION['search_question'])){
                    $_SESSION['search_question']="";
                }
                $search_question=$_SESSION['search_question'];
                if(!empty($search_question)){
                    require "connect_database.php";
                    $list="SELECT * FROM question WHERE question_id LIKE '%$search_question%' OR question_content LIKE '%$search_question%' OR question_level LIKE '%$search_question%' OR question_topic LIKE '%$search_question%'";
                    $result=mysqli_query($con,$list);
                    while($row=mysqli_fetch_array($result)){
                        $a=$row['question_id'];
                        $b=$row['question_topic'];
                        $c=$row['question_content'];
                        $d=$row['question_level'];
                ?>
                    <tr border="0" style="background-color:white;">
                        <td><?php echo $a; ?></td>
                        <td><?php echo $b; ?></td>
                        <td><?php echo $c; ?></td>
                        <td><?php echo $d; ?></td>
                        <?php
                        if(in_array($a,$_SESSION['chosen_quiz_content'])){
                            echo '<td><i class="fa fa-check-circle-o"></i></td>';
                        }else{
                            echo '<td><a href="action_addques_to_quiz.php?ques_id='.$a.'"><i class="fas fa-folder-plus"></i></a></td>';
                        }
                        ?>
                    </tr>
                <?php
                    }
                }else{
                    echo "<tr>It's Empty!</tr>";
                }
                ?> 
                </table>
                </div>
            </form>
       
    </div>

    <div class="col-sm-10 main_content pages" style="display:none;">
        <br>
        <Label title="Questions you had created"style="color:white;font-size:1.5rem;"><i class="far fa-folder-open"></i>Accessable question:</Label>
           
                
                <div class="availablez">
                <form method="POST" action="action_edit_question.php">
                <table border="0" class="table">
                    <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                        <th>Question ID</th>
                        <th>Question Topic </th>
                        <th>Question Content</th>
                        <th>Question Level</th>
                        <th>Edit question</th>
                    </tr>
                <?php 
                    require "connect_database.php";
                    $list="SELECT * FROM question WHERE user_id=".$_SESSION['userID'];
                    $result=mysqli_query($con,$list);
                    while($row=mysqli_fetch_array($result)){
                        $a=$row['question_id'];
                        $b=$row['question_topic'];
                        $c=$row['question_content'];
                        $d=$row['question_level'];
                        $e=$row['question_select'];
                        $f=$row['question_type'];
                ?>
                    <tr border="0" style="background-color:white;">
                        <td><?php echo $a; ?></td>
                        <td><?php echo $b; ?></td>
                        <td><?php echo $c; ?></td>
                        <td><?php echo $d; ?></td>
                        <td> 
                            <a class="editor" style="margin-left:10px;" href="edit_ques_page.php?ques_id=<?php echo $a;?>&type=<?php echo $f;?>&error=none" target="_blank"><i class="fas fa-pen"></i></a><a class="editor" style="margin-left:40px;" href="content_admin.php?ques_id=<?php echo $a;?>"><i class="fas fa-trash-alt"></i></a>                           
                        </td> 
                    </tr>
                <?php
                    }
                ?> 
                </table>
                </form>
                </div>
                <Label style="color:white;font-size:1.5rem;"><i class="fas fa-edit"></i> Create your own Question:</Label>
    </div>
   
    <div class="col-sm-10 main_content pages" style="display:none;">Note</div>
    
    <div class="col-sm-10 main_content pages" style="display:none;">statistics</div>
</div>