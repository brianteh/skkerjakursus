<main>
<?php 
if(!isset($_SESSION['age'])){
    $_SESSION['age']=$_SESSION['form'];
}
?>
<div class="container-fluid">
<div class="row">
<div class="col-sm-2">
    <h2 id="bui_quiz" class="selected_quiz">Built in Quiz</h2>
    <h2 id="cus_quiz" class="">Custom Quiz</h2>
</div>
<div class="quiz_form col-sm-10">
    <br>
    <div class="quiz_type" style="margin-left:200px;font-size:1.4rem;">
        Form:
        <select id="age" style="position:relative;left:25px;border-radius:15px;padding:10px;width:auto;outline:none;">
            <option value="1">Form 1</option>
            <option value="2">Form 2</option>
            <option value="3">Form 3</option>
            <option value="4">Form 4</option>
        </select>
        <script>
            var age=document.getElementById('age');
            var current=<?php echo json_encode($_SESSION['age']);?>;
            age.selectedIndex=current-1;
            // age.select option for $_SESSION['age']
            age.onchange=function (){
                var age_value=age.value;
                var request=new XMLHttpRequest();
                var $POST="age="+age_value;
                var url="action_set_age.php";
                request.open('POST',url,true);
                request.setRequestHeader('Content-type','application/x-www-form-urlencoded');
                request.send($POST);
                request.onreadystatechange = function() {
                    if(request.readyState == 4 && request.status == 200) {
                        var someCallback = request.responseText;
                        if(someCallback=="success"){
                            location.reload();
                        }
                        
                    }
                }   
            }
        </script>
        <br><br>
        <form method="POST" action="action_quiz_setup.php">
            Subject:
            <select name="topic" style="border-radius:15px;padding:10px;width:auto;outline:none;">
            <?php
                // gathering different question topic 
                require "connect_database.php";
                $find_topic="SELECT DISTINCT question_topic FROM question WHERE question_level<=".$_SESSION['age'];
                $result_topic=mysqli_query($con,$find_topic);
                while($row=mysqli_fetch_array($result_topic)){
                    $available=$row['question_topic'];
            ?>
                <option value="<?php echo $available;?>"><?php echo $available;?></option>
            <?php
                }
            ?>
            </select>
            <br><br>
            <button name='built-in-btn' type='submit' style="padding:15px;"><i class="fa fa-flag-checkered"></i> <b>Start<b></button>
        </form>
    </div>
    <div class="quiz_type" style="display:none;margin-left:200px;font-size:1.4rem;">
        <form  method="POST" action="action_quiz_setup.php">
        Quiz Code: <input name="quiz_code" class="field" type="text" placeholder="Enter your quiz code here" style="width:300px;border-top-right-radius:0px;border-bottom-right-radius:0px;" required/> <button name="custom-btn" type="submit" style="padding:15px;border-top-left-radius:0px;border-bottom-left-radius:0px;border-top-right-radius:25px;border-bottom-right-radius:25px;margin-left:-5px;"><i class="fa fa-flag-checkered"></i> Start</button>
        </form>
    </div>
</div>
</div>
<script>
    var built=document.getElementById('bui_quiz');
    var custom=document.getElementById('cus_quiz');
    var form=document.getElementsByClassName('quiz_type');
    built.onclick=function(){
        form[0].style.display="block";
        form[1].style.display="none";
        built.className="selected_quiz";
        custom.className="";
    }
    custom.onclick=function(){
        form[1].style.display="block";
        form[0].style.display="none";
        built.className="";
        custom.className="selected_quiz";
        
    }
</script>
</div>

<!--SEE RECENT QUIZ by adding cookies-->


</main>
