<br><br>
<div class="sign_up_style row">
    <div class="col-sm-2"></div>
    <div class="col-sm-8 sign_up_content">
        <br><br>
        <!--FORM FOR SIGN UP-->
        <form class="sign_up_form" action="action_sign_up.php" method="POST">
            <div class="row">
                <div class="col-sm-3 labelz"><label><b>Username:</b></label></div>
                <div class="col-sm-9">
                    <input class="fieldz" name="uid" placeholder="Your Name" type="text" required/>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-sm-3 labelz"><label><b>User info:</b></label></div>
                <div class="col-sm-9">
                    <select class="s_field" name="status">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                    </select>
                    <select class="s_field" name="age">
                    <option value=4>Form 4</option>
                    <option value=3>Form 3</option>
                    <option value=2>Form 2</option>
                    <option value=1>Form 1</option>
                    </select>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-sm-3 labelz"><label><b>Email:</b></label></div>
                <div class="col-sm-9"><input class="fieldz" name="mail" placeholder="Your Email" type="text" required/></div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-sm-3 labelz"><label><b>Password:</b></label></div>
                <div class="col-sm-9"><input class="fieldz" name="pwd" placeholder="Your Password" type="password" required/></div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-sm-3 labelz"><label><b>Confirm Password:</b></label></div>
                <div class="col-sm-9"><input class="fieldz" name="r_pwd" placeholder="Confirm Your Password" type="password" required/></div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-sm-3 labelz">
                    <label><b>Class:</b></label><br>
                    <i class="fas fa-toggle-off" id="toggle_class" onclick="toggle_status_class();" title="New Class"></i>
                    <div id="class_popup" 
                        style="border-radius:35px;padding:20px;background-color:white;position:relative;width:200px;color:#1c1c1c;top:50px;display:none;">
                        Click this to create a new class!
                    </div>
                </div>
                <div class="col-sm-9">
                    <input class="fieldz" name="cls_id" placeholder="Your Class ID" type="text" required/><br><br>
                    <input id="new_cls" class="fieldz" name="cls_name" placeholder="New Class Name (max 25 letters)" type="text" value="-" 
                    style="display:none;margin-left:105px;"required/>
                </div>
                <script>
                    // show new class name field if toggled
                        var toggle_class=document.getElementById("toggle_class");
                        var new_class=document.getElementById("new_cls");
                        var class_popup=document.getElementById("class_popup");
                        var state=true;
                        function toggle_status_class(){
                            if(state){
                                toggle_class.className="fas fa-toggle-off";
                                new_class.style.display="none";
                                state=false;
                            }
                            else if(!state){
                                toggle_class.className="fas fa-toggle-on";
                                new_class.style.display="block";
                                state=true;
                            }
                        }
                        toggle_class.onmouseover=function(){
                            class_popup.style.display="block";
                        }
                        toggle_class.onmouseleave=function(){
                            class_popup.style.display="none";
                        }
                </script>
            </div>
            <br><br>
            <button style="width:140px;" id="sign_up_btn" name="sign_up_btn" type="submit"><i class="fa fa-arrow-circle-o-right"></i>  
            <b>Sign Up</b>
            </button>
        </form>
        <br>
    </div>
    <div class="col-sm-2"></div>
</div>
