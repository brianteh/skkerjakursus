-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2021 at 12:04 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE `note` (
  `note_id` int(100) NOT NULL,
  `note_topic` varchar(1000) NOT NULL,
  `note_title` text NOT NULL,
  `note_content` text NOT NULL,
  `user_id` int(255) NOT NULL,
  `note_status` varchar(7) NOT NULL,
  `note_keyword` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`note_id`, `note_topic`, `note_title`, `note_content`, `user_id`, `note_status`, `note_keyword`) VALUES
(56, 'Heat', 'What is thermal equilibrium?', '<font face=\"Comic Sans MS\" color=\"#a40e0e\">Two physical systems are in thermal equilibrium if there is no net flow of thermal energy between them when they are connected by a path permeable to heat.</font><div><br></div><div><font face=\"Comic Sans MS\" color=\"#cb3a3a\"></font></div><iframe width=\"734\" height=\"413\" src=\"https://www.youtube.com/embed/gzy4YFuKg9A\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\"></iframe>', 8, 'public', 'thermal equilibrium,thermal,heat,heat transfer');

-- --------------------------------------------------------

--
-- Table structure for table `pme_class`
--

CREATE TABLE `pme_class` (
  `class_id` varchar(11) NOT NULL,
  `class_name` varchar(25) NOT NULL,
  `class_num` int(11) NOT NULL,
  `class_date_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pme_class`
--

INSERT INTO `pme_class` (`class_id`, `class_name`, `class_num`, `class_date_time`) VALUES
('12344', 'Physics_Course2', 5, '2021-05-09 10:36:46'),
('12345', 'Physics_Course', 2, '2021-05-11 10:37:03'),
('12345678', 'adjhgasdkjhagskjahsgkjash', 1, '2021-08-06 11:34:24'),
('12346', 'Physics_Course3', 1, '2021-06-12 13:48:26'),
('12347', 'Physics_Course4', 1, '2021-06-18 11:51:57'),
('15624165426', 'zadfgsdfgdfg', 1, '2021-06-26 14:25:31');

-- --------------------------------------------------------

--
-- Table structure for table `pme_user`
--

CREATE TABLE `pme_user` (
  `user_id` int(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(10000) NOT NULL,
  `acc_status` varchar(5) NOT NULL,
  `user_form` int(1) NOT NULL,
  `user_pic` text NOT NULL,
  `class_id` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pme_user`
--

INSERT INTO `pme_user` (`user_id`, `username`, `user_email`, `user_password`, `acc_status`, `user_form`, `user_pic`, `class_id`) VALUES
(6, 'thomas', 'qbertaaa@gmail.com', '$2y$10$Zivmda7Bp3giUPNznOAtmu4BC3kFSMjaJekCBFzM8/f13N0iRqHBS', 'user', 4, 'squidward.jpg', '12345'),
(8, 'eeee', 'brian_teh@ymail.com', '$2y$10$smCDDMF2nH22fAIib4uEUeXvDmewu8Sc5A1cuM8RYKwGUe2h9ih2.', 'admin', 4, 'default_avatar.png', '12344'),
(10, 'cavekagoo', 'm-11308201@moe-dl.edu.my', '$2y$10$rhRV0Z8VfHj1pyXS65jX/eQPvSYNFUUTL.o0IXGFZmArcuKz4wSb6', 'admin', 4, 'squidward.jpg', '12345'),
(13, 'holol', 'ecslb04@gmail.com', '$2y$10$z3F/JDJqEk0uKBUKPcZWZ.7c64e04odGA/Bkmav2rpmLksRCHWhEW', 'user', 3, '60c4d89e60e2d1.25771386.png', '12344'),
(14, 'halil', 'ecprefectofficial@gmail.com', '$2y$10$uIKUOaxB9yf.9CkngJgVO.QzRvnHqHG8n7vK0WlSwEt6rZn9RpkRa', 'user', 4, '-', '12344'),
(35, 'aaron', 'tehline123@gmail.com', '$2y$10$LqMaNczVfHTX9RnhzJ9Lk.g1/yjF2L5Vd2F1pBNvEqk.aNMZz5K5q', 'user', 4, 'default_avatar.png', '12347'),
(36, 'hhf', 'tehcognito6@gmail.com', '$2y$10$IeLnIQK8Myoj337goKgt0eZy96Gv6b1seudU/xZNZJJpQChgaGMfi', 'user', 4, 'default_avatar.png', '15624165426'),
(39, 'tehweijing', 'brianteh007@gmail.com', '$2y$10$cbmssYAPrt584T8b9j88hOkoE6IY0Mt221AgR8wopFuQV6tJrIuQG', 'user', 5, '-', '12344'),
(40, 'lsm', 'maytheresalim@gmail.com', '$2y$10$Z8GT6jqmdqoGaNfMyw76neoJlBkGM74kRuXKP4JoeKFQf9mv9Ck7q', 'user', 5, '-', '12344'),
(41, 'hohoho', 'webinc@gmail.com', '$2y$10$JnsHbM6LzmbUpbC3QU0YgeNDZzY7F30cJANIvbeXfx.4RlkJnD8ne', 'user', 4, 'default_avatar.png', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `question_id` int(100) NOT NULL,
  `question_topic` text NOT NULL,
  `question_content` text NOT NULL,
  `question_answer` text NOT NULL,
  `question_status` text NOT NULL,
  `question_select` text NOT NULL,
  `question_level` int(1) NOT NULL,
  `question_type` varchar(3) NOT NULL,
  `question_time_limit` int(2) DEFAULT NULL,
  `question_picture` text NOT NULL,
  `user_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`question_id`, `question_topic`, `question_content`, `question_answer`, `question_status`, `question_select`, `question_level`, `question_type`, `question_time_limit`, `question_picture`, `user_id`) VALUES
(1, 'Heat', 'What is the SI unit for temperature?', 'Kelvin', 'public', '_', 1, 'SUB', 40, 'pixil-frame-4.png', 8),
(2, 'Light', 'How does light travel?', 'in a straight line', 'public', '_', 2, 'SUB', 20, 'light.gif\r\n', 8),
(3, 'Heat', 'What is the equation for calculating latent heat?', 'l=Q/m', 'public', '_', 1, 'SUB', 20, 'pixil-frame-5.png', 8),
(4, 'Heat', 'What is the freezing point of water?', '0 celsius degree', 'public', '_', 2, 'SUB', 60, '600abea9b3be74.62935155.png', 8),
(5, 'Heat', 'What is the specific heat capacity of water?', '420', 'public', '430-400-450-420', 4, 'OBJ', 20, '-', 8),
(6, 'Light', 'What is the speed of light?', '3.0*10^8', 'public', '_', 1, 'SUB', 60, 'pixil-frame-2.png', 8),
(8, 'Wave', 'What is the velocity of the wave if given f=50Hz and λ=1.5m?', '75ms^-1', 'public', '_', 4, 'SUB', 20, 'pixil-frame-0 - 2020-07-31T165805.929.png', 10),
(14, 'Gravity', 'What keeps us on the surface on the Earth?', 'gravity', 'public', '-', 1, 'SUB', 100, '_', 8),
(15, 'Gravity', 'What is the weight of a 600N man if he is in the Moon?', '100N', 'public', '_', 3, 'SUB', 80, '-', 8),
(2170, 'Heat', 'What is the energy required to boil 100g of water in 30 degree celsius in J(joule)? Given the formula Q=mcθ.', '29400', 'public', '29400-46700-78231-48493', 3, 'OBJ', 72, '-', 8),
(2173, 'Pressure', 'What is the pressure exerted on a plate if its area is 1m^2 and is pushed down with a force of 60N?', '60Pa', 'public', '_', 4, 'SUB', 40, '-', 8),
(2174, 'Pressure', 'What is the pressure exerted on a plate if its area is 0.1m^2 and is pushed down with a force of 600N?', '6000Pa', 'public', '_', 4, 'SUB', 60, '-', 8);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `quiz_pin_number` varchar(10) NOT NULL,
  `quiz_name` text NOT NULL,
  `quiz_content` text NOT NULL,
  `quiz_level` int(1) NOT NULL,
  `quiz_status` text NOT NULL,
  `quiz_time_stamp` date NOT NULL,
  `user_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`quiz_pin_number`, `quiz_name`, `quiz_content`, `quiz_level`, `quiz_status`, `quiz_time_stamp`, `user_id`) VALUES
('12345', 'Physics:All', '8,1,9,2,3,6,4,5', 4, 'public', '2021-01-01', 8),
('12567', 'PhysicsForm5', '1,8,14,15,3,4,5,2', 4, 'private', '2021-06-11', 8),
('1345134522', 'Physics:Heat', '1,3,4,5', 1, 'public', '2021-01-01', 8),
('1345134524', 'Physics:All', '1,3,4,5', 2, 'public', '2021-01-01', 8),
('1345134525', 'Physics:All', '1,3,4,5,2', 2, 'public', '2021-01-01', 8),
('1345134526', 'Physics:Light', '6,8', 3, 'public', '2021-01-01', 10);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `user_id` int(255) NOT NULL,
  `date_time` date NOT NULL,
  `hour_time` time NOT NULL,
  `utc_time` datetime NOT NULL,
  `quiz_pin_number` varchar(10) NOT NULL,
  `result_score` text NOT NULL,
  `result_accuracy` text NOT NULL,
  `result_time_used` int(11) NOT NULL,
  `result_wrong_question` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`user_id`, `date_time`, `hour_time`, `utc_time`, `quiz_pin_number`, `result_score`, `result_accuracy`, `result_time_used`, `result_wrong_question`) VALUES
(8, '2021-05-11', '20:00:00', '2021-05-13 20:02:21', '12345', '4', '50%', 56, '1,2,3,4'),
(8, '2021-05-13', '20:00:00', '2021-05-13 20:52:30', '12345', '0', '0%', 246, '1,5,3,8,2,4,6'),
(8, '2021-06-03', '22:00:00', '2021-06-03 22:55:13', '12345', '1', '14.29%', 44, '1,4,6,3,2,8'),
(13, '2021-06-07', '23:00:00', '2021-06-07 23:07:36', '12345', '1', '14.29%', 18, '6,3,4,8,2,1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`note_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pme_class`
--
ALTER TABLE `pme_class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `pme_user`
--
ALTER TABLE `pme_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`quiz_pin_number`) USING BTREE,
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD KEY `user_id` (`user_id`),
  ADD KEY `quiz_pin_number` (`quiz_pin_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
  MODIFY `note_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `pme_user`
--
ALTER TABLE `pme_user`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `question_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2175;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `note`
--
ALTER TABLE `note`
  ADD CONSTRAINT `note_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `pme_user` (`user_id`);

--
-- Constraints for table `pme_user`
--
ALTER TABLE `pme_user`
  ADD CONSTRAINT `pme_user_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `pme_class` (`class_id`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `pme_user` (`user_id`);

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `pme_user` (`user_id`);

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `pme_user` (`user_id`),
  ADD CONSTRAINT `result_ibfk_2` FOREIGN KEY (`quiz_pin_number`) REFERENCES `quiz` (`quiz_pin_number`);

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `user_expiry` ON SCHEDULE EVERY 1 MONTH STARTS '2021-04-29 18:16:13' ON COMPLETION PRESERVE ENABLE COMMENT 'Trying Event' DO SELECT * FROM pme_user$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
