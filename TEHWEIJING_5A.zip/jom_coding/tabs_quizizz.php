<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physics Made Easy - Quiz is Playing</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/result.css">
     <link type="text/css" rel ="stylesheet" href="css/timer.css">
    <link type="text/css" rel ="stylesheet" href="css/quiz_content.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <style>
        main{
            height:auto;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }   
    </style>
</head>
<body>
    

    
