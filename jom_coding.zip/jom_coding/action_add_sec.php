<?php
    session_start();
    // add to count down timer via ajax request
    $_SESSION['count_down_sec']=$_SESSION['count_down_sec']-1;
    if($_SESSION['count_down_sec']==0){
        echo "1";
    }else{
        echo "0";
    }