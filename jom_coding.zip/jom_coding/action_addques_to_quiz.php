<?php
    session_start();
    // see if ques_id already exist in quiz directory
    if(isset($_REQUEST['ques_id'])){
        if(!in_array($_REQUEST['ques_id'],$_SESSION['chosen_quiz_content'])){
            array_push($_SESSION['chosen_quiz_content'],$_REQUEST['ques_id']);
        }
    }

    header("Location:../jom_coding/content_admin_quiz.php");
