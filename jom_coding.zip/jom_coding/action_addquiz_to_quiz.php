<?php
    session_start();
    // add quiz content of an existing quiz to the quiz directory
    if(isset($_REQUEST['quiz_content'])){
        $chosen_list=preg_split("/,/",$_REQUEST['quiz_content']);
        foreach($chosen_list as $chl){
            if(!in_array($chl,$_SESSION['chosen_quiz_content'])){
                array_push($_SESSION['chosen_quiz_content'],$chl);
            }
        }
    }
    header("Location:../jom_coding/content_admin_quiz.php");   