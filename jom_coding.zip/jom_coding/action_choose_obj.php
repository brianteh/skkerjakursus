<?php
    session_start();
    // update objective question settings
    $_SESSION['current_answer']=$_REQUEST['current'];
    $_SESSION['obj_count']=$_REQUEST['obj_count'];
    header("Location:../jom_coding/content_quizizz.php"); 
