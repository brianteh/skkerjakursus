<?php
    session_start();
    // clear quiz directory
    if($_POST['click']==1){
        $_SESSION['chosen_quiz_content']=array();
    }
?>