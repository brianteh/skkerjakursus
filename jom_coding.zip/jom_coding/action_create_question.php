<?php
    session_start();
    // add question into database
    require 'connect_database.php';
    $target_dir = "question_photo/";
    $target_file = $target_dir . basename($_FILES["ques_pic"]["name"]);
    $file=basename($_FILES["ques_pic"]["name"]);
    $upOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $ques_topic=$_POST['ques_topic'];
    $ques_level=$_POST['ques_level'];
    $ques_type=$_POST['ques_type'];
    $ques_content=$_POST['ques_content'];
    $ques_answer=$_POST['ques_answer'];
    $ques_select=$_POST['ques_select'];
    $ques_time_limit=$_POST['ques_time_limit'];
    $user_id=$_SESSION['userID'];
    echo $file;
    if(isset($_POST["create_ques"])) {
        if($file==""){
            echo "nofile";
            // no question photo is uploaded in this case
            $create_ques="INSERT INTO question (question_topic,question_content,question_answer,question_status,question_select,question_level,
                          question_type,question_time_limit,question_picture,user_id) 
                          VALUES('$ques_topic','$ques_content','$ques_answer','private','$ques_select',
                          '$ques_level','$ques_type','$ques_time_limit','-','$user_id')";
            $creating_ques=mysqli_query($con,$create_ques);
            if($creating_ques){
                header('Location:../jom_coding/content_admin_question.php');
            }else{
                header('Location:../jom_coding/content_admin_question.php?error=sqlerror');
            }
        }else{
            $check = getimagesize($_FILES["ques_pic"]["tmp_name"]);
            if($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $upOk = 1;
            }else{
                echo "File is not an image.";
                $upOk = 0;
            }
        }
        
    }
    if($file!=""){
        // check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $upOk = 0;
        
        }
        
        // check file size
        if ($_FILES["ques_pic"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $upOk = 0;
            
            
        }
        
        // allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $upOk = 0;
            
            
        }
    } 
    
    // upload file
    if($upOk==1){
        if (move_uploaded_file($_FILES["ques_pic"]["tmp_name"], $target_file)){
            $create_ques="INSERT INTO question (question_topic,question_content,question_answer,question_status,question_select,
                          question_level,question_type,question_time_limit,question_picture,user_id) 
                          VALUES('$ques_topic','$ques_content','$ques_answer','private','$ques_select','$ques_level',
                          '$ques_type','$ques_time_limit','$file','$user_id')";
            $creating_ques=mysqli_query($con,$create_ques);
            if($creating_ques){
                header('Location:../jom_coding/content_admin_question.php');
            }else{
                header('Location:../jom_coding/content_admin_question.php?error=sqlerror');
            }
        }   
    }  
    