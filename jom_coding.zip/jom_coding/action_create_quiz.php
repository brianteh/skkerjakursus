<?php
    session_start();
    require "connect_database.php";
    $quiz_pin=$_POST['quiz_pin'];
    $quiz_level=$_POST['quiz_level'];
    $quiz_name=$_POST['quiz_name'];
    $user_id=$_SESSION['userID'];
    $quiz_content="";

    // add the question id in quiz directory into the new quiz's content
    if(count($_SESSION['chosen_quiz_content'])){
        for($i=0;$i<count($_SESSION['chosen_quiz_content']);$i++){
            if($i==count($_SESSION['chosen_quiz_content'])-1){
               $quiz_content=$quiz_content.$_SESSION['chosen_quiz_content'][$i];   
            }
            else{
               $quiz_content=$quiz_content.$_SESSION['chosen_quiz_content'][$i].",";
            }
        }
        $checkquiz_sql="SELECT quiz_pin_number FROM quiz WHERE quiz_pin_number='$quiz_pin'";
        $checkquiz=mysqli_query($con,$checkquiz_sql);
        if($row=mysqli_fetch_assoc($checkquiz)){
            echo "<script>
            alert('ERROR when creating quiz! Quiz pin Existed!');
            window.location='content_admin_quiz.php';</script>";
        }
        else{
            // numerous error checking
            $num_arr=['0','1','2','3','4','5','6','7','8','9'];
            if(empty($quiz_pin) || empty($quiz_name) || empty($quiz_level) || strlen($quiz_pin)>10 || strlen($quiz_level)>1 
            || !in_array($quiz_level,$num_arr)){
                echo "<script>
                alert('ERROR when creating quiz! Something is not right!');
                window.location='content_admin_quiz.php';</script>";
            }else{
                $current_time=getdate();
                $date_time=$current_time['year']."-".$current_time['mon']."-".$current_time['mday'];
                $addquiz_sql="INSERT INTO quiz(quiz_pin_number,quiz_name,quiz_content,quiz_level,quiz_status,quiz_time_stamp,user_id) 
                              VALUES('$quiz_pin','$quiz_name','$quiz_content','$quiz_level','private','$date_time','$user_id')";
                $addquestoquiz=mysqli_query($con,$addquiz_sql);
                if($addquestoquiz){
                    echo "<script>
                    alert('Quiz successfully created!');
                    window.location='content_admin_quiz.php';</script>";
                }else{
                    echo "<script>
                    alert('ERROR when creating quiz! Make sure all value entered are within the boundary!');
                    window.location='content_admin_quiz.php';</script>";
                }
            }   
            
        }
    }else{
        echo "<script>
        alert('ERROR when creating quiz! No question are selected!');
        window.location='content_admin_quiz.php';</script>";
    }
    