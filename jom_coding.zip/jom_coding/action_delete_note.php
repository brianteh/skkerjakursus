<?php
    session_start();
    // delete note 
    $uid=$_SESSION['userID'];
    require 'connect_database.php';
    $id=$_REQUEST['note_id'];
    $topic=$_REQUEST['note_topic'];
    $title=$_REQUEST['note_title'];
    $keyword=$_REQUEST['note_keyword'];
    $delete_note="DELETE FROM note WHERE note_id=? AND note_topic=? AND note_title=? AND note_keyword=? AND user_id=? ";
    $deleting_note=mysqli_stmt_init($con);
    if(mysqli_stmt_prepare($deleting_note,$delete_note)){
        mysqli_stmt_bind_param($deleting_note,"isssi",$id,$topic,$title,$keyword,$uid);
        mysqli_stmt_execute($deleting_note);
        echo 'success';
    }else{
        echo 'error';
    }
    header('Location:../jom_coding/content_admin_note.php');