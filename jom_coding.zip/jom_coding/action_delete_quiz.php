<?php
session_start();
    // delete quiz
    $uid=$_SESSION['userID'];
    require 'connect_database.php';
    $pin=$_REQUEST['quiz_pin_number'];
    $name=$_REQUEST['quiz_name'];
    $content=$_REQUEST['quiz_content'];
    $delete_result="DELETE FROM result WHERE quiz_pin_number='$pin'";
    $deleting_result=mysqli_query($con,$delete_result);
    if($deleting_result){
        $delete_quiz="DELETE FROM quiz WHERE quiz_pin_number=? AND quiz_name=? AND quiz_content=? AND user_id=? ";#HERE
        $deleting_quiz=mysqli_stmt_init($con);
        if(mysqli_stmt_prepare($deleting_quiz,$delete_quiz)){
            mysqli_stmt_bind_param($deleting_quiz,"sssi",$pin,$name,$content,$uid);
            mysqli_stmt_execute($deleting_quiz);
            echo 'success';
        }else{
            echo 'error';
        }
    }
    header('Location:../jom_coding/content_admin_quiz.php');