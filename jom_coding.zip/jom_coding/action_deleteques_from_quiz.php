<?php
    session_start();
    // delete question from quiz directory
    if(isset($_REQUEST['ques_id'])){
        $delete_list=array_diff($_SESSION['chosen_quiz_content'],[$_REQUEST['ques_id']]);
        $_SESSION['chosen_quiz_content']=array();
        foreach($delete_list as $d){
            array_push($_SESSION['chosen_quiz_content'],$d);
        }
    }
    header("Location:../jom_coding/content_admin_quiz.php");
