<?php
    session_start();
    // update note
    require 'connect_database.php';
    $topic=$_POST['topic'];
    $title=$_POST['title'];
    $keyword=$_POST['keyword'];
    $content=$_POST['content'];
    $id=$_POST['id'];
    $uid=$_SESSION['userID'];
    $update_note="UPDATE note SET note_topic='$topic',note_title='$title',note_keyword='$keyword',note_content='$content' WHERE note_id='$id' AND user_id='$uid'";
    $updating_note=mysqli_query($con,$update_note);
    if($updating_note){
        echo "success";
    }else{
        echo "error";
    }