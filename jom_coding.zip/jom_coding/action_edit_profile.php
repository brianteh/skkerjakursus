<?php
session_start();
// check if uploaded profile photo is valid
require 'connect_database.php';
if(isset($_POST['change_profile'])){
    if($_SESSION['temp_pic']!=$_SESSION['profile_pic']){
        unlink("user_photo/".$_SESSION['temp_pic']);
    }
    $file=$_FILES['profile_photo_upload'];
    $fileName=$_FILES['profile_photo_upload']['name'];
    $fileTmp=$_FILES['profile_photo_upload']['tmp_name'];
    $fileType=$_FILES['profile_photo_upload']['type'];
    $fileError=$_FILES['profile_photo_upload']['error'];
    $fileSize=$_FILES['profile_photo_upload']['size'];
    $fileExt=explode(".",$fileName);
    $fileExt=strtolower(end($fileExt));
    $allowed=array('png','jpeg','jpg','gif');
    if(in_array($fileExt,$allowed)){
        if($fileError===0){
            if($fileSize <500000){
                // unique id to ensure non similar name for profile picture
                $fileNameNew=uniqid('',true).".".$fileExt;
                $fileDestination="user_photo/".$fileNameNew;
                if(move_uploaded_file($fileTmp,$fileDestination)){
                    $_SESSION['temp_pic']=$fileNameNew;
                    header("Location:../jom_coding/content_profile.php?error=none"); 
                }else{
                    header("Location:../jom_coding/content_profile.php?error=upload"); 
                }
            }else{
                header("Location:../jom_coding/content_profile.php?error=upload"); 
            }
        }else{
            header("Location:../jom_coding/content_profile.php?error=upload"); 
        }
    }else{
        header("Location:../jom_coding/content_profile.php?error=upload"); 
    }
}