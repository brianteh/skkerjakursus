<?php
session_start();
// update profile
require 'connect_database.php';
if(isset($_POST['change_btn'])){
    $uid=$_SESSION['userID'];
    $pic=$_SESSION['temp_pic'];
    $user_form=$_POST['form'];
    $update_sql="UPDATE pme_user SET user_pic='$pic',user_form='$user_form' WHERE user_id='$uid'";
    $updating_sql=mysqli_query($con,$update_sql);
    if($updating_sql){
        $_SESSION['form']=$user_form;
        // delete previous profile photo
        unlink('user_photo/'.$_SESSION['profile_pic']);
        $_SESSION['profile_pic']=$pic;
        header("Location:../jom_coding/content_profile.php?error=none"); 
    }else{
        header("Location:../jom_coding/content_profile.php?error=upload"); 
    }
}
