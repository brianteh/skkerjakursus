<?php
session_start();
// update question
require 'connect_database.php';
$uid=$_SESSION['userID'];
$id=$_POST['ques_id'];
$topic=$_POST['topic'];
$content=$_POST['content'];
$answer=$_POST['answer'];
$select=$_POST['select'];
$type=$_POST['type'];
$level=$_POST['level'];
$pic=$_SESSION['temp_ques_pic'.$id];
$update_sql="UPDATE question SET question_topic='$topic',question_level='$level',question_content='$content',question_answer='$answer',question_select='$select',question_picture='$pic' WHERE question_id='$id' AND user_id='$uid'";
$updating_sql=mysqli_query($con,$update_sql);
if($updating_sql){
    if($_SESSION['temp_ques_pic'.$id]!=$_SESSION['ques_pic'.$id]){
        // delete previous question photo
        unlink('question_photo/'.$_SESSION['ques_pic'.$id]);
    }
    $_SESSION['temp_ques_pic'.$id]=$pic;
    echo "error";
}else{
    echo "error";
}

