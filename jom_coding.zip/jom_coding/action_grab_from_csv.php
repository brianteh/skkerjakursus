<?php
// grab question data from .csv format
require 'connect_database.php';
$file_csv=fopen("question_csv/".$_SESSION['imported_ques_csv'],"r");
while(($data = fgetcsv($file_csv, 100000000, ",")) !== FALSE){
    $user_id=$_SESSION['userID'];
    $sql="INSERT INTO question(question_topic,question_content,question_answer,question_status,question_select,question_level,
          question_type,question_time_limit,question_picture,user_id) 
          VALUES('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','-','$user_id')";
    $insert_question=mysqli_query($con,$sql);
    if($insert_question){
        echo "<script type='text/javascript'>alert(\"Success!\");window.location='content_admin_question.php';</script>";
    }else{
        echo "<script type='text/javascript'>alert(\"Error!\");window.location='content_admin_question.php';</script>";
    }
}
fclose($file_csv);
// delete temporary csv after entering question data to database
unlink("question_csv/".$_SESSION['imported_ques_csv']);