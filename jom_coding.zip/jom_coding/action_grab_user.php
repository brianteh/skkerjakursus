<?php
// grab user data in .csv format
require 'connect_database.php';
$file_csv=fopen("bot/".$_SESSION['imported_user_csv'],"r");
while(($data = fgetcsv($file_csv, 100000000, ",")) !== FALSE){
    $uid=$data[0];
    $mail=$data[1];
    $pwd=$data[2];
    $status=$data[3];
    $age=$data[4];
    $pic="-";
    $cid=$_SESSION['class_id'];
    if(empty($uid) || empty($mail) || empty($pwd)){
        echo 
        "<script type='text/javascript'>
            alert(\"Error in importing user in csv format.\");
            window.location.href='content_admin_student.php';
        </script>";
    }else if(!filter_var($mail,FILTER_VALIDATE_EMAIL)){
        echo 
        "<script type='text/javascript'>
            alert(\"Error in importing user in csv format.\");
            window.location.href='content_admin_student.php';
        </script>";
    }
    else{
        // check if username exists or not
        $sql="SELECT username FROM pme_user WHERE username=?";
        $stmt=mysqli_stmt_init($con);
        if (!mysqli_stmt_prepare($stmt,$sql)){
            echo 
            "<script type='text/javascript'>
                alert(\"Error in importing user in csv format.\");
                window.location.href='content_admin_student.php';
            </script>";
        }
        else{
            mysqli_stmt_bind_param($stmt,"s",$uid);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $usernameCheck=mysqli_stmt_num_rows($stmt);
            if($usernameCheck > 0){
                echo 
                "<script type='text/javascript'>
                    alert(\"Error in importing user in csv format.\");
                    window.location.href='content_admin_student.php';
                </script>";
            }
            else{
                // check if user mail exists or not
                $sql="SELECT user_email FROM pme_user WHERE user_email=? ";
                $stmt=mysqli_stmt_init($con);
                if (!mysqli_stmt_prepare($stmt,$sql)){
                    echo 
                    "<script type='text/javascript'>
                        alert(\"Error in importing user in csv format.\");
                        window.location.href='content_admin_student.php';
                    </script>";
                }
                else{
                    mysqli_stmt_bind_param($stmt,"s",$mail);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);
                    $usermailCheck=mysqli_stmt_num_rows($stmt);
                    if($usermailCheck > 0){
                        echo 
                        "<script type='text/javascript'>
                            alert(\"Error in importing user in csv format.\");
                            window.location.href='content_admin_student.php';
                        </script>";
                    }
                    else{
                        // search if class exists or not
                        $find_class="SELECT * FROM pme_class WHERE class_id='$cid'";
                        $finding_class=mysqli_query($con,$find_class);
                        $num=mysqli_num_rows($finding_class);
                        if(!($num>0)){
                            echo 
                            "<script type='text/javascript'>
                                alert(\"Error in importing user in csv format.\");
                                window.location.href='content_admin_student.php';
                            </script>";
                        }else{
                            $row=mysqli_fetch_array($finding_class);
                            $class_num=$row['class_num'];
                        }
                        // insert user to database
                        $sql="INSERT INTO pme_user (username,user_email,user_password,acc_status,user_form,user_pic,class_id) VALUES(?,?,?,?,?,?,?)";#CHANGE
                        $stmt=mysqli_stmt_init($con);
                        if (!mysqli_stmt_prepare($stmt,$sql)){
                            echo 
                            "<script type='text/javascript'>
                                alert(\"Error in importing user in csv format.\");
                                window.location.href='content_admin_student.php';
                            </script>";
                        }
                        else{
                            // hash pasword
                            $hashed_pwd=password_hash($pwd,PASSWORD_DEFAULT);
                            mysqli_stmt_bind_param($stmt,"ssssiss",$uid,$mail,$hashed_pwd,$status,$age,$pic,$cid);
                            mysqli_stmt_execute($stmt);

                            // update number of participant in class
                            $class_num+=1;
                            $update_class="UPDATE pme_class SET class_num='$class_num' WHERE class_id='$cid'";
                            $updating_class=mysqli_query($con,$update_class);
                            if(!$updating_class){
                                echo 
                                "<script type='text/javascript'>
                                    alert(\"Error in importing user in csv format.\");
                                    window.location.href='content_admin_student.php';
                                </script>";
                            }
                           
                        }

                    }
                    
                }
            }
        }
    }
    mysqli_stmt_close($stmt);
    mysqli_close($con);
}
fclose($file_csv);
// delete temporary csv after entering user data to database
unlink("bot/".$_SESSION['imported_user_csv']);
?>