<?php
session_start();
// import question in .csv format
$file=$_FILES['import_csv'];
$fileName=$_FILES['import_csv']['name'];
$fileTmp=$_FILES['import_csv']['tmp_name'];
$fileType=$_FILES['import_csv']['type'];
$fileError=$_FILES['import_csv']['error'];
$fileSize=$_FILES['import_csv']['size'];
$fileExt=explode(".",$fileName);
$fileExt=strtolower(end($fileExt));
$allowed=array('csv');
if(isset($_POST['btn_import_csv'])){
    if(in_array($fileExt,$allowed)){
        if($fileError===0){
            if($fileSize <500000 && $fileSize>0){
                $fileNameNew=uniqid('',true).".".$fileExt;
                $fileDestination="question_csv/".$fileNameNew;
                if(move_uploaded_file($fileTmp,$fileDestination)){
                    $_SESSION['imported_ques_csv']=$fileNameNew;
                    require 'action_grab_from_csv.php';
                }else{
                    // error message is shown
                    echo 
                    "<script type='text/javascript'>
                        alert(\"Error in uploading question in csv format.\");
                        window.history.back();
                    </script>";
                }
            }else{
                // error message is shown
                echo 
                "<script type='text/javascript'>
                    alert(\"Error in uploading question in csv format.\");
                    window.history.back();
                </script>";
            }
        }else{
            // error message is shown
            echo 
            "<script type='text/javascript'>
                alert(\"Error in uploading question in csv format.\");
                window.history.back();
            </script>";
        }
    }else{
        // error message is shown
        echo 
        "<script type='text/javascript'>
            alert(\"Error in uploading question in csv format.\");
            window.history.back();
        </script>";
    }
}
?>