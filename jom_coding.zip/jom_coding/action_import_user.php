<?php
session_start();
// import user in .csv format
$file=$_FILES['import_user'];
$fileName=$_FILES['import_user']['name'];
$fileTmp=$_FILES['import_user']['tmp_name'];
$fileType=$_FILES['import_user']['type'];
$fileError=$_FILES['import_user']['error'];
$fileSize=$_FILES['import_user']['size'];
$fileExt=explode(".",$fileName);
$fileExt=strtolower(end($fileExt));
$allowed=array('csv');
if(isset($_POST['btn_import_user'])){
    if(in_array($fileExt,$allowed)){
        if($fileError===0){
            if($fileSize <500000 && $fileSize>0){
                $fileNameNew=uniqid('',true).".".$fileExt;
                $fileDestination="bot/".$fileNameNew;
                if(move_uploaded_file($fileTmp,$fileDestination)){
                    $_SESSION['imported_user_csv']=$fileNameNew;
                    require 'action_grab_user.php';
                    echo 
                    "<script type='text/javascript'>
                        alert(\"Successful in importing user in csv format.\");
                        window.history.back();
                    </script>";
                }else{
                    echo 
                    "<script type='text/javascript'>
                        alert(\"Error in importing user in csv format.\");
                        window.history.back();
                    </script>";
                }
            }else{
                echo 
                "<script type='text/javascript'>
                    alert(\"Error in importing user in csv format.\");
                    window.history.back();
                </script>";
            }
        }else{
            echo 
            "<script type='text/javascript'>
                alert(\"Error in importing user in csv format.\");
                window.history.back();
            </script>";
        }
    }else{
        echo 
        "<script type='text/javascript'>
            alert(\"Error in importing user in csv format.\");
            window.history.back();
        </script>";
    }
}
?>
