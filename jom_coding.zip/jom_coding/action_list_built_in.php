<?php
        require "connect_database.php";
        // handling question sequence & answer scheme
        $target_topic=$_SESSION['quiz_topic'];
        $target_form=$_SESSION['form'];
        $grab_question="SELECT * FROM question WHERE question_topic='$target_topic' AND question_level<=".$target_form;
        $show_question=mysqli_query($con,$grab_question);
        $list_of_all=array();
        $list_of_content=array();
        $list_of_answer=array();
        $list_of_type=array();
        $list_of_select=array();
        $list_of_picture=array();
        $list_of_id=array();
        $list_of_time_limit=array();
        date_default_timezone_set('Asia/Colombo');
        while($row=mysqli_fetch_array($show_question)){
            $question_id=$row['question_id'];
            $question_content=$row['question_content'];
            $question_answer=$row['question_answer'];
            $question_type=$row['question_type'];
            $question_select=$row['question_select'];
            $question_picture=$row['question_picture'];
            $question_time_limit=$row['question_time_limit'];
            array_push($list_of_all,$question_content.">".$question_answer.">".$question_type.">".$question_select.">".$question_picture.">".$question_id.">".$question_time_limit);
            
        }
        shuffle($list_of_all);
        foreach($list_of_all as $i){
            $list=preg_split("/>/",$i);
            array_push($list_of_content,$list[0]);
            array_push($list_of_answer,$list[1]);
            array_push($list_of_type,$list[2]);
            array_push($list_of_select,$list[3]);
            array_push($list_of_picture,$list[4]);
            array_push($list_of_id,$list[5]);
            array_push($list_of_time_limit,$list[6]);
        }
        $_SESSION['question_list']=$list_of_content;
        $_SESSION['question_answer']=$list_of_answer;
        $_SESSION['question_type']=$list_of_type;
        $_SESSION['question_select']=$list_of_select;
        $_SESSION['question_picture']=$list_of_picture;
        $_SESSION['question_seq']=$list_of_id;
        $_SESSION['question_time_limit']=$list_of_time_limit;
        $_SESSION['timer']=time();
        $_SESSION['current_answer_list']=array();
        
            
?>