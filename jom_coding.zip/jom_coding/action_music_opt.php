<?php
session_start();
// set quiz music
$_SESSION['music']=$_POST['music'];