<?php
    session_start();
    $_SESSION['quiz_outcome']=false;
    $_SESSION['wrong_answer_list']=array();
    $points=0;
    // alternative way $answer_check=array_intersect_assoc($_SESSION['question_answer'],$_SESSION['current_answer_list']);
    for($i=0;$i<sizeof($_SESSION['current_answer_list']);$i++){
        if($_SESSION['current_answer_list'][$i]==$_SESSION['question_answer'][$i]){
            $points+=1;
        }else{
            array_push($_SESSION['wrong_answer_list'],$_SESSION['question_seq'][$i]);
        }
    }

    // showing result as in default html
    $_SESSION['result_score']=$points;
    $_SESSION['result_accuracy']=round(($points/sizeof($_SESSION['current_answer_list']))*100,2);
    if($_SESSION['result_accuracy']>=50){
        $_SESSION['quiz_outcome']=true;
    }
    $_SESSION['result_accuracy']=$_SESSION['result_accuracy']."%";
    echo "<br>";
    print_r($_SESSION['result_score']);
    echo "<br>";
    echo $_SESSION['time_used'];
    echo "<br>";
    echo $_SESSION['result_accuracy'];
    echo "<br>";
    print_r($_SESSION['wrong_answer_list']);
    echo "<br>";
    print_r($_SESSION['current_answer_list']);
    echo "<br>";
    // converting the wrong answer list into a string format
    $wrong_answer_string="";
    for($i=0;$i<count($_SESSION['wrong_answer_list']);$i++){
        if($i==count($_SESSION['wrong_answer_list'])-1){
            $wrong_answer_string=$wrong_answer_string.$_SESSION['wrong_answer_list'][$i];
        }else{
            $wrong_answer_string=$wrong_answer_string.$_SESSION['wrong_answer_list'][$i].",";
        }
    }
    $_SESSION['wrong_answer_list']=$wrong_answer_string;


    

    // constant info of user
    $user_id=$_SESSION['userID'];
    $result_score=$_SESSION['result_score'];
    $result_accuracy=$_SESSION['result_accuracy'];
    $result_time_used=$_SESSION['time_used'];
    $result_wrong_question=$wrong_answer_string;
    $current_time=getdate();
    $day=(int)$current_time['mday'];
    $month=(int)$current_time['mon'];
    if($day<10){
        $day=(string)$day;
        $day="0".$day;
    }else{
        $day=(string)($day);
    }
    if($month<10){
        $month=(string)$month;
        $month="0".$month;
    }
    $date_time=$current_time['year']."-".$month."-".$day;
    $hour=(int)$current_time['hours'];
    $hour=$hour+6;
    $hour=$hour%24;
    if($hour<10){
        $hour=(string)$hour;
        $hour="0".$hour.":00:00";
    }else{
        $hour=(string)$hour;
        $hour=$hour.":00:00";
    }
    print_r($current_time);
    echo "<br>";
    echo $date_time;
    $sec=$current_time['seconds'];
    if($sec<10){
        $sec="0".$sec;
    }
    $date = $date_time." ".(int)($current_time['hours']+6).":".$current_time['minutes'].":".$sec;
    echo $date;


    
    // handling builtin & custom quiz result
    require 'connect_database.php';

    if($_SESSION['quiz_type']=="builtin"){
        header('Location:../jom_coding/content_finalR.php');
    }else if($_SESSION['quiz_type']=="custom"){
        $quiz_id=$_SESSION['quiz_code'];
        $update_result="INSERT INTO result(`user_id`,`date_time`,`hour_time`,`utc_time`,`quiz_pin_number`,`result_score`,`result_accuracy`,`result_time_used`,`result_wrong_question`) 
        VALUES('$user_id','$date_time','$hour','$date','$quiz_id','$result_score','$result_accuracy','$result_time_used','$result_wrong_question')";
        $updating_result=mysqli_query($con,$update_result);
        if($updating_result){
            header('Location:../jom_coding/content_finalR.php');
        }
        else{
            echo "sql error";
        }
    }
    
    

    
    
    
    
    
