<?php
    session_start();
    require 'connect_database.php';
    // processes built-in and custom quiz request
    if(isset($_POST['built-in-btn'])){
        $topic=$_POST['topic'];
        if(!empty($topic)){
            $_SESSION['quiz_topic']=$topic;
            $_SESSION['quiz_type']="builtin";
        }            
        require "action_list_built_in.php";
        $_SESSION['count_down_sec']=$_SESSION['question_time_limit'][0]; 
        header("Location:../jom_coding/content_quizizz.php");
        exit();
    }else if(isset($_POST['custom-btn'])){
        $quiz_choice=$_POST['quiz_code'];
        if(!empty($quiz_choice)){
            $_SESSION['quiz_code']=$quiz_choice;
            $_SESSION['quiz_type']="custom";
        }else{
            header("Location:../jom_coding/content_quiz.php?page=1&error=1"); 
        }
        require "action_list_custom.php";
        $_SESSION['count_down_sec']=$_SESSION['question_time_limit'][0];
        header("Location:../jom_coding/content_quizizz.php");
        exit();
    }
   