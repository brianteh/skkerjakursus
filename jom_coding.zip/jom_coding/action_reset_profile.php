<?php
    session_start();
    // reset newly uploaded profle photo
    if($_SESSION['temp_pic']!==$_SESSION['profile_pic']){
        unlink("user_photo/".$_SESSION['temp_pic']);
    }
    $_SESSION['temp_pic']=$_SESSION['profile_pic'];
    header("Location:../jom_coding/content_profile.php?error=none");