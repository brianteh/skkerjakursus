<?php
session_start();
// reset newly entered data in edit_ques_page.php
if($_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]!=$_SESSION['ques_pic'.$_REQUEST['ques_id']]){
    unlink("question_photo/".$_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]);
}
$_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]=$_SESSION['ques_pic'.$_REQUEST['ques_id']];
header("Location:../jom_coding/edit_ques_page.php?ques_id=".$_REQUEST['ques_id']."&type=".$_REQUEST['type']);