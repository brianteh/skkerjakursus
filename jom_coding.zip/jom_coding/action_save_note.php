<?php
    session_start();
    // save note
    require 'connect_database.php';
    $topic=$_POST['ntopic'];
    $title=$_POST['ntitle'];
    $content=$_POST['ncontent'];
    $uid=$_SESSION['userID'];
    $keyword=$_POST['nkeyword'];
    // check for error
    if(empty($topic) || empty($title) || empty($content) || empty($uid) || empty($keyword)){
        echo "error";
    }else{
        $save_note="INSERT INTO note (note_topic,note_title,note_content,user_id,note_status,note_keyword) 
                    VALUES('$topic','$title','$content','$uid','private','$keyword')";
        $saving_note=mysqli_query($con,$save_note);
        if($saving_note){
            echo "success";
        }else{
            echo "error";
        }
    }
        
    
   