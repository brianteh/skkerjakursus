<?php
session_start();
// processes search quiz request
if(isset($_POST['search_quiz'])){
    $_SESSION['search_quiz']=$_POST['search_quiz'];
}else{
    $_SESSION['search_quiz']="";
}
header("Location:../jom_coding/content_admin_quiz.php");