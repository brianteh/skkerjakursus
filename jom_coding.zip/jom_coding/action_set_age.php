<?php
    session_start();
    // set age
    $_SESSION['age']=$_POST['age'];
    echo "success";