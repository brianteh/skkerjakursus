<?php
    session_start();
    // set view status in content_admin_statistics.php
    $_SESSION['chose_overall_stat']=$_POST['overall_stat'];
    echo "ok";