<?php
    session_start();
    // set quiz pin for viewing
    $_SESSION['chose_quiz_pin']=$_POST['quiz_pin'];
    echo "ok";