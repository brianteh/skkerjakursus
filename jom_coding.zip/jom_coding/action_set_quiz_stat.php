<?php
    session_start();
    // set quiz status for viewing
    $_SESSION['chose_quiz_stat']=$_POST['quiz_stat'];
    echo "ok";