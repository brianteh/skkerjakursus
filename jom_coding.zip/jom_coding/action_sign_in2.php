<?php
    require "connect_database.php";
    
if(isset($_POST['sign_in_btn'])){
    $in_uid=$_POST['uid'];
    $password=$_POST['password'];
    if (empty($in_uid) || empty($password)){
        header("Location:../jom_coding/content_sign_in.php?error=emptyfields");
        exit();
    }
    else{
        // compare credentials in database with the input given
        $sql="SELECT user_id,username,user_form,user_email,user_password,acc_status,user_pic,class_id 
              FROM pme_user WHERE username=? OR user_email=? ";
        $stmt=mysqli_prepare($con,$sql);
        if(!$stmt){
            header("Location:../jom_coding/content_sign_in.php?error=sqlerror");
            exit();
        }
        else{
            mysqli_stmt_bind_param($stmt,"ss",$in_uid,$in_uid);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt,$user_id,$username,$user_form,$user_email,$user_password,$acc_status,$user_pic,$class_id);
            if(mysqli_stmt_fetch($stmt)){
                // verify password
                $pwdCheck=password_verify($password,$user_password);
                if($pwdCheck==false){
                    header("Location:../jom_coding/content_sign_in.php?error=invalidpwd");
                    exit();

                }
                else if($pwdCheck==true){
                    session_start();
                    // set all user data as session variables for further usage
                    $_SESSION['userID']=$user_id;
                    $_SESSION['username']=$username;
                    $_SESSION['user_email']=$user_email;
                    $_SESSION['form']=$user_form;
                    $_SESSION['acc_status']=$acc_status;
                    $_SESSION['profile_pic']=$user_pic;
                    $_SESSION['temp_pic']=$_SESSION['profile_pic'];
                    $_SESSION['toggle-music']=true;
                    $_SESSION['class_id']=$class_id;
                    if($_SESSION['acc_status']=="admin"){
                        $_SESSION['chosen_quiz_content']=array();
                    }
                    $_SESSION['music']="cyberpunk";
                    $_SESSION['theme']="space";
                    $_SESSION['log_status']=1;
                    header("Location:../jom_coding/content_home.php");
                    exit();

                }
                else{
                    header("Location:../jom_coding/content_sign_in.php?error=invalidpwd");
                    exit();

                }

            }
        }
    }
    header("Location:../jom_coding/content_sign_in.php?error=invalidpwd&username");
    exit();
}
else{
    header("Location:../jom_coding/content_sign_in.php");
}