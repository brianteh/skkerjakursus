<?php 
    session_start();
    // destroy all session variables for logging out
    unset($_SESSION['userID']);
    unset($_SESSION['username']);
    unset($_SESSION['user_email']);
    unset($_SESSION['log_status']);
    session_unset();
    header("Location:../jom_coding/content_sign_in.php?page=none");