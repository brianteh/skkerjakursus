<?php
    require "connect_database.php";
if(isset($_POST['sign_up_btn']))
{
    $uid=$_POST['uid'];
    $mail=$_POST['mail'];
    $pwd=$_POST['pwd'];
    $r_pwd=$_POST['r_pwd'];
    $status=$_POST['status'];
    $age=$_POST['age'];
    $pic="default_avatar.png";
    $cls_id=$_POST['cls_id'];
    $cls_name=$_POST['cls_name'];
    $signUp="none";
    
    // check validity of user (username,email)
    if(empty($uid) || empty($mail) || empty($pwd) || empty($r_pwd)){
        $signUp="empty field";
        echo "<script type='text/javascript'>alert('Error:".$signUp."');window.location='content_sign_up.php?error=".$signUp."';</script>";
    }else if(!filter_var($mail,FILTER_VALIDATE_EMAIL)){
        $signUp="invalid email";
        echo "<script type='text/javascript'>alert('Error:".$signUp."');window.location='content_sign_up.php?error=".$signUp."';</script>";
    }
    else if($pwd !== $r_pwd){
        $signUp="Password does not match";
        echo "<script type='text/javascript'>alert('Error:".$signUp."');window.location='content_sign_up.php?error=".$signUp."';</script>";
    }
    else{
        $sql="SELECT username FROM pme_user WHERE username=?";
        $stmt=mysqli_stmt_init($con);
        if (!mysqli_stmt_prepare($stmt,$sql)){
            $signUp="SQL error";
            echo "<script type='text/javascript'>alert('Error:".$signUp."');window.location='content_sign_up.php?error=".$signUp."';</script>";
        }
        else{
            mysqli_stmt_bind_param($stmt,"s",$uid);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $usernameCheck=mysqli_stmt_num_rows($stmt);
            if($usernameCheck > 0){
                $signUp="Username taken";
                echo 
                "<script type='text/javascript'>alert('Error:".$signUp."');
                window.location='content_sign_up.php?error=".$signUp."';</script>";
            }
            else{
                $sql="SELECT user_email FROM pme_user WHERE user_email=? ";
                $stmt=mysqli_stmt_init($con);
                if (!mysqli_stmt_prepare($stmt,$sql)){
                    $signUp="SQL error";
                    echo 
                    "<script type='text/javascript'>alert('Error:".$signUp."');
                    window.location='content_sign_up.php?error=".$signUp."';</script>";
                }
                else{
                    mysqli_stmt_bind_param($stmt,"s",$mail);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);
                    $usernameCheck=mysqli_stmt_num_rows($stmt);
                    if($usernameCheck > 0){
                        $signUp="User email taken";
                        echo 
                        "<script type='text/javascript'>alert('Error:".$signUp."');
                        window.location='content_sign_up.php?error=".$signUp."';</script>";
                    }
                    else{
                        // insert user info into database
                        $sql="INSERT INTO pme_user (username,user_email,user_password,acc_status,user_form,user_pic,class_id) 
                              VALUES(?,?,?,?,?,?,?)";
                        $stmt=mysqli_stmt_init($con);
                        if (!mysqli_stmt_prepare($stmt,$sql)){
                            $signUp="SQL error";
                            echo 
                            "<script type='text/javascript'>alert('Error:".$signUp."');
                            window.location='content_sign_up.php?error=".$signUp."';</script>";
                        }
                        else{
                            // check validity of class related info
                            $grab_class="SELECT * FROM pme_class WHERE class_id='$cls_id'";
                            $grabbing_class=mysqli_query($con,$grab_class);
                            if(mysqli_num_rows($grabbing_class)){
                                $row=mysqli_fetch_array($grabbing_class);
                                $num=$row['class_num']+1;
                                $update_class="UPDATE pme_class SET class_num='$num' WHERE class_id='$cls_id'";
                                $updating_class=mysqli_query($con,$update_class);
                                if(!$updating_class){
                                    $signUp="updateclass";
                                }
                            }else{
                                if($cls_name=="-" || strlen($cls_name)>25 || empty($cls_name) || strlen($cls_id)>11 || empty($cls_id)){
                                    $signUp="Invalid class settings";
                                    echo 
                                    "<script type='text/javascript'>alert('Error:".$signUp."');
                                    window.location='content_sign_up.php?error=".$signUp."';</script>";
                                }
                                // create new class
                                $date=date("Y-m-d");
                                $time=explode(":",date("h:i:s"));
                                if($time[0][0]=="0"){
                                    $time[0]=(int)($time[0][1])+8;
                                    if($time[0]<10){
                                        $time[0]="0".$time[0];
                                    }
                                }else if((int)($time[0])+8>24){
                                    $time[0]=(((int)($time[0])+8)%24);
                                    if($time[0]<10){
                                        $time[0]="0".$time[0];
                                    }
                                }
                                $final_time=$time[0].":".$time[1].":".$time[2];
                                $final_date_time=$date." ".$final_time;

                                $insert_class="INSERT INTO pme_class (class_id,class_name,class_num,class_date_time) 
                                               VALUES('$cls_id','$cls_name',1,'$final_date_time')";
                                $inserting_class=mysqli_query($con,$insert_class);
                                if(!$inserting_class){
                                    $signUp="createclass";
                                }
                            }
                            // hash password for security
                            $hashed_pwd=password_hash($pwd,PASSWORD_DEFAULT);
                            mysqli_stmt_bind_param($stmt,"ssssiss",$uid,$mail,$hashed_pwd,$status,$age,$pic,$cls_id);
                            mysqli_stmt_execute($stmt);
                            if($signUp=="none"){
                                echo 
                                "<script type='text/javascript'>alert('Sign up Successful!');
                                window.location='content_sign_in.php';</script>";
                            }
                            else{
                                echo 
                                "<script type='text/javascript'>alert('Error:".$signUp."');
                                window.location='content_sign_up.php?error=".$signUp."';</script>";
                            }
                             
                        }

                    }
                    
                }
            }
        }
    }
    mysqli_stmt_close($stmt);
    mysqli_close($con);
}
else{
    header("Location:../jom_coding/content_sign_up.php?error=invalid&page=2 ");
    exit();
}
    


