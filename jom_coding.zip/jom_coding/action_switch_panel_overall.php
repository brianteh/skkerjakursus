<?php
    session_start();
    // set orientation of overall statistics panel
    if($_SESSION['overall_main']==0){
        $_SESSION['overall_main']=1;
    }else if($_SESSION['overall_main']==1){
        $_SESSION['overall_main']=2;
    }else if($_SESSION['overall_main']==2){
        $_SESSION['overall_main']=0;
    }
    echo "success";