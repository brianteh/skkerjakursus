<?php
    // set status of question (public/private) via ajax request
    require 'connect_database.php';
    $id=$_POST['ques_id'];
    $stat=$_POST['current'];
    if($stat=="private"){
        $final_stat="public";
    }else if($stat=="public"){
        $final_stat="private";
    }
    $reset_stat="UPDATE question SET question_status='$final_stat' WHERE question_id='$id'";
    $resetting_stat=mysqli_query($con,$reset_stat);
    if($resetting_stat){
        echo "success";
    }else{
        echo "error";
    }