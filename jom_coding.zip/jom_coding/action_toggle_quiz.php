<?php
    // set status of quiz (public/private) via ajax request
    require 'connect_database.php';
    $id=$_POST['quiz_id'];
    $stat=$_POST['current'];
    if($stat=="private"){
        $final_stat="public";
    }else if($stat=="public"){
        $final_stat="private";
    }
    $reset_stat="UPDATE quiz SET quiz_status='$final_stat' WHERE quiz_pin_number='$id'";
    $resetting_stat=mysqli_query($con,$reset_stat);
    if($resetting_stat){
        echo "success";
    }else{
        echo "error";
    }