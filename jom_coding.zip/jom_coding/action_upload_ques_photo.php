<?php
session_start();
// update question photo
require 'connect_database.php';
if(isset($_POST['change_ques'])){
    if($_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]!=$_SESSION['ques_pic'.$_REQUEST['ques_id']]){
        unlink("question_photo/".$_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]);
    }
    $file=$_FILES['ques_photo_upload'];
    $fileName=$_FILES['ques_photo_upload']['name'];
    $fileTmp=$_FILES['ques_photo_upload']['tmp_name'];
    $fileType=$_FILES['ques_photo_upload']['type'];
    $fileError=$_FILES['ques_photo_upload']['error'];
    $fileSize=$_FILES['ques_photo_upload']['size'];
    $fileExt=explode(".",$fileName);
    $fileExt=strtolower(end($fileExt));
    $allowed=array('png','jpeg','jpg','gif');
    if(in_array($fileExt,$allowed)){
        if($fileError===0){
            if($fileSize <500000){
                // unique id to ensure no similar photo names
                $fileNameNew=uniqid('',true).".".$fileExt;
                $fileDestination="question_photo/".$fileNameNew;
                if(move_uploaded_file($fileTmp,$fileDestination)){
                    $_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]=$fileNameNew;
                    echo "success";
                    header("Location:../jom_coding/edit_ques_page.php?ques_id=".$_REQUEST['ques_id']."&type=".$_REQUEST['type']);
                }else{
                   echo "error";
                 
                }
            }else{
                echo "error";
               
            }
        }else{
           echo "error";
           
        }
    }else{
       echo "error";
      
    }
}