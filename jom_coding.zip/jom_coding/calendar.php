<?php
//get current date
$current_date=getdate();
$filename = 'calendar/calendar.csv';
$_SESSION['date_list']= []; 

// grab data from calendar.csv
if (($calendar = fopen("{$filename}", "r")) !== FALSE) 
{
  while (($data = fgetcsv($calendar, 1000, ",")) !== FALSE) 
  {
    $_SESSION['date_list'][]=$data;		
  }
  fclose($calendar);
}
$last=count($_SESSION['date_list'])-1;

// grab creation timestamp of quiz
require 'connect_database.php';
$uid=$_SESSION['userID'];
$grab_earliest="SELECT quiz.quiz_time_stamp,quiz.user_id FROM quiz WHERE quiz.user_id='$uid' ORDER BY quiz.quiz_time_stamp DESC";
$grabbing_earliest=mysqli_query($con,$grab_earliest);
if($grabbing_earliest){
    while($row=mysqli_fetch_array($grabbing_earliest)){
      $earl=$row['quiz_time_stamp'];
    }  
}
// processes date and time
$day=(int)$current_date['mday'];
$month=(int)$current_date['mon'];
if($day<10){
    $day=(string)$day;
    $day="0".$day;
}else{
    $day=(string)($day);
}
if($month<10){
    $month=(string)$month;
    $month="0".$month;
}
else{
  $month=(string)$month;
}
$late=$current_date['year']."-".$month."-".$day;

// set range of time for statistics panel
$_SESSION['ending_point']=$late;
$_SESSION['starting_point']=$earl;