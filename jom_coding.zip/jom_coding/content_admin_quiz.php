<?php
    session_start();
    if($_SESSION['acc_status']=="user"){
        header("Location:../jom%20coding/content_home.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/admin.css">
    <link type="text/css" rel ="stylesheet" href="css/autocomplete.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <style>
        .main_content{
            background-image:url('image/background6.png');
            height:auto;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
    <title>Physics Made Easy - Admin Panel</title>
</head>
<body>
    <div class="container-fluid">
        <?php require 'tabs_faq.php';?><br><br>
        <?php require "main_admin_quiz2.php";?>
    </div>
</body>
</html>