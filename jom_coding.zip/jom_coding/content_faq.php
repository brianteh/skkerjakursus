<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/admin.css">
    <link type="text/css" rel ="stylesheet" href="css/autocomplete.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <style>
        body{
            background-image:url('image/background5.jpg');
            height:2000px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .faq_panel{
            background-color:rgba(255,255,255,0.2);
            padding:20px;
            font-size:1.2rem;
            width: 300px;
        }
        .faq_panel:hover{
            background-color:rgba(0,0,255,0.2);
        }
        .head_admin{
            width:100%;
            z-index:1000;
        }
        p::before{
            color:white;
            font-size:1.3rem;
        }
        h1{
            color:aquamarine;
        }
    </style>
    <title>Physics Made Easy - FAQ Support</title>
</head>
<body>
    <div class="container-fluid">
        <?php require 'tabs_faq.php';?>
        <br><br>
        <div class="row">
            <div class="col-sm-3" style="height:auto;">
            <div style="overflow:auto;height:575px;width:302px;position:fixed;top:55px;" >
            <!-- FAQ PANEL -->
                <div class="row faq_panel"><a href="#join_quiz" style="text-decoration:none;"><span style="color:white;"> How to Start Playing a Quiz?</span></a></div>
                <div class="row faq_panel"><a href="#create_quiz" style="text-decoration:none;"><span style="color:white;"> How to Create a Quiz?</span></a></div>
                <div class="row faq_panel"><a href="#create_note" style="text-decoration:none;"><span style="color:white;"> How to Create a Note?</span></a></div>
                <div class="row faq_panel"><a href="#create_ques" style="text-decoration:none;"><span style="color:white;"> How to Create a Question?</span></a></div>
                <div class="row faq_panel"><a href="#music_settings" style="text-decoration:none;"><span style="color:white;"> How to Configure Theme & Music Settings?</span></a></div>
                <div class="row faq_panel"><a href="#edit_profile" style="text-decoration:none;"><span style="color:white;"> How to Edit my Profile?</span></a></div>
                <div class="row faq_panel"><a href="#import_ques" style="text-decoration:none;"><span style="color:white;"> How to Import Questions?</span></a></div>
                <div class="row faq_panel"><a href="#import_user" style="text-decoration:none;"><span style="color:white;"> How to Import Users?</span></a></div>
                <div class="row faq_panel"><a href="#print_result" style="text-decoration:none;"><span style="color:white;"> How to Print Students' Result?</span></a></div>
            </div>
            </div>
            <div class="col-sm-9" style="height:1025px;z-index:950;">
                <div>
                    <h1 style="transform:scale(1.2);position:relative;left:100px;color:whitesmoke;">Physcis Made Easy Documentation Guide</h1>
                </div>
                <div id="join_quiz">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Joining a Quiz</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                           <i class="fas fa-book color_icon" style="position:relative;top:2px;"></i> Quiz >> Custom Quiz / Built-in Quiz
                        </code>
                        <br><br>
                        <span style="color:whitesmoke;font-family:monospace;font-size:1.1rem;">
                        Custom Quiz: Quizzes that are customly made and can only enter by using the code given.<br>
                        Built-in Quiz: Quizzes that are made based on the topic and are sourced from public questions.
                        </span>
                    </p>
                </div>
                <div id="create_quiz">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Creating a Quiz</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                        <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fas fa-user-edit" style="position:relative;top:2px;"></i> Admin >> <i class="far fa-calendar" style="position:relative;top:2px;"></i> Create Quiz
                        </code>
                    </p>
                </div>
                <div id="create_note">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Creating a Note</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                            <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fas fa-user-edit" style="position:relative;top:2px;"></i> Admin >> <i class="fas fa-graduation-cap" style="position:relative;top:2px;"></i> Create Note
                        </code>
                    </p>
                </div>
                <div id="create_ques">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Creating a Question</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                            <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fas fa-user-edit" style="position:relative;top:2px;"></i> Admin >> <i class="fab fa-accusoft" style="position:relative;top:2px;"></i> Create Question
                        </code>
                    </p>
                </div>
                <div id="music_settings">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Configuring Theme & Music Settings</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                            <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fa fa-cog" style="position:relative;top:2px;"></i> Settings >> Music / Theme
                        </code>
                    </p>
                </div>
                <div id="edit_profile">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Editing Profile</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                            <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fas fa-user-cog" style="position:relative;top:2px;"></i> Profile
                        </code>
                    </p>
                </div>
                <div id="import_ques">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Importing Questions</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                            <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fas fa-user-edit" style="position:relative;top:2px;"></i> Admin >> <i class="fab fa-accusoft" style="position:relative;top:2px;"></i> Create Question >> <i class="fas fa-edit" style="position:relative;top:2px;"></i> Upload Question Via CSV
                        </code>
                        <br><br>
                        <span style="color:whitesmoke;font-family:monospace;font-size:1.1rem;">
                            Make sure the .csv file is in this particular format:<br>
                            <code style="color:whitesmoke;background-color:rgba(0,0,255,0.2);">Topic,Content,Answer,Status(public/private),Option('-' in each interval for objective questions || '_' for subjective questions),Type(SUB/OBJ),Time limit(in seconds)</code>
                        </span>
                    </p>
                </div>
                <div id="import_user">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Importing Users</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                            <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fas fa-user-edit" style="position:relative;top:2px;"></i> Admin >> <i class="fas fa-users" style="position:relative;top:2px;"></i> Students >> <i class="fas fa-user-plus" style="position:relative;top:2px;"></i> Add Users
                        </code>
                        <br><br>
                        <span style="color:whitesmoke;font-family:monospace;font-size:1.1rem;">
                            Make sure the .csv file is in this particular format:<br>
                            <code style="color:whitesmoke;background-color:rgba(0,0,255,0.2);">Username,Email,Password,Status(user/admin),Form</code>
                        </span>
                    </p>
                </div>
                <div id="print_result">
                    <h1 style="color:whitesmoke;">_________________________________________________________________________</h1>
                </div>
                <div>
                    <h1>Printing Results</h1>
                    <p>
                        <code style="color:white;font-size:1.4rem;padding:10px;background-color:rgba(255,255,255,0.2);">
                            <i class="fas fa-bars" style="position:relative;top:2px;"></i> Menu bar >> <i class="fas fa-user-edit" style="position:relative;top:2px;"></i> Admin >> <i class="fas fa-users" style="position:relative;top:2px;"></i> Students >> <i class="fab fa-searchengin" style="position:relative;top:2px;"></i> Monitor Users
                        </code>
                        <br><br>
                        <span style="color:whitesmoke;font-family:monospace;font-size:1.1rem;">
                            Click on the <i class="fas fa-eye" style="position:relative;top:2px;"></i> to navigate the user's info.<br>
                            Then,click on <code>PRINT AS PDF</code> to print the results.
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>