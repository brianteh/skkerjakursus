<?php
    session_start();
    require "tabs_quizizz.php";
?>
<main style="background-image:url('image/theme_<?php echo $_SESSION['theme'];?>.png');">
    <?php
        require "main_finalR.php";
    ?>
</main>
<?php
    require "footer.php";
?>