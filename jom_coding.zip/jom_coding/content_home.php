<?php
    session_start();
    if(!isset($_SESSION['log_status'])){
        $_SESSION['log_status']=0;
    }
    $_SESSION['page_type']=0;
    require "tabs.php";
?>
<main>
    <?php
        require "main_home.php";
    ?>
</main>
<?php
    require "footer.php";
?>
