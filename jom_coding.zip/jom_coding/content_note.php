<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <title>Physics Made Easy - Editing Note</title>
    <link rel="stylesheet" href="css/admin.css">
    <style>
    .side{
        background-image:url('image/background6.png');
    }
    .middle{
        background-image:url('image/background5.jpg');
    }
    .change_btn{
        border-radius:15px;
        background-color:#1c1c1c;
        color:white;
        padding:10px;
        font-size:1.3rem;
        border:2px solid #1c1c1c;
    }
    .reset_btn{
        border-radius:15px;
        background-color:#1c1c1c;
        color:white;
        padding:12px;
        font-size:1.3rem;
        border:2px solid #1c1c1c;
    }
    .reset_btn:hover{
        color:white;
        text-decoration:none;
    }

    </style>
</head>
<body>
    <div class="row head_admin">
        <div class="col-sm-1"><center><a href="content_home.php"><img class="logo" src="image/physics.jpg" ></a></center></div>
        <div class="col-sm-8"></div>
        <div class="col-sm-2" style="margin-top:10px;"><center><input class="search_field" type="text" placeholder="Type in any keywords"></center></div>
        <div class="col-sm-1" style="margin-top:10px;"><button class="search_btn">Search</button></div>
    </div>
    <script src="js/filterfaq.js"></script>
    <div class="row">
    <div class="col-sm-2 side" style="height:auto;"></div>
    <div class="col-sm-8 middle" style="height:auto;">
        <br>
        <?php
            session_start();
            // show content for editorial
            $uid=$_SESSION['userID'];
            $note_id=$_REQUEST['note_id'];
            require 'connect_database.php';
            require 'editor.php';
            $select_note="SELECT * FROM note WHERE user_id='$uid' AND note_id='$note_id'";
            $selecting_note=mysqli_query($con,$select_note);
            if($selecting_note){
                while($row=mysqli_fetch_array($selecting_note)){
                    $note_content=$row['note_content'];
                    $note_topic=$row['note_topic'];
                    $note_title=$row['note_title'];
                    $note_keyword=$row['note_keyword'];
                    echo "
                    <script>
                        var note_topic=document.getElementById('note_topic');
                        var note_title=document.getElementById('note_title');
                        var note_keyword=document.getElementById('note_keyword');
                        note_topic.textContent='".$note_topic."';
                        note_title.textContent='".$note_title."';
                        note_keyword.textContent='".$note_keyword."';
                        richTextField.document.getElementsByTagName('body')[0].innerHTML='".$note_content."';
                    </script>
                    ";
                }
            }else{
                header("Location:../jom_coding/content_admin_note.php");
            }
            
        ?>
        
        <br><br><br>
        <div class="row">
       
        <script>
            // function to make changes to note via ajax request
            function changeNote(){
                var request=new XMLHttpRequest();
                var url="action_edit_note.php";
                var id= <?php echo json_encode($_REQUEST['note_id']); ?>;
                var topic=document.getElementById("note_topic").value;
                var title=document.getElementById("note_title").value;
                var keyword=document.getElementById("note_keyword").value;
                var content=richTextField.document.getElementsByTagName("body")[0].innerHTML;
                var $POST="content="+content+"&topic="+topic+"&title="+title+"&keyword="+keyword+"&id="+id;
                request.open("POST",url,true);
                request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                request.onreadystatechange = function() {
                    if(request.readyState == 4 && request.status == 200) {
                        var someCallback = request.responseText;
                        if(someCallback=="success"){
                            alert('Changes have been saved successfully!');
                        }else if(someCallback=="error"){
                            alert('An error has occurred!');
                        }
                            
                    }
                }
                request.send($POST);
            }
            function resetNote(){
                location.reload();
            }
        </script>    
            <button class="change_btn" type="submit" name="change_btn" style="margin-left:40px;outline:none;" onclick="changeNote();"><i class="fa fa-angle-right"></i> Change <i class="fa fa-angle-left"></i></button>  <button class="reset_btn" style="margin-left:600px;" onclick="resetNote();"><i class="fa fa-refresh"></i> Reset</button>
           
        </div>
        <br>     
    </div>
    <div class="col-sm-2 side" style="height:auto;"></div>
        
    </div>
    
</body>
</html>