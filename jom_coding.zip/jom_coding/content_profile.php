<?php 
session_start();
if(!isset($_SESSION['temp_pic'])){
    $_SESSION['temp_pic']=$_SESSION['profile_pic'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/profile.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <style>
    .side{
        background-image:url('image/background6.png');
    }
    .edit_title{
        font-size:1.5rem;
        border: #000;
        border-radius:10px;
        background-color:#1c1c1c;
        padding:10px;
    }
    .border-line{
        height:3px;
        width:98%;
        margin-left:auto;
        margin-right:auto;
        margin-bottom:10px;
        background-color:rgb(105, 104, 104);
        border-radius:5px;
    }
    .change_btn{
        border-radius:15px;
        background-color:#1c1c1c;
        color:white;
        padding:10px;
        font-size:1.3rem;
        border:2px solid #1c1c1c;
    }
    .reset_btn{
        border-radius:15px;
        background-color:#1c1c1c;
        color:white;
        padding:12px;
        font-size:1.3rem;
        border:2px solid #1c1c1c;
        text-decoration:none;
    }
    .reset_btn:hover{
        color:white;
        text-decoration:none;
    }
    .change_profile{
        background-color:#1c1c1c;
        border-radius:15px;
        border:2px solid #1c1c1c;
        color:white;
        margin-left:0px;
        padding:5px; 
    }
    .file_browser{
        width:35%;
    }
    .profile_photo{
        height:300px;
        width:300px;
        margin-left:auto;
        margin-right:auto;
        overflow:auto;
    }
    </style>
    <title>Physics Made Easy - Profile</title>
</head>
<body>

    <div class="row head_admin">
        <div class="col-sm-1"><center><a href="content_home.php"><img class="logo" src="image/physics.jpg" ></a></center></div>
        <div class="col-sm-8"></div>
        <div class="col-sm-2" style="margin-top:10px;"><center><input class="search_field" type="text" placeholder="Type in any keywords"></center></div>
        <div class="col-sm-1" style="margin-top:10px;"><button class="search_btn">Search</button></div>
    </div>

    <div class="row">
    <div class="col-sm-2 side" style="height:auto;"></div>
    <div class="col-sm-8 middle" style="height:auto;">
        <span style="font-size:2.8rem;font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;">Profile Info</span>
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <center><span class="edit_title">Profile picture</span></center><br><br>
                <form action="action_edit_profile.php" method="POST" enctype="multipart/form-data">
                    <div class="row"><img class="profile_photo" style="border-radius:50%;" src="<?php echo "user_photo/".$_SESSION['temp_pic'];?>"></div><br>
                    <div class="row"><input class="file_browser" name="profile_photo_upload" style="margin-left:190px;" type="file"> <button name="change_profile" class="change_profile" type="submit" style="margin-top:-4px;"><i class="fa fa-upload"></i></button></div><br>
                </form>
            </div>
            <div class="col-sm-2"></div>
        </div> 
        <br><div class="border-line"></div><br>
        <form action="action_edit_profile_full.php" method="POST">
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <center><span class="edit_title">Personal info</span><br><br></center>
                <div class="row">
                    <div class="col-sm-6">
                        <span style="font-size:1.25rem;margin-left:217px;">Form:</span><br>
                        <span style="font-size:1.25rem;margin-left:170px;">Username:</span><br>
                        <span style="font-size:1.25rem;margin-left:213px;">Email:</span><br>
                    </div>
                    <div class="col-sm-6">
                        <div style="margin-top:-5px;">
                        <textarea name="form" id="" cols="2" rows="1" style="margin-top:3px;"><?php echo $_SESSION['form'];?></textarea><br>
                        <span style="font-size:1.2rem;margin-top:5px;"><?php echo $_SESSION['username'];?></span><br>
                        <span style="font-size:1.2rem;margin-top:5px;"><?php echo $_SESSION['user_email'];?></span><br>
                    </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2"></div>
        </div>
        <br><br>
        <br><div class="border-line"></div><br>
        <div class="row">
        <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <center><span class="edit_title">Result History</span><br><br></center>
                <div style="overflow:auto;height:400px;">
                <table border="0" class="table">
                        <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                            <th>Quiz Pin</th>
                            <th>Quiz Name</th>
                            <th>Result Accuracy</th>
                            <th>Result Date</th>
                            <th>Time Used</th>
                        </tr>
                        <?php 
                            // prints out result history of user
                            $uid=$_SESSION['userID'];
                            require "connect_database.php";
                            $list="SELECT * FROM result,quiz WHERE result.user_id ='$uid' AND result.quiz_pin_number=quiz.quiz_pin_number";
                            $result=mysqli_query($con,$list);
                            while($row=mysqli_fetch_array($result)){
                                $a=$row['quiz_pin_number'];
                                $b=$row['quiz_name'];
                                $c=$row['result_accuracy'];
                                $d=$row['date_time'];
                                $e=$row['result_time_used'];
                                
                        ?>
                            <tr border="0" style="background-color:white;">
                                <td><?php echo $a; ?></td>
                                <td><?php echo $b; ?></td>
                                <td><?php echo $c; ?></td>
                                <td><?php echo $d; ?></td>
                                <td><?php echo $e; ?></td>
                            </tr>
                        <?php
                            
                            }
                    
                        ?> 
                </table>
                </div>
            </div>
        <div class="col-sm-2"></div>
        </div>
        <br><br>
        <div class="row">
            <button class="change_btn" type="submit" name="change_btn" style="margin-left:40px;"><i class="fa fa-angle-right"></i> Change <i class="fa fa-angle-left"></i></button>  <a class="reset_btn" style="margin-left:600px;" href="action_reset_profile.php"><i class="fa fa-refresh"></i> Reset</a>
        </div>     
        </form>
        <br><br>
    </div>
    <div class="col-sm-2 side"  style="height:auto;"></div>
    </div>
    
</body>
</html>