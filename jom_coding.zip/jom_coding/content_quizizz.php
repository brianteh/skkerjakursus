<?php
    require "tabs_quizizz.php";
    session_start();
?>
<main style="background-image:url('image/theme_<?php echo $_SESSION['theme'];?>.png');">
    <?php
        require "main_quizizz.php";
    ?>
</main>
</body>
</html>