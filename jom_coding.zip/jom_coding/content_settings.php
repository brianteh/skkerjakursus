<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/admin.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <style>
        .side{
            background-image:url('image/background6.png');
            height:1080px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .autocomplete-items{
            z-index:1100;
            background-color: whitesmoke;
        }
        
    </style>
    <title>Physics Made Easy - Settings</title>
</head>
<body>
    <div class="container-fluid">
        <?php include 'tabs_faq.php';?>
        <div class="row">
                <div class="col-sm-2 side" style="height:auto;">333</div>
                <div class="col-sm-8" style="background-color:#383434;height:1000px;">
                <br><br><br><br>
                <span style="font-size:2rem;color:white;background-color:#1c1c1c;padding:15px;border-radius:15px;">Quiz Settings:</span>
                <br><br>
                <div class="border-line"></div>
                <br><br>
                <span style="font-size:2rem;color:white;background-color:#1c1c1c;padding:15px;border-radius:15px;">Music :</span><span style="font-size:2rem;color:white;margin-left:80px;"><i id="toggle_music" onclick="toggle_music();" class="fas fa-toggle-on"></i></span>
                <br>
                <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8 w3-container" id="music_opt">
                <img id="clockwise" onclick="rotate_clockwise();" class="img_music" style="box-shadow: 0 5px 15px rgba(0, 0, 0, 0.63);height:100px;width:100px;margin-left:30px;">
                <img class="img_music w3-center" style="border:2px solid white;box-shadow: 0 5px 15px rgba(0, 0, 0, 0.63);height:200px;width:200px;margin-left:50px;">
                <img id="anticlockwise" onclick="rotate_anticlockwise();" class="img_music" style="box-shadow: 0 5px 15px rgba(0, 0, 0, 0.63);height:100px;width:100px;margin-left:50px;">
                <script>
                // section of music settings
                var music_state;
                if(<?php if($_SESSION['toggle-music']){echo "true";}else{echo "false";}?>){
                    music_state=0;
                }else{
                    music_state=1;
                }
                var toggle_musica=document.getElementById('toggle_music');
                var images=document.getElementsByClassName('img_music');
                var music_option=document.getElementById('music_opt');
                var music_list=['cyberpunk','chilling','nature'];
                images[0].src='image/music_'+music_list[0]+'.jpg'; 
                images[1].src='image/music_'+music_list[1]+'.jpg'; 
                images[2].src='image/music_'+music_list[2]+'.jpg';
                function rotate_anticlockwise(){
                    var temp=music_list[0];
                    music_list[0]=music_list[1];
                    music_list[1]=music_list[2];
                    music_list[2]=temp;
                    images[0].src='image/music_'+music_list[0]+'.jpg'; 
                    images[1].className="img_music w3-center w3-animate-right";
                    images[1].src='image/music_'+music_list[1]+'.jpg'; 
                    images[1].style.width='200';
                    images[1].style.height='200';
                    images[2].src='image/music_'+music_list[2]+'.jpg';
                }
                function reset_img(){
                    images[1].className="img_music w3-center";
                    if(music_state==0){
                        toggle_musica.className="fas fa-toggle-on";
                    }else if(music_state==1){
                        toggle_musica.className="fas fa-toggle-off";
                    }
                    music_opt(music_list[1]);
                }
                function rotate_clockwise(){
                    var temp=music_list[1];
                    music_list[1]=music_list[0];
                    music_list[0]=music_list[2];
                    music_list[2]=temp;
                    images[0].src='image/music_'+music_list[0]+'.jpg'; 
                    images[1].className="img_music w3-center w3-animate-left";
                    images[1].src='image/music_'+music_list[1]+'.jpg'; 
                    images[1].style.width='200';
                    images[1].style.height='200';
                    images[2].src='image/music_'+music_list[2]+'.jpg';
                }
                setInterval(reset_img,1000);
                function toggle_music(){
                    if(music_state==0){
                        toggle_musica.className='fas fa-toggle-off';
                        settings_music("music-off");
                        music_state=1;
                    }else if(music_state==1){
                        toggle_musica.className='fas fa-toggle-on';
                        settings_music("music-on");
                        music_state=0;
                    }
                }
                function settings_music(settings_op){
                    var request=new XMLHttpRequest();
                    var url="settings.php";
                    request.open("POST",url,true);
                    var $POST="settings="+settings_op;
                    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    request.send($POST);
                }
                function music_opt(music_theme){
                    var request=new XMLHttpRequest();
                    var url="action_music_opt.php";
                    request.open("POST",url,true);
                    var $POST="music="+music_theme;
                    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    request.send($POST);
                }
                </script>
                </div>
                <div class="col-sm-2"></div>
                </div>
                <br>
                <span style="font-size:2rem;color:white;background-color:#1c1c1c;padding:15px;border-radius:15px;">Theme :</span><span style="font-size:2rem;color:white;margin-left:80px;"></span>   
                <br>
                <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8" id="theme_opt">
                <img id="tclockwise" onclick="trotate_clockwise();" class="img_theme" style="box-shadow: 0 5px 15px rgba(0, 0, 0, 0.63);height:100px;width:100px;margin-left:30px;">
                <img class="img_theme w3-center" style="border:2px solid white;box-shadow: 0 5px 15px rgba(0, 0, 0, 0.63);height:200px;width:200px;margin-left:50px;">
                <img id="tanticlockwise" onclick="trotate_anticlockwise();" class="img_theme" style="box-shadow: 0 5px 15px rgba(0, 0, 0, 0.63);height:100px;width:100px;margin-left:50px;">
                <script>
                // settings for theme
                var theme_state=0;
                var toggle_themea=document.getElementById('toggle_theme');
                var timages=document.getElementsByClassName('img_theme');
                var theme_option=document.getElementById('theme_opt');
                var theme_list=['space','colourful','nature'];
                timages[0].src='image/theme_'+theme_list[0]+'.jpg'; 
                timages[1].src='image/theme_'+theme_list[1]+'.jpg'; 
                timages[2].src='image/theme_'+theme_list[2]+'.jpg';
                function trotate_anticlockwise(){
                    var temp=theme_list[0];
                    theme_list[0]=theme_list[1];
                    theme_list[1]=theme_list[2];
                    theme_list[2]=temp;
                    timages[0].src='image/theme_'+theme_list[0]+'.jpg'; 
                    timages[1].className="img_theme w3-center w3-animate-right";
                    timages[1].src='image/theme_'+theme_list[1]+'.jpg'; 
                    timages[1].style.width='200';
                    timages[1].style.height='200';
                    timages[2].src='image/theme_'+theme_list[2]+'.jpg';
                }
                function treset_img(){
                    timages[1].className="img_theme w3-center";
                    theme_opt(theme_list[1]);
                }
                function trotate_clockwise(){
                    var temp=theme_list[1];
                    theme_list[1]=theme_list[0];
                    theme_list[0]=theme_list[2];
                    theme_list[2]=temp;
                    timages[0].src='image/theme_'+theme_list[0]+'.jpg'; 
                    timages[1].className="img_theme w3-center w3-animate-left";
                    timages[1].src='image/theme_'+theme_list[1]+'.jpg'; 
                    timages[1].style.width='200';
                    timages[1].style.height='200';
                    timages[2].src='image/theme_'+theme_list[2]+'.jpg';
                }
                setInterval(treset_img,1000);
                function theme_opt(theme_theme){
                    var request=new XMLHttpRequest();
                    var url="action_theme_opt.php";
                    request.open("POST",url,true);
                    var $POST="theme="+theme_theme;
                    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    request.send($POST);
                }
                </script>
                </div>
                <div class="col-sm-2"></div>
                </div>
                <br>
                </div>
                <div class="col-sm-2 side" style="height:auto;">333</div>
        </div>
    </div>
</body>
</html>