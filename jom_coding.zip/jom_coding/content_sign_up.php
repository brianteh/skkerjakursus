<?php
    session_start(); 
    if(!isset($_SESSION['log_status'])){
        $_SESSION['log_status']=0;
    }
    $_SESSION['page_type']=2;
    require "tabs.php";
?> 
     

<main>
   <?php
        require "main_sign_up.php";
   ?> 
</main>

<?php
    require "footer.php";
?>
 