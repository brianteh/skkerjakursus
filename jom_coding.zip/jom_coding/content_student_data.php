<?php
    session_start();
    if($_SESSION['acc_status']!="admin"){
        header("Location:../jom_coding/content_home.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/admin.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    <title>Student Data</title>
    <style>
        body{
            background-image:url('image/background6.png');
            height:1080px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            color:white;
        }
    </style>
</head>
<body>
    <div class="row head_admin">
        <div class="col-sm-1"><center><a href="content_home.php"><img class="logo" src="image/physics.jpg" ></a></center></div>
        <div class="col-sm-8"></div>
        <div class="col-sm-2" style="margin-top:10px;"><center><input class="search_field" type="text" placeholder="Type in any keywords"></center></div>
        <div class="col-sm-1" style="margin-top:10px;"><button class="search_btn">Search</button></div>
        
    </div>
    <br>
    <?php 
        // grab student data from database for report
        require 'connect_database.php';
        $id=$_GET['user_id'];
        $grab_student_info="SELECT * FROM pme_user WHERE user_id='$id'";    
        $grabbing_student_info=mysqli_query($con,$grab_student_info);
        if($grabbing_student_info){
            while($row=mysqli_fetch_array($grabbing_student_info)){
                $form=$row['user_form'];
                $name=$row['username'];
                $email=$row['user_email'];
            }
        }
    ?>
    <div class="row">
        <div class="col-sm-2">
        </div>
        <div class="col-sm-8">
            <h2>Quiz Selected:</h2>
            <select name="" id="stu_stat">
            <?php
                // shows quizs that user have done before
                $ok=true;
                require 'connect_database.php';
                $id=$_GET['user_id'];
                $grab_student_results="SELECT DISTINCT result.quiz_pin_number,quiz.quiz_name FROM result,quiz 
                                       WHERE result.user_id='$id' AND result.quiz_pin_number=quiz.quiz_pin_number;";
                $grabbing_student_results=mysqli_query($con,$grab_student_results);
                if($grabbing_student_results){
                    $num=0;
                    while($row=mysqli_fetch_array($grabbing_student_results)){
                        $quiz_pin=$row['quiz_pin_number'];
                        $quiz_topic=$row['quiz_name'];
                        echo "<option value='".$num."'>".$quiz_topic."---->".$quiz_pin."</option>";
                        if(!isset($_SESSION['chose_student_quiz'])){
                            $_SESSION['chose_student_quiz']=$quiz_pin;
                        }
                        if(!isset($_SESSION['chose_student_index'])){
                            $_SESSION['chose_student_index']=$num;
                        }
                        if(!isset($_SESSION['quiz_title'])){
                            $_SESSION['quiz_title']=$quiz_topic;
                        }
                        $num+=1;
                    }
                }
                // check if the user has ever done a quiz
                if(mysqli_num_rows($grabbing_student_results)==0){
                    $ok=false;
                }
            ?>
                <script>
                    // update quiz selected using ajax request
                        var quiz_opt=document.getElementById('stu_stat');
                        var current=<?php echo $_SESSION['chose_student_index'];?>;
                        quiz_opt.selectedIndex=current;
                        quiz_opt.onchange=function (){
                            var quiz_opt_index=quiz_opt.value;
                            var quiz_opt_value=quiz_opt.options[quiz_opt.selectedIndex].text;
                            var request=new XMLHttpRequest();
                            var $POST="stu_stat="+quiz_opt_value+"&index="+quiz_opt_index;
                            var url="action_set_stu_stat.php";
                            request.open('POST',url,true);
                            request.setRequestHeader('Content-type','application/x-www-form-urlencoded');
                            request.send($POST);
                            request.onreadystatechange = function() {
                                if(request.readyState == 4 && request.status == 200) {
                                    var someCallback = request.responseText;
                                    if(someCallback=="success"){
                                        location.reload();
                                    }
                                    
                                }
                            }   
                        }
                </script>
            </select>
            <br><br>
            <!-- INFO OF USER-->
            <h3>FORM:   <?php echo $form;?></h3><hr/>
            <h3>NAME:   <?php echo $name;?></h3><hr/>
            <h3>EMAIL:   <?php echo $email;?></h3><hr/>
            <Label style="color:white;font-size:1.5rem;"><?php if($ok){echo $_SESSION['quiz_title'];}else{echo "None";}?></Label>
            <table border="0" class="table">
                <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                    <th>Date</th>
                    <th>Time Used</th>
                    <th>Result</th>
                </tr>
            <?php
                require 'connect_database.php';
                if(!isset($_SESSION['chose_student_quiz'])){
                    $_SESSION['chose_student_quiz']="-";
                }
                $pin=$_SESSION['chose_student_quiz'];
                // grab and show record of quiz
                $id=$_GET['user_id'];
                $grab_student_results="SELECT * FROM result WHERE user_id='$id' AND quiz_pin_number='$pin' ORDER BY date_time ASC";
                $grabbing_student_results=mysqli_query($con,$grab_student_results);
                if($grabbing_student_results){
                    while($row=mysqli_fetch_array($grabbing_student_results)){
                        $date=$row['date_time'];
                        $time_used=$row['result_time_used'];
                        $accuracy=$row['result_accuracy'];
                        
            ?>
                <tr style="color:white;">
                    <td><?php echo $date;?></td>
                    <td><?php echo $time_used;?></td>
                    <td><?php echo $accuracy;?></td>
                </tr>
            <?php 
                    }
                }else{
                    echo '
                    <tr>
                    <span style="color:white;">None results have been recorded</span>
                    </tr>';
                }
            ?>
            </table>
        </div>
        <div class="col-sm-2"> 
            <a style="color:indigo;padding:20px;font-size:1.5rem;"
            href="content_student_pdf.php?user_id=<?php echo $_GET['user_id'];?>">Print As PDF</a>
        </div>
    </div>
    
</body>
</html>


