<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="css/edit_question.css">
    <link rel="stylesheet" href="css/admin.css">
    <style>
    .side{
        background-image:url('image/background6.png');
    }
    </style>
    <title>Document</title>
</head>
<body>

    <div class="row head_admin">
        <div class="col-sm-1"><center><a href="content_home.php"><img class="logo" src="image/physics.jpg" ></a></center></div>
        <div class="col-sm-8"></div>
        <div class="col-sm-2" style="margin-top:10px;"><center><input class="search_field" type="text" placeholder="Type in any keywords"></center></div>
        <div class="col-sm-1" style="margin-top:10px;"><button class="search_btn">Search</button></div>
    </div>
    <script src="js/filterfaq.js"></script>
    <div class="row">
    <div class="col-sm-2 side"></div>
    <div class="col-sm-8 middle">
        <?php
            require 'action_edit_question.php';
            $type=$_REQUEST['type'];
            $_SESSION['ques_pic'.$_REQUEST['ques_id']]=$ques_pic;
            
            echo 
            '
            <div class="modal" id="error_window" style="">
                <div class="modal-content">
                    <div class="row" style="background-color:black;width:598px;margin-left:0px;">
                        <div class="col-sm-11">ERROR</div>
                        <div class="col-sm-1"><i style="color:white;" id="close" class="fas fa-compress-arrows-alt"></i></div>
                    </div>
                    <div class="row">
                        <div class="col-sm-2"></div>
                        <div class="col-sm-8"><span style="color:black;font-size:1.5rem;">An error occured !</span></div>
                        <div class="col-sm-2"></div>
                    </div>
                </div>
            </div>
            <script>
                var modal = document.getElementById("error_window");
                var close = document.getElementById("close");
                close.onclick = function() {
                modal.style.display = "none";
                }
                window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
                }
            </script>
            ';
            
            echo 
            '
            <br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><span class="edit_title">Question Topic</span></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><textarea id="topic">'.$ques_topic.'</textarea></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br><div class="border-line"></div><br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><span class="edit_title">Question Level</span></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><textarea id="level">'.$ques_level.'</textarea></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br><div class="border-line"></div><br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><span class="edit_title">Question Content</span></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><textarea id="content">'.$ques_content.'</textarea></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br><div class="border-line"></div><br>
            ';
            if(!isset($_SESSION['temp_ques_pic'.$_REQUEST['ques_id']])){
                $_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]=$_SESSION['ques_pic'.$_REQUEST['ques_id']];
            }
            if($_SESSION['temp_ques_pic'.$_REQUEST['ques_id']]!="-"){
                echo
                '
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8"><center><span class="edit_title">Question Picture</span></center></div>
                    <div class="col-sm-2"></div>
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8"><center><img src="question_photo/'.$_SESSION['temp_ques_pic'.$_REQUEST['ques_id']].'"></center></div>
                    <div class="col-sm-2"></div>
                </div>
                <br>
                ';
            }else{
                // upload photo
                echo
                '
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8"><center><span class="edit_title">Question Picture</span></center></div>
                    <div class="col-sm-2"></div>
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8"><center>-</center></div>
                    <div class="col-sm-2"></div>
                </div>
                ';
            }

            echo
            '
            <br>
            <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
            <form action="action_upload_ques_photo.php?ques_id='.$_REQUEST['ques_id'].'&type='.$type.'" method="POST" enctype="multipart/form-data">
            <input style="width:220px;margin-left:165px;" id="up" type="file" name="ques_photo_upload"/><button name="change_ques" class="change_profile" type="submit" style="margin-left:0px;margin-top:-4px;"><i class="fa fa-upload"></i></button>
            </form>
            </div>
            <div class="col-sm-2"></div>
            </div>
            ';
        
            if($type=="OBJ"){
                echo
                '
                <br><div class="border-line"></div><br>
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8"><center><span class="edit_title">Question Option</span></center></div>
                    <div class="col-sm-2"></div>
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8"><center><textarea id="select">'.$ques_select.'</textarea></center></div>
                    <div class="col-sm-2"></div>
                </div>';
                
            }    
            echo
            '
            <br><div class="border-line"></div><br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><span class="edit_title">Question Answer</span></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br>
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8"><center><textarea id="answer">'.$ques_answer.'</textarea></center></div>
                <div class="col-sm-2"></div>
            </div>
            <br><div class="border-line"></div><br>
            <button class="change_btn" id="change_btn" onclick="gogo();" name="change"><i class="fa fa-angle-right"></i> Change <i class="fa fa-angle-left"></i></button><a class="reset_btn" href="action_reset_question.php?ques_id='.$_REQUEST['ques_id'].'&type='.$_REQUEST['type'].'"><i class="fa fa-refresh"></i> Reset</a>
            <br><br>';

            if($type=="OBJ"){
                echo 
                '
                <script>
                var modal = document.getElementById("error_window");
                var close = document.getElementById("close");
                var change_btn=document.getElementById("change_btn");
              
                function gogo(){
                    var topic=document.getElementById("topic").value;
                    var content=document.getElementById("content").value;
                    var answer=document.getElementById("answer").value;
                    var level=document.getElementById("level").value;
                    var select=document.getElementById("select").value;
                    var request= new XMLHttpRequest();
                    var url ="action_edit_question_full.php";
                    var $POST="ques_id='.$_REQUEST['ques_id'].'"+"&type='.$type.'"+"&topic="+topic+"&content="+content+"&answer="+answer+"&select="+select+"&ques_pic='.$_SESSION['temp_ques_pic'.$_REQUEST['ques_id']].'"+"&level="+level;
                    request.open("POST",url,true);
                    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    request.onreadystatechange = function() {
                        if(request.readyState == 4 && request.status == 200) {
                            var someCallback = request.responseText;
                            if(someCallback=="error"){
                                modal.style.display="block";
                            }
                          
                        }
                    }
                    request.send($POST);
                }
                </script>
                ';
            }else if($type=="SUB"){
                echo 
                '
                <script>
                var modal = document.getElementById("error_window");
                var close = document.getElementById("close");
                var change_btn=document.getElementById("change_btn");
                
                function gogo(){
                    var topic=document.getElementById("topic").value;
                    var content=document.getElementById("content").value;
                    var answer=document.getElementById("answer").value;
                    var level=document.getElementById("level").value;
                    var select="-";
                    var request= new XMLHttpRequest();
                    var url ="action_edit_question_full.php";
                    var $POST="ques_id='.$_REQUEST['ques_id'].'"+"&type='.$type.'"+"&topic="+topic+"&content="+content+"&answer="+answer+"&select="+select+"&ques_pic='.$_SESSION['temp_ques_pic'.$_REQUEST['ques_id']].'"+"&level="+level;
                    request.open("POST",url,true);
                    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    request.onreadystatechange = function() {
                        if(request.readyState == 4 && request.status == 200) {
                            var someCallback = request.responseText;
                            if(someCallback=="error"){
                                modal.style.display="block";
                            }
                          
                        }
                    }
                    request.send($POST);
                    
                }
            
                </script>
                ';
            }
        ?>
   
        
    </div>
    <div class="col-sm-2 side"></div>
    </div>
    
</body>
</html>