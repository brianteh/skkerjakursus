<footer>
    <div class="footer">
    Copyright &copy; Physics Made Easy.Co
    <br><br>
    <a href="content_faq.php"><i class="fas fa-hands-helping"></i> Faq Support</a>
    <br><br>
    <a href="mailto:email@example.com"><i class="fas fa-mail-bulk"></i> Feedback</a>
    </div>
</footer>
</body>
</html>