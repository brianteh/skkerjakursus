<div class="row content_admin">
    <div class="col-sm-2 nav_tab" style="height:auto;">
        <div class="row"><span class="" id="create_quiz"><center><a class="nav-link" href="content_admin_quiz.php" style="text-decoration:none;"><i class="	far fa-calendar"></i> Create Quiz</a></center></span></div>
        <div class="row"><span style="font-size:1.25rem;" class="" id="create_question"><center><a class="nav-link" href="content_admin_question.php" style="text-decoration:none;"><i class="fab fa-accusoft"></i> Create Question</a></center></span></div>
        <div class="row"><span class="active_tabz" id="create_note"><center><a class="nav-link" href="content_admin_note.php" style="text-decoration:none;"><i class="fas fa-graduation-cap"></i> Create Note</a></center></span></div>
        <div class="row"><span class="" id="statistics"><center><a class="nav-link" href="content_admin_statistics.php" style="text-decoration:none;"><i class="fas fa-chart-bar"></i> Statistics</a></center></span></div>
        <div class="row"><span class="" id="student"><center><a class="nav-link" href="content_admin_student.php" style="text-decoration:none;"><i class="fas fa-users"></i> Students</a></center></span></div>
    </div>   
    <div class="col-sm-10 main_content pages" style="display:block;height:auto;">
        <br>
        <Label title="Questions you had created"style="color:white;font-size:1.5rem;"><i class="far fa-folder-open"></i>Contribute your own notes:</Label>
        <br>
        <span style="color:white;">Notes Gallery:</span>
        <div class="note_gallery">
        <table border="0" class="table">
            <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                <th>ID</th>
                <th>Topic</th>
                <th>Title</th>
                <th>Status <i class="fas fa-globe"></i>
                </th>
                <th>Action</th>
            </tr>
        <?php
            // show note of user
            require "connect_database.php";
            $user_id=$_SESSION['userID'];
            $search_query="SELECT * FROM note WHERE user_id='$user_id'";
            $searchResult=mysqli_query($con,$search_query);
            $counter=1;
            $stat="";
            while($row=mysqli_fetch_array($searchResult)){
                $topic=$row['note_topic'];
                $id=$row['note_id'];
                $status=$row['note_status'];
                $title=$row['note_title'];
                $keyword=$row['note_keyword'];
                if($status=="private"){
                    $stat="fas fa-toggle-off";
                }else if($status=="public"){
                    $stat="fas fa-toggle-on";
                }
        ?>
                <tr border="0" style="background-color:white;">
                    <td><?php echo $id;?></td>
                    <td><?php echo $topic;?></td>
                    <td><?php echo $title;?></td>
                    <td><i id="<?php echo "stat_btn".$counter;?>" onclick='<?php echo "changeStat".$counter."();";?>' class="<?php echo $stat?>"></i></td>
                    <td><a class="editor" style="margin-left:10px;" href="content_note.php?note_id=<?php echo $id;?>" target="_blank"><i class="fas fa-pen"></i></a><a class="editor" style="margin-left:40px;" href="javascript:delete_note<?php echo $counter;?>()"><i class="fas fa-trash-alt"></i></a></td>
                    <script>
                    // all function have special id to prevent function overload
                    function <?php echo "delete_note".$counter;?>(){
                            var state=confirm("Are you sure of this action?");
                            if(state==true){
                                window.location="action_delete_note.php?note_id=<?php echo $id;?>&note_topic=<?php echo $topic;?>&note_title=<?php echo $title;?>&note_keyword=<?php echo $keyword;?>";
                            }
                    }
                    var <?php echo "status".$counter;?>="";
                    var <?php echo "stat_btn".$counter;?>=document.getElementById("<?php echo "stat_btn".$counter;?>");
                    function <?php echo "toggleStatus".$counter;?>(){
                        if(<?php echo "stat_btn".$counter;?>.className=="fas fa-toggle-off"){
                            <?php echo "stat_btn".$counter;?>.className="fas fa-toggle-on";
                            <?php echo "status".$counter;?>="private";
                        }else if(<?php echo "stat_btn".$counter;?>.className=="fas fa-toggle-on"){
                            <?php echo "stat_btn".$counter;?>.className="fas fa-toggle-off";
                            <?php echo "status".$counter;?>="public";
                        }
                    }
                    // change access status of note via ajax
                    function <?php echo "changeStat".$counter;?>(){
                        <?php echo "toggleStatus".$counter;?>();
                        var note_status=<?php echo "status".$counter;?>;
                        var request=new XMLHttpRequest();
                        var url="action_toggle_stat.php";
                        var $POST="note_id="+"<?php echo $id;?>"+"&current="+note_status;
                        request.open("POST",url,true);
                        request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                        request.send($POST);
                    }
                    
                    </script>
                </tr>
            <?php
            $counter+=1;
            }
            ?>
        </table>
        </div> 
        <br><div class="border-line"></div><br>
        <Label title="Let's create some notes!"style="color:white;font-size:1.5rem;"><i class="far fa-edit"></i>Create your own notes:</Label>
        <br>
        <br>
        <?php
            require 'editor.php';
        ?>
        <br>
        <br>
        <button  class="direct_create_note" onclick="saveNote();">Create note!</button>
        <br>
        <br>
    
    
    </div>
</div>