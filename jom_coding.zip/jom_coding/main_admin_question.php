<div class="row content_admin">
    <div class="col-sm-2 nav_tab">
        <div class="row"><span class="" id="create_quiz"><center><a class="nav-link" href="content_admin_quiz.php" style="text-decoration:none;"><i class="	far fa-calendar"></i> Create Quiz</a></center></span></div>
        <div class="row"><span style="font-size:1.25rem;" class="active_tabz" id="create_question"><center><a class="nav-link" href="content_admin_question.php" style="text-decoration:none;"><i class="fab fa-accusoft"></i> Create Question</a></center></span></div>
        <div class="row"><span class="" id="create_note"><center><a class="nav-link" href="content_admin_note.php" style="text-decoration:none;"><i class="fas fa-graduation-cap"></i> Create Note</a></center></span></div>
        <div class="row"><span class="" id="statistics"><center><a class="nav-link" href="content_admin_statistics.php" style="text-decoration:none;"><i class="fas fa-chart-bar"></i> Statistics</a></center></span></div>
        <div class="row"><span class="" id="student"><center><a class="nav-link" href="content_admin_student.php" style="text-decoration:none;"><i class="fas fa-users"></i> Students</a></center></span></div>
    </div>   
    <div class="col-sm-10 main_content pages" style="display:block;">
        <br>
        <!-- 1 -->
        <Label title="Questions you had created"style="color:white;font-size:1.5rem;"><i class="far fa-folder-open"></i>Accessable question:</Label>
            <!-- change below if possible-->
            <div class="availablez">
                <form method="POST" action="action_edit_question.php">
                <table border="0" class="table">
                    <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                        <th>Question ID</th>
                        <th>Question Topic </th>
                        <th>Question Content</th>
                        <th>Question Level</th>
                        <th>Status</th>
                        <th>Edit question</th>
                    </tr>
                <?php 
                    require "connect_database.php";
                    $list="SELECT * FROM question WHERE user_id=".$_SESSION['userID'];
                    $result=mysqli_query($con,$list);
                    $stat="";
                    $counter=1;
                    while($row=mysqli_fetch_array($result)){
                        $a=$row['question_id'];
                        $b=$row['question_topic'];
                        $c=$row['question_content'];
                        $d=$row['question_level'];
                        $e=$row['question_select'];
                        $f=$row['question_type'];
                        $status=$row['question_status'];
                        if($status=="private"){
                            $stat="fas fa-toggle-off";
                        }else if($status=="public"){
                            $stat="fas fa-toggle-on";
                        }
                ?>
                    <tr border="0" style="background-color:white;">
                        <td><?php echo $a; ?></td>
                        <td><?php echo $b; ?></td>
                        <td><?php echo $c; ?></td>
                        <td><?php echo $d; ?></td>
                        <td><i id='<?php echo "stat_btn".$counter;?>' onclick='<?php echo "changeStat".$counter."()";?>' class='<?php echo $stat;?>'></i></td>
                        <td> 
                            <a class="editor" style="margin-left:10px;" href="edit_ques_page.php?ques_id=<?php echo $a;?>&type=<?php echo $f;?>" target="_blank"><i class="fas fa-pen"></i></a><a class="editor" style="margin-left:40px;" href="javascript:delete_question<?php echo $counter;?>()"><i class="fas fa-trash-alt"></i></a>                           
                        </td>
                        <script>
                        // all function have special id to prevent function overload
                        function <?php echo "delete_question".$counter;?>(){
                            var state=confirm("Are you sure of this action?");
                            if(state==true){
                                window.location="action_delete_question.php?ques_id=<?php echo $a;?>";
                            }
                        }
                        var <?php echo "status".$counter;?>="";
                        var <?php echo "stat_btn".$counter;?>=document.getElementById('<?php echo "stat_btn".$counter;?>');
                        function <?php echo "toggleStatus".$counter;?>(){
                            if(<?php echo "stat_btn".$counter;?>.className=="fas fa-toggle-off"){
                                <?php echo "stat_btn".$counter;?>.className="fas fa-toggle-on";
                                <?php echo "status".$counter;?>="private";
                            }else if(<?php echo "stat_btn".$counter;?>.className=="fas fa-toggle-on"){
                                <?php echo "stat_btn".$counter;?>.className="fas fa-toggle-off";
                                <?php echo "status".$counter;?>="public";
                            }
                        }
                        // change access status of question via ajax
                        function <?php echo "changeStat".$counter;?>(){
                            <?php echo "toggleStatus".$counter;?>();
                            var ques_status=<?php echo "status".$counter;?>;
                            var request=new XMLHttpRequest();
                            var url="action_toggle_ques.php";
                            var $POST="ques_id="+<?php echo $a;?>+"&current="+ques_status;
                            request.open("POST",url,true);
                            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                            request.send($POST);
                            
                        }
                        </script> 
                    </tr>
                <?php
                    $counter+=1;
                    }
                ?> 
                </table>
                </form>
            </div>
        <br>
        <!-- 2 -->
        <br><br><div class="border-line"></div><br><br>
        <Label style="color:white;font-size:1.5rem;"><i class="fas fa-edit"></i> Create your own Question:</Label>
            <br>
            <form style="color:white;font-size:1.2rem;" method="POST" action="action_create_question.php" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-sm-2">Topic :</div>
                    <div class="col-sm-10"><input name="ques_topic" type="text"></div>  
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2">Level :</div>
                    <div class="col-sm-10">
                        <select name="ques_level" id="">
                            <option value=1>1</option>
                            <option value=2>2</option>
                            <option value=3>3</option>
                            <option value=4>4</option>
                        </select>
                    </div>  
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2">Type :</div>
                    <div class="col-sm-10">
                        <select name="ques_type" id="">
                            <option value="OBJ">OBJECTIVE</option>
                            <option value="SUB">SUBJECTIVE</option>
                        </select>
                    </div>  
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2">Content:</div>
                    <div class="col-sm-10"><textarea style="max-width:80%;"name="ques_content" id="" cols="80" rows="10"></textarea></div>  
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2">Picture:</div>
                    <div class="col-sm-10"><input name="ques_pic" type="file" /></div>  
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2">Answer:</div>
                    <div class="col-sm-10"><input name="ques_answer" type="text"></div>  
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2">Option:</div>
                    <div class="col-sm-10"><input name="ques_select" type="text">
                        ("_" for SUBJECTIVE questions & Put "-" in each interval of answers for OBJECTIVE questions)
                    </div>  
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-2">Time Limit:</div>
                    <div class="col-sm-10"> 
                        <select name="ques_time_limit" id="">
                        <option value="8">8</option>
                        <option value="12">12</option>
                        <option value="16">16</option>
                        <option value="20">20</option>
                        <option value="24">24</option>
                        <option value="28">28</option>
                        <option value="32">32</option>
                        <option value="36">36</option>
                        <option value="40">40</option>
                        <option value="44">44</option>
                        <option value="48">48</option>
                        <option value="52">52</option>
                        <option value="56">56</option>
                        <option value="60">60</option>
                        <option value="64">64</option>
                        <option value="68">68</option>
                        <option value="72">72</option>
                        <option value="76">76</option>
                        <option value="80">80</option>
                        <option value="84">84</option>
                        <option value="88">88</option>
                        <option value="92">92</option>
                        <option value="96">96</option>
                        <option value="100">100</option>
                        </select>
                    </div>
                </div>
                <br>
                <br>
                <button class="create_quiz_btn" type="submit" name="create_ques"><i class="fa fa-angle-right"></i> Create Question <i class="fa fa-angle-left"></i></button>
                <br><br>
            </form>
            <br><br><div class="border-line"></div><br>
            <Label style="color:white;font-size:1.5rem;"><i class="fas fa-edit"></i> Upload Question Via CSV:</Label>
            <br><br>
            <div style="margin-left:-170px;">
                <!--IMPORT CSV FILE ,STRAIGHT AWAY TO DB-->
                <form action="action_import_csv.php" method="POST" enctype="multipart/form-data">
                <input name="import_csv" style="border-radius:25px;padding:20px;background-color:rgba(168, 168, 163, 0.37);color:white;margin-left:190px;" type="file"/> 
                <button name="btn_import_csv" type="submit" style="margin-top:-4px;border-radius:25px;padding:20px;background-color:#1c1c1c;color:white;outline:none;border:2px solid #1c1c1c;margin-top:-4px;">
                    <i class="fa fa-upload"></i>
                </button>
                </form>
            </div>
            <br>
    </div>
</div>