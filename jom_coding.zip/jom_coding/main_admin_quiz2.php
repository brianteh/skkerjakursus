
<div class="row content_admin">
    <div class="col-sm-2 nav_tab">
        <div class="row"><span class="active_tabz" id="create_quiz"><center><a class="nav-link" href="content_admin_quiz.php" style="text-decoration:none;"><i class="	far fa-calendar"></i> Create Quiz</a></center></span></div>
        <div class="row"><span style="font-size:1.25rem;" class="" id="create_question"><center><a class="nav-link" href="content_admin_question.php" style="text-decoration:none;"><i class="fab fa-accusoft"></i> Create Question</a></center></span></div>
        <div class="row"><span class="" id="create_note"><center><a class="nav-link" href="content_admin_note.php" style="text-decoration:none;"><i class="fas fa-graduation-cap"></i> Create Note</a></center></span></div>
        <div class="row"><span class="" id="statistics"><center><a class="nav-link" href="content_admin_statistics.php" style="text-decoration:none;"><i class="fas fa-chart-bar"></i> Statistics</a></center></span></div>
        <div class="row"><span class="" id="student"><center><a class="nav-link" href="content_admin_student.php" style="text-decoration:none;"><i class="fas fa-users"></i> Students</a></center></span></div>
    </div>
    <div class="col-sm-10 main_content pages" style="display:block;">
        <br>
        <div class="row">
            <!-- Available section --> 
            <div class="col-sm-6">
                <div class="row">
                <div class="col-sm-11">
                <Label style="color:white;font-size:1.5rem;"><i class="fas fa-folder-open"></i> Available Quiz:</Label>
                <form method="POST" action="action_search_quiz.php">
                    <input name="search_quiz" type="text" placeholder="Search">
                    <!-- change below if possible-->
                    <div class="available">
                    <table border="0" class="table">
                        <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                            <th>Pin</th>
                            <th>Name</th>
                            <th>Collection</th>
                            <th>Difficulty</th>
                            <th>Action</th>
                        </tr>
                    <?php 
                    if(!isset($_SESSION['search_quiz'])){
                        $_SESSION['search_quiz']="";
                    }
                    $userID=$_SESSION['userID'];
                    $search_quiz=$_SESSION['search_quiz'];
                    if(!empty($search_quiz)){
                        require "connect_database.php"; 
                        // search quiz according to id or content or topic with the condition of it being public or user=owner
                        $list="SELECT * FROM quiz 
                               WHERE (quiz_status='public' OR user_id='$userID') 
                               AND (quiz_name LIKE '%$search_quiz%' OR quiz_pin_number LIKE '%$search_quiz%')";
                        $result=mysqli_query($con,$list);
                        while($row=mysqli_fetch_array($result)){
                            $a=$row['quiz_pin_number'];
                            $b=$row['quiz_name'];
                            $c=$row['quiz_content'];
                            $d=$row['quiz_level'];
                    ?>
                        <tr border="0" style="background-color:white;">
                            <td><?php echo $a; ?></td>
                            <td><?php echo $b; ?></td>
                            <td><?php echo $c; ?></td>
                            <td><?php echo $d; ?></td>
                            <!--TOOLS TO ADD QUIZ CONTENT INTO NEW QUIZ CREATING DIRECTORY FOR CREATING A NEW QUIZ-->
                            <td><a href="action_addquiz_to_quiz.php?quiz_content=<?php echo $c;?>"><i class="fas fa-folder-plus"></i></a></td>
                        </tr>
                    <?php
                        }
                    }else{
                        echo "<tr>It's Empty!</tr>";
                    }
                    ?> 
                    </table>
                    </div>
                </form>
                </div>
                <div class="col-sm-1"><div class="wall-line"></div></div>
                </div>
            </div>
            <div class="col-sm-6">
                <Label style="color:white;font-size:1.5rem;"><i class="	far fa-folder-open"></i> Available Question:</Label>
                <form method="POST" action="action_search_question.php">
                    <input name="search_question" type="text" placeholder="Search">
                    <!-- change below if possible-->
                    <div class="available">
                    <table border="0" class="table">
                        <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                            <th>ID</th>
                            <th>Topic </th>
                            <th>Content</th>
                            <th>Level</th>
                            <th>Action</th>
                        </tr>
                    <?php 
                    if(!isset($_SESSION['search_question'])){
                        $_SESSION['search_question']="";
                    }
                    $search_question=$_SESSION['search_question'];
                    $userID=$_SESSION['userID'];
                    if(!empty($search_question)){
                        require "connect_database.php";
                        // search quiz according to id or content or topic with the condition of it being public or user=owner
                        $list="SELECT * FROM question 
                               WHERE (question_status='public' OR user_id='$userID') 
                               AND (question_content LIKE '%$search_question%' OR 
                                    question_id LIKE '%$search_question%' OR 
                                    question_topic LIKE '%$search_question%')";
                        $result=mysqli_query($con,$list);
                        while($row=mysqli_fetch_array($result)){
                            $a=$row['question_id'];
                            $b=$row['question_topic'];
                            $c=$row['question_content'];
                            $d=$row['question_level'];
                    ?>
                        <tr border="0" style="background-color:white;">
                            <td><?php echo $a; ?></td>
                            <td><?php echo $b; ?></td>
                            <td><?php echo $c; ?></td>
                            <td><?php echo $d; ?></td>
                            <?php
                            if(in_array($a,$_SESSION['chosen_quiz_content'])){
                                echo '<td><i class="fa fa-check-circle-o"></i></td>';
                            }else{
                                // tools to add question into new quiz creating directory for creating a new quiz
                                echo '<td><a href="action_addques_to_quiz.php?ques_id='.$a.'"><i class="fas fa-folder-plus"></i></a></td>';
                            }
                            ?>
                        </tr>
                    <?php
                        }
                    }else{
                        echo "<tr>It's Empty!</tr>";
                    }
                    ?> 
                    </table>
                    </div>
                </form>
            </div>
        </div>
        <br><div class="border-line"></div><br>
        <div class="row">
        <div class="col-sm-12">
        <Label style="color:white;font-size:1.5rem;"><i class="	far fa-folder-open"></i> Your Quiz:</Label>
            <div class="available">
                <table border="0" class="table">
                    <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                        <th>Quiz Pin</th>
                        <th>Quiz Name</th>
                        <th>Collection</th>
                        <th>Difficulty</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                <?php 
                    // show quiz of user
                    require "connect_database.php";
                    $user_ID=$_SESSION['userID'];
                    $own="SELECT * FROM quiz WHERE user_id='$user_ID'";#HERE
                    $grabbing_own=mysqli_query($con,$own);
                    $counter=1;
                    $stat="";
                    while($row=mysqli_fetch_array($grabbing_own)){
                        $a=$row['quiz_pin_number'];
                        $b=$row['quiz_name'];
                        $c=$row['quiz_content'];
                        $d=$row['quiz_level'];
                        $status=$row['quiz_status'];
                        if($status=="private"){
                            $stat="fas fa-toggle-off";
                        }else if($status=="public"){
                            $stat="fas fa-toggle-on";
                        }
                ?>
                    <tr border="0" style="background-color:white;">
                        <td><?php echo $a; ?></td>
                        <td><?php echo $b; ?></td>
                        <td><?php echo $c; ?></td>
                        <td><?php echo $d; ?></td>
                        <td><i id='<?php echo "stat_btn".$counter;?>' onclick='<?php echo "changeStat".$counter."()";?>' class='<?php echo $stat;?>'></i></td>
                        <td>
                            <a href="action_addquiz_to_quiz.php?quiz_content=<?php echo $c;?>"><i class="fas fa-folder-plus"></i></a><a class="editor" style="margin-left:40px;" href="javascript:delete_quiz<?php echo $counter;?>()"><i class="fas fa-trash-alt"></i></a>
                        </td>
                        <script>
                        // all function have special id to prevent function overload
                        function <?php echo "delete_quiz".$counter;?>(){
                            var state=confirm("Are you sure of this action?");
                            if(state==true){
                                window.location="action_delete_quiz.php?quiz_pin_number=<?php echo $a;?>&quiz_name=<?php echo $b;?>&quiz_content=<?php echo $c;?>";
                            }
                        }
                        var <?php echo "status".$counter;?>="";
                        var <?php echo "stat_btn".$counter;?>=document.getElementById('<?php echo "stat_btn".$counter;?>');
                        function <?php echo "toggleStatus".$counter;?>(){
                            if(<?php echo "stat_btn".$counter;?>.className=="fas fa-toggle-off"){
                                <?php echo "stat_btn".$counter;?>.className="fas fa-toggle-on";
                                <?php echo "status".$counter;?>="private";
                            }else if(<?php echo "stat_btn".$counter;?>.className=="fas fa-toggle-on"){
                                <?php echo "stat_btn".$counter;?>.className="fas fa-toggle-off";
                                <?php echo "status".$counter;?>="public";
                            }
                        }
                        // change access status of quiz via ajax
                        function <?php echo "changeStat".$counter;?>(){
                            <?php echo "toggleStatus".$counter;?>();
                            var quiz_status=<?php echo "status".$counter;?>;
                            var request=new XMLHttpRequest();
                            var url="action_toggle_quiz.php";
                            var $POST="quiz_id="+<?php echo $a;?>+"&current="+quiz_status;
                            request.open("POST",url,true);
                            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                            request.send($POST);
                            
                        }
                        </script>
                    </tr>
                <?php
                    $counter+=1;
                    }
                ?> 
                </table>
            </div>
        </div>
        </div>
        <br><br><div class="border-line"></div><br>
        <!--CREATE SECTION-->
        <div class="row">
        <div class="col-sm-12">
        <Label style="color:white;font-size:1.5rem;"><i class="fas fa-edit"></i> Create your own Quiz:</Label>    
            <form method='POST' action="action_create_quiz.php">
                <span class="quiz_text">Quiz PIN:</span> <input name="quiz_pin" type="text" placeholder="maximum:10 key values">
                <span class="quiz_text">Quiz Level:</span> <input name="quiz_level" type="text" placeholder="scale 0-9" 
                onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                <span class="quiz_text">Quiz Name:</span> <input name="quiz_name" type="text"><br>
                <span class="quiz_text">Quiz Directory:</span>
            
                <table border="0" class="table">
                        <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                            <th>Question ID</th>
                            <th>Question Topic </th>
                            <th>Question Content</th>
                            <th>Question Level</th>
                            <th>Action</th>
                        </tr>
                        <?php 
                        $chosen_quiz_string="";
                        if(count($_SESSION['chosen_quiz_content'])){
                        for($i=0;$i<count($_SESSION['chosen_quiz_content']);$i++){
                            if($i==count($_SESSION['chosen_quiz_content'])-1){
                            $chosen_quiz_string=$chosen_quiz_string."'".$_SESSION['chosen_quiz_content'][$i]."'";   
                            }
                            else{
                            $chosen_quiz_string=$chosen_quiz_string."'".$_SESSION['chosen_quiz_content'][$i]."',";
                            }
                        }
                        }

                        if(!empty($_SESSION['chosen_quiz_content'])){
                            require "connect_database.php";
                            $list="SELECT * FROM question WHERE question_id IN (".$chosen_quiz_string.")";
                            $result=mysqli_query($con,$list);
                            while($row=mysqli_fetch_array($result)){
                                $a=$row['question_id'];
                                $b=$row['question_topic'];
                                $c=$row['question_content'];
                                $d=$row['question_level'];
                        ?>
                            <tr border="0" style="background-color:white;">
                                <td><?php echo $a; ?></td>
                                <td><?php echo $b; ?></td>
                                <td><?php echo $c; ?></td>
                                <td><?php echo $d; ?></td>
                                <td><a href="action_deleteques_from_quiz.php?ques_id=<?php echo $a;?>"><i class="fa fa-close"></i></a></td>
                            </tr>
                        <?php
                            }
                        }else{
                            echo "<tr>It's Empty!</tr>";
                        }
                    
                        ?> 
                    </table>
                <button class="create_quiz_btn" type="submit"><i class="fa fa-angle-right"></i> Create Quiz <i class="fa fa-angle-left"></i></button>
                <script>
                    // ajax reuqest to delete note created
                   function clearNote(){
                       var request=new XMLHttpRequest();
                       var url="action_clear_chosen.php";
                       var $POST="click=1";
                       request.open("POST",url,true);
                       request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                       request.send($POST);
                       location.reload();
                  }
               </script>
                <button id="clear_btn" class="create_quiz_btn" style="margin-left:770px;" onclick="clearNote();"><i class="fa fa-trash-o"></i> Clear All</button>
            </form>
        </div>
        </div>
    </div>
</div>