<?php
    if(!isset($_SESSION['chose_overall_stat'])){
        $_SESSION['chose_overall_stat']=0;
    }
    if(!isset($_SESSION['chose_quiz_stat'])){
        $_SESSION['chose_quiz_stat']=0;
    }
    if(!isset($_SESSION['overall_main'])){
        $_SESSION['overall_main']=0;
    }
    if(!isset($_SESSION['quiz_main'])){
        $_SESSION['quiz_main']=0;
    }
?>
<div class="row content_admin">
    <div class="col-sm-2 nav_tab" style="height:auto;">
        <div class="row"><span class="" id="create_quiz"><center><a class="nav-link" href="content_admin_quiz.php" style="text-decoration:none;"><i class="	far fa-calendar"></i> Create Quiz</a></center></span></div>
        <div class="row"><span style="font-size:1.25rem;" class="" id="create_question"><center><a class="nav-link" href="content_admin_question.php" style="text-decoration:none;"><i class="fab fa-accusoft"></i> Create Question</a></center></span></div>
        <div class="row"><span class="" id="create_note"><center><a class="nav-link" href="content_admin_note.php" style="text-decoration:none;"><i class="fas fa-graduation-cap"></i> Create Note</a></center></span></div>
        <div class="row"><span class="active_tabz" id="statistics"><center><a class="nav-link" href="content_admin_statistics.php" style="text-decoration:none;"><i class="fas fa-chart-bar"></i> Statistics</a></center></span></div>
        <div class="row"><span class="" id="student"><center><a class="nav-link" href="content_admin_student.php" style="text-decoration:none;"><i class="fas fa-users"></i> Students</a></center></span></div>
    </div>   
    <div class="col-sm-10 main_content pages" style="display:block;height:auto;color:white;">
        <div class="row">
           <div class="col-sm-12"><br><span style="font-size:1.7rem;"><i class="fas fa-chart-line"></i> Statistics:</span><br></div>
        </div>
        <div class="row">
            <!-- OVERALL QUIZ ANALYSIS-->
            <div class="col-sm-10">
                <span style="font-size:1.5rem;">Overall:</span>
            </div>
            <div class="col-sm-2">
                <span style="margin-left:30px;">
                    <select style="margin-top:5px;" name="" id="overall_stat">
                        <option value="0">All time</option>
                        <option value="1">Last 7 days</option>
                        <option value="2">Today</option>
                    </select>
                    <script>
                    var overall_opt=document.getElementById('overall_stat');
                    var current=<?php echo json_encode($_SESSION['chose_overall_stat']);?>;
                    overall_opt.selectedIndex=current;
                    overall_opt.onchange=function (){
                        var overall_opt_value=overall_opt.value;
                        var request=new XMLHttpRequest();
                        var $POST="overall_stat="+overall_opt_value;
                        var url="action_set_overall_stat.php";
                        request.open('POST',url,true);
                        request.setRequestHeader('Content-type','application/x-www-form-urlencoded');
                        request.send($POST);
                        request.onreadystatechange = function() {
                            if(request.readyState == 4 && request.status == 200) {
                                var someCallback = request.responseText;
                                if(someCallback=="ok"){
                                    location.reload();
                                }
                                
                            }
                        }   
                    }
                    </script>
                </span>   
            </div>
            
        </div>
        <div class="row">
            <div class="col-sm-8">
                <div class="row">
                    <div class="col-sm-10">
                        <br>
                        <div id="overall_chart1" style="width:600px;height:400px;margin-left:20px;box-shadow:0 15px 15px rgba(0, 0, 0, 0.8);"></div>
                    </div>
                    <div class="col-sm-2"><i id="overall_next_chart" onclick="nextOverall();" class="fas fa-angle-down" style="transform:scale(5);margin-left:55px;margin-right:auto;margin-top:220px;;margin-bottom:auto;"></i></div>
                </div>
                
            </div>
            <div class="col-sm-4">
                <br>
                <div id="overall_chart2" style="width:300px;height:200px;box-shadow:0 15px 15px rgba(0, 0, 0, 0.8);"></div>
                <div id="overall_chart3" style="width:300px;height:200px;box-shadow:0 15px 15px rgba(0, 0, 0, 0.8);"></div>
            </div>
        </div>
        <br><br><div class="border-line"></div>
        <div class="row">
            <div class="col-sm-12">
                <!--SPECIFIC QUIZ ANALYSIS -->
                <span style="font-size:1.5rem;">Specific Quiz:</span>
                <select name="" id="chose_quiz_pin">
                    <?php
                        // options for quiz analysis
                        $_SESSION['quiz_pin_list']=array();
                        $uid=$_SESSION['userID'];
                        require 'connect_database.php';
                        $grab_quiz="SELECT * FROM quiz WHERE user_id='$uid'";
                        $grabbing_quiz=mysqli_query($con,$grab_quiz);
                        while($row=mysqli_fetch_array($grabbing_quiz)){
                            $pin=$row['quiz_pin_number'];
                            $name=$row['quiz_name'];
                            array_push($_SESSION['quiz_pin_list'],$pin);
                            echo '<option value="'.$pin.'">'.$pin.' : '.$name.'</option>';
                        }
                        if(!isset($_SESSION['chose_quiz_pin'])){
                            $_SESSION['chose_quiz_pin']=$pin;
                        }
                    ?>
                </select>
                <script>
                // ajax request to change quiz chosen for analysis
                var quiz_pin=document.getElementById('chose_quiz_pin');
                var current=<?php echo json_encode(array_search($_SESSION['chose_quiz_pin'],$_SESSION['quiz_pin_list']));?>;
                quiz_pin.selectedIndex=current;
                quiz_pin.onchange=function (){
                    var quiz_pin_value=quiz_pin.value;
                    var request=new XMLHttpRequest();
                    var $POST="quiz_pin="+quiz_pin_value;
                    var url="action_set_quiz_pin.php";
                    request.open('POST',url,true);
                    request.setRequestHeader('Content-type','application/x-www-form-urlencoded');
                    request.send($POST);
                    request.onreadystatechange = function() {
                        if(request.readyState == 4 && request.status == 200) {
                            var someCallback = request.responseText;
                            if(someCallback=="ok"){
                                location.reload();
                            }
                            
                        }
                    }   
                }
                </script>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-10">
                <span style="font-size:1.5rem;">Quiz Info:</span>
            </div>
            <div class="col-sm-2">
                <span style="margin-left:20px;">
                    <select style="margin-top:5px;" name="" id="quiz_stat">
                        <option value="0">All time</option>
                        <option value="1">Last 7 days</option>
                        <option value="2">Today</option>
                    </select>
                    <script>
                    // ajax request to change format of statistics panel (All time,Week,Today)
                    var quiz_opt=document.getElementById('quiz_stat');
                    var current=<?php echo json_encode($_SESSION['chose_quiz_stat']);?>;
                    quiz_opt.selectedIndex=current;
                    quiz_opt.onchange=function (){
                        var quiz_opt_value=quiz_opt.value;
                        var request=new XMLHttpRequest();
                        var $POST="quiz_stat="+quiz_opt_value;
                        var url="action_set_quiz_stat.php";
                        request.open('POST',url,true);
                        request.setRequestHeader('Content-type','application/x-www-form-urlencoded');
                        request.send($POST);
                        request.onreadystatechange = function() {
                            if(request.readyState == 4 && request.status == 200) {
                                var someCallback = request.responseText;
                                if(someCallback=="ok"){
                                    location.reload();
                                }
                                
                            }
                        }   
                    }
                    </script>
                </span>   
            </div>
        </div>
        <div class="row">
            <div class="col-sm-8">
            <div class="row">
                    <div class="col-sm-10">
                        <br>
                        <div id="quiz_chart1" style="width:600px;height:400px;margin-left:20px;box-shadow:0 15px 15px rgba(0, 0, 0, 0.8);"></div>
                    </div>
                    <div class="col-sm-2"><i id="quiz_next_chart" onclick="nextQuiz();" class="fas fa-angle-down" style="transform:scale(4);margin-left:55px;margin-right:auto;margin-top:220px;;margin-bottom:auto;"></i></div>
                </div>
            </div>
            <div class="col-sm-4">
                <br>
                <div id="quiz_chart2" style="width:300px;height:200px;box-shadow:0 15px 15px rgba(0, 0, 0, 0.8);"></div>
                <div id="quiz_chart3" style="width:300px;height:200px;box-shadow:0 15px 15px rgba(0, 0, 0, 0.8);"></div>
            </div>
        </div>
        <br>
        <span style="font-size:1.5rem;">Results:</span>
        <br>
        <div class="row">
            <div class="col-sm-12" style="height:500px;">
                <div style="height:400px;overflow:auto;">
                    <table border="0" class="table">
                        <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                            <th>Rank</th>
                            <th>User id</th>
                            <th>Username</th>
                            <th>Quiz pin number</th>
                            <th>Accuracy</th>
                            <th>Time used</th>
                            <th>Timestamp</th>
                        </tr>
                        <?php 
                            // prints all reocrd in table 'result'
                            $chose_pin=$_SESSION['chose_quiz_pin'];
                            require 'connect_database.php';
                            $grab_quiz_result="SELECT pme_user.username,pme_user.user_id,result.result_accuracy,result.result_time_used,
                                               result.result_score,result.date_time,result.quiz_pin_number,result.user_id 
                                               FROM pme_user,result WHERE pme_user.user_id=result.user_id AND result.quiz_pin_number='$chose_pin' 
                                               ORDER BY result.result_score DESC ,result.result_time_used ASC";
                            $grabbing_quiz_result=mysqli_query($con,$grab_quiz_result);
                        if($grabbing_quiz_result){
                            $rank=1;
                            while($row=mysqli_fetch_array($grabbing_quiz_result)){
                                $a=$row['user_id'];
                                $b=$row['username'];
                                $c=$row['quiz_pin_number'];
                                $d=$row['result_accuracy'];
                                $e=$row['result_time_used'];
                                $f=$row['date_time'];
                            
                        ?>
                            <tr border="0" style="background-color:white;">
                                <td><?php echo $rank; ?></td>
                                <td><?php echo $a; ?></td>
                                <td><?php echo $b; ?></td>
                                <td><?php echo $c; ?></td>
                                <td><?php echo $d; ?></td>
                                <td><?php echo $e; ?></td>
                                <td><?php echo $f; ?></td>
                            </tr>
                        <?php
                            $rank+=1;
                            }
                        }
                        ?> 
                    </table>
                </div>
                <br>
            </div>
        </div>
        <script type="text/javascript">
        // configure data into the google chart 
        // this section is divided into two section (Overall & Specific)
        
            var state=0;
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawOverallChart);
            google.charts.setOnLoadCallback(drawQuizChart);
            
            //draw specific quiz chart
            function drawQuizChart(){
                var data_total_visit = new google.visualization.arrayToDataTable([
                    <?php 
                        require 'calendar.php';
                        require 'time.php';
                        require 'connect_database.php';
                        $uid=$_SESSION['userID'];
                        $cqid=$_SESSION['chose_quiz_pin'];
                        if($_SESSION['chose_quiz_stat']!="2"){
                            echo "['Day', 'Visitors'],";
                            $end=array_search(array($_SESSION['ending_point']),$_SESSION['date_list']);
                            $date_list=$_SESSION['date_list'];
                            if($_SESSION['chose_quiz_stat']=="0"){
                                $start=array_search(array($_SESSION['starting_point']),$_SESSION['date_list']);
                            }else if($_SESSION['chose_quiz_stat']=="1"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list'])-6;
                            }
                            for($i=$start;$i<$end+1;$i++){
                                $date=$date_list[$i];
                                $grab_overall="SELECT result.quiz_pin_number,quiz.quiz_pin_number,quiz.user_id FROM result,quiz WHERE result.date_time='$date[0]' AND quiz.user_id='$uid' AND result.quiz_pin_number=quiz.quiz_pin_number AND quiz.quiz_pin_number='$cqid'";
                                $grabbing_overall=mysqli_query($con,$grab_overall);
                                if($grabbing_overall){
                                    $num_of_visitors=0;
                                    while($row=mysqli_fetch_array($grabbing_overall)){
                                        $num_of_visitors+=1;
                                    }
                                }
                                echo "['".$date[0]."',".$num_of_visitors."],";
                            }
                        }
                        else if($_SESSION['chose_quiz_stat']=="2"){
                            echo "['Hour', 'Visitors'],";
                            $today=$_SESSION['ending_point'];
                            $end_time=array_search(array($_SESSION['current_time']),$_SESSION['time_list']);
                            $start_time=array_search(array("00:00:00"),$_SESSION['time_list']);
                            for($i=$start_time;$i<$end_time+1;$i++){
                                $time=$_SESSION['time_list'][$i];
                                $grab_overall="SELECT result.quiz_pin_number,quiz.quiz_pin_number,quiz.user_id,result.hour_time,result.date_time FROM result,quiz WHERE quiz.user_id='$uid' AND result.date_time='$today' AND result.hour_time='$time[0]' AND result.quiz_pin_number=quiz.quiz_pin_number AND quiz.quiz_pin_number='$cqid'";
                                $grabbing_overall=mysqli_query($con,$grab_overall);
                                if($grabbing_overall){
                                    $num_of_visitors=0;
                                    while($row=mysqli_fetch_array($grabbing_overall)){
                                        $num_of_visitors+=1;
                                    }
                                }
                                echo "['".$time[0]."',".$num_of_visitors."],";
                            }
                        }
                        
                    ?>
                    ]);

                var data_type= new google.visualization.arrayToDataTable([
                    ["Popularity of Wrong Question", "Visitors", { role: "style" } ],
                    
                    <?php
                        $uid=$_SESSION['userID'];
                        $cqid=$_SESSION['chose_quiz_pin'];
                        require 'connect_database.php';
                        if($_SESSION['chose_quiz_stat']=="0"){
                            $starting_date=$_SESSION['ending_point'];
                            $grab_type_number="SELECT result.quiz_pin_number,result.result_wrong_question,quiz.quiz_content,quiz.quiz_pin_number FROM quiz,result WHERE result.quiz_pin_number='$cqid' AND quiz.quiz_pin_number=result.quiz_pin_number AND result.date_time<='$starting_date'";
                            $grabbing_type_number=mysqli_query($con,$grab_type_number);
                            $wrong_question_list=array();
                            if($grabbing_type_number){
                                while($row=mysqli_fetch_array($grabbing_type_number)){
                                    $wrong=$row['result_wrong_question'];
                                    $wrong_question_list=array_merge($wrong_question_list,preg_split('/,/',$wrong)); 
                                    
                                }
                            }
                            $wrong_question_list=array_count_values($wrong_question_list);
                            unset($wrong_question_list['']);
                            $question_id_list=array_keys($wrong_question_list);
                            if(count($wrong_question_list)==0){
                                echo "['None',0,'#1c1c1c'],";
                            }else{
                                foreach($question_id_list as $id){
                                    echo "['".$id."',".$wrong_question_list[$id].",'#4b2387'],";
                                }     
                            }
                           
                        }else{ 
                            if($_SESSION['chose_quiz_stat']=="1"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list'])-6;
                            }else if($_SESSION['chose_quiz_stat']=="2"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list']);
                            }
                            $starting_date=$_SESSION['date_list'][$start][0];
                            $grab_type_number="SELECT result.quiz_pin_number,result.result_wrong_question,quiz.quiz_content,quiz.quiz_pin_number FROM quiz,result WHERE result.quiz_pin_number='$cqid' AND quiz.quiz_pin_number=result.quiz_pin_number AND result.date_time>='$starting_date'";
                            $grabbing_type_number=mysqli_query($con,$grab_type_number);
                            $wrong_question_list=array();
                            if($grabbing_type_number){
                                while($row=mysqli_fetch_array($grabbing_type_number)){
                                    $wrong=$row['result_wrong_question'];
                                    $wrong_question_list=array_merge($wrong_question_list,preg_split('/,/',$wrong)); 
                                    
                                }
                            }
                            $wrong_question_list=array_count_values($wrong_question_list);
                            unset($wrong_question_list['']);
                            $question_id_list=array_keys($wrong_question_list);
                            if(count($wrong_question_list)==0){
                                echo "['None',0,'#1c1c1c'],";
                            }else{
                                foreach($question_id_list as $id){
                                    echo "['".$id."',".$wrong_question_list[$id].",'#4b2387'],";
                                }     
                            }
                        }
                    ?>
                    ]);
                var data_form = new google.visualization.arrayToDataTable([
                    ["Form", "Visitors", { role: "style" } ],
                    <?php
                        $uid=$_SESSION['userID'];
                        $cqid=$_SESSION['chose_quiz_pin'];
                        require 'connect_database.php';
                        if($_SESSION['chose_quiz_stat']=="0"){
                            $starting_date=$_SESSION['ending_point'];
                            $f1=0;
                            $f2=0;
                            $f3=0;
                            $f4=0;
                            $grab_type_number="SELECT result.quiz_pin_number,result.user_id,pme_user.user_id,pme_user.user_form FROM result,pme_user WHERE result.quiz_pin_number='$cqid' AND result.user_id=pme_user.user_id AND result.date_time<='$starting_date'";
                            $grabbing_type_number=mysqli_query($con,$grab_type_number);
                            if($grabbing_type_number){
                                while($row=mysqli_fetch_array($grabbing_type_number)){
                                    $form=$row['user_form'];
                                    if($form==1){
                                        $f1+=1;
                                    }else if($form==2){
                                        $f2+=1;
                                    }else if($form==3){
                                        $f3+=1;
                                    }else if($form==4){
                                        $f4+=1;
                                    }                                    
                                }
                            }
                        
                            echo "['Form 1',".$f1.",'#4287f5'],";   
                            echo "['Form 2',".$f2.",'#4287f5'],";  
                            echo "['Form 3',".$f3.",'#4287f5'],";  
                            echo "['Form 4',".$f4.",'#4287f5'],"; 
                           
                        }else{ 
                            if($_SESSION['chose_quiz_stat']=="1"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list'])-6;
                            }else if($_SESSION['chose_quiz_stat']=="2"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list']);
                            }
                            $starting_date=$_SESSION['date_list'][$start][0];
                            $grab_type="SELECT quiz.quiz_pin_number,quiz.user_id FROM quiz WHERE quiz.user_id='$uid'";
                            $grabbing_type=mysqli_query($con,$grab_type);
                            $f1=0;
                            $f2=0;
                            $f3=0;
                            $f4=0;
                            
                            $grab_type_number="SELECT result.quiz_pin_number,result.date_time,result.user_id,pme_user.user_id,pme_user.user_form FROM result,pme_user WHERE result.quiz_pin_number='$cqid' AND result.user_id=pme_user.user_id AND result.date_time>='$starting_date'";
                            $grabbing_type_number=mysqli_query($con,$grab_type_number);
                            if($grabbing_type_number){
                                while($row=mysqli_fetch_array($grabbing_type_number)){
                                    $form=$row['user_form'];
                                    if($form==1){
                                        $f1+=1;
                                    }else if($form==2){
                                        $f2+=1;
                                    }else if($form==3){
                                        $f3+=1;
                                    }else if($form==4){
                                        $f4+=1;
                                    }
                                }
                            }
                                
                            echo "['Form 1',".$f1.",'#4287f5'],";   
                            echo "['Form 2',".$f2.",'#4287f5'],";  
                            echo "['Form 3',".$f3.",'#4287f5'],";  
                            echo "['Form 4',".$f4.",'#4287f5'],";  
                           
                        }
                    ?>
                    ]);
            
                
                var main_visit = {
                    title: 'Total Daily Visitors for Quiz',
                    width:600,
                    height:400,
                    series:{
                        0: { color: '#de0404' }
                    },
                    lineWidth:5,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Number of Visitors",
                        
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Time",
                    },
                    animation:{
                    duration: 5000,
                    easing: 'in'
                    },
                    };
                
                var side_visit = {
                    title: 'Total Daily Visitors for Quiz',
                    width:300,
                    height:200,
                    series:{
                        0: { color: '#de0404' }
                    },
                    lineWidth:3,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Number of Visitors",
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Time",
                    }
                    };
                var main_type = {
                    title: 'Popularity of Wrong Question',
                    width:600,
                    height:400,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Question ID",
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Tendency of students getting it wrong",
                    },
                    animation:{
                    duration: 5000,
                    easing: 'in'
                    },
                    };
                
                var side_type = {
                    title: 'Popularity of Wrong Question',
                    width:300,
                    height:200,
                    bar: {groupWidth: "95%"},
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Question ID",
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Tendency of students getting it wrong",
                    }
                    };
                var main_form = {
                    title: 'Age Demographic',
                    width:600,
                    height:400,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Age",
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Number of Visitors",
                    },
                    animation:{
                    duration: 5000,
                    easing: 'in'
                    },
                    };
                
                var side_form = {
                    title: 'Age Demographic',
                    width:300,
                    height:200,
                    bar: {groupWidth: "95%"},
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Age",
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'},
                        title:"Number of Visitors",
                    }
                    };
                var data_total_type = new google.visualization.DataView(data_type);
                    data_total_type.setColumns([0, 1,
                                    { calc: "stringify",
                                        sourceColumn: 1,
                                        type: "string",
                                        role: "annotation" },
                                    2]);
                var data_total_form = new google.visualization.DataView(data_form);
                    data_total_form.setColumns([0, 1,
                                    { calc: "stringify",
                                        sourceColumn: 1,
                                        type: "string",
                                        role: "annotation" },
                                    2]);
                var state=<?php echo json_encode($_SESSION['quiz_main']);?>;
                if(state==0){
                    var option_list=[main_visit,side_type,side_form];
                    var data_list=[data_total_visit,data_total_type,data_total_form];
                    var chart = new google.visualization.LineChart(document.getElementById('quiz_chart1'));
                    chart.draw(data_list[0], option_list[0]);
                    var chart2 = new google.visualization.BarChart(document.getElementById('quiz_chart2'));
                    chart2.draw(data_list[1], option_list[1]);
                    var chart3 = new google.visualization.BarChart(document.getElementById('quiz_chart3'));
                    chart3.draw(data_list[2], option_list[2]);   
                }else if(state==1){
                    var option_list=[main_type,side_form,side_visit];
                    var data_list=[data_total_type,data_total_form,data_total_visit];
                    var chart = new google.visualization.BarChart(document.getElementById('quiz_chart1'));
                    chart.draw(data_list[0], option_list[0]);
                    var chart2 = new google.visualization.BarChart(document.getElementById('quiz_chart2'));
                    chart2.draw(data_list[1], option_list[1]);
                    var chart3 = new google.visualization.LineChart(document.getElementById('quiz_chart3'));
                    chart3.draw(data_list[2], option_list[2]);    
                }else if(state==2){
                    var option_list=[main_form,side_visit,side_type];
                    var data_list=[data_total_form,data_total_visit,data_total_type];
                    var chart = new google.visualization.BarChart(document.getElementById('quiz_chart1'));
                    chart.draw(data_list[0], option_list[0]);
                    var chart2 = new google.visualization.LineChart(document.getElementById('quiz_chart2'));
                    chart2.draw(data_list[1], option_list[1]);
                    var chart3 = new google.visualization.BarChart(document.getElementById('quiz_chart3'));
                    chart3.draw(data_list[2], option_list[2]); 
                }  
            }
            
            // draw overall chart
            function drawOverallChart() {
                
                var data_total_visit = new google.visualization.arrayToDataTable([
                    <?php 
                        require "calendar.php";
                        require 'time.php';
                        require 'connect_database.php';
                        $uid=$_SESSION['userID'];
                        if($_SESSION['chose_overall_stat']!="2"){
                            echo "['Day', 'Visitors'],";
                            $end=array_search(array($_SESSION['ending_point']),$_SESSION['date_list']);
                            $date_list=$_SESSION['date_list'];
                            if($_SESSION['chose_overall_stat']=="0"){
                                $start=array_search(array($_SESSION['starting_point']),$_SESSION['date_list']);
                            }else if($_SESSION['chose_overall_stat']=="1"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list'])-6;
                            }
                            for($i=$start;$i<$end+1;$i++){
                                $date=$date_list[$i];
                                $grab_overall="SELECT result.quiz_pin_number,quiz.quiz_pin_number,quiz.user_id FROM result,quiz WHERE result.date_time='$date[0]' AND quiz.user_id='$uid' AND result.quiz_pin_number=quiz.quiz_pin_number";
                                $grabbing_overall=mysqli_query($con,$grab_overall);
                                if($grabbing_overall){
                                    $num_of_visitors=0;
                                    while($row=mysqli_fetch_array($grabbing_overall)){
                                        $num_of_visitors+=1;
                                    }
                                }
                                echo "['".$date[0]."',".$num_of_visitors."],";
                            }
                        }
                        else if($_SESSION['chose_overall_stat']=="2"){
                            echo "['Hour', 'Visitors'],";
                            $today=$_SESSION['ending_point'];
                            $end_time=array_search(array($_SESSION['current_time']),$_SESSION['time_list']);
                            $start_time=array_search(array("00:00:00"),$_SESSION['time_list']);
                            for($i=$start_time;$i<$end_time+1;$i++){
                                $time=$_SESSION['time_list'][$i];
                                $grab_overall="SELECT result.quiz_pin_number,quiz.quiz_pin_number,quiz.user_id,result.hour_time,result.date_time FROM result,quiz WHERE quiz.user_id='$uid' AND result.date_time='$today' AND result.hour_time='$time[0]' AND result.quiz_pin_number=quiz.quiz_pin_number";
                                $grabbing_overall=mysqli_query($con,$grab_overall);
                                if($grabbing_overall){
                                    $num_of_visitors=0;
                                    while($row=mysqli_fetch_array($grabbing_overall)){
                                        $num_of_visitors+=1;
                                    }
                                }
                                echo "['".$time[0]."',".$num_of_visitors."],";
                            }
                        }
                        
                    ?>
                    ]);

                var data_type= new google.visualization.arrayToDataTable([
                    ["PIN", "Visitors", { role: "style" } ],
                    <?php
                        $uid=$_SESSION['userID'];
                        require 'connect_database.php';
                        if($_SESSION['chose_overall_stat']=="0"){
                            $grab_type="SELECT quiz.quiz_pin_number,quiz.user_id FROM quiz WHERE quiz.user_id='$uid'";
                            $grabbing_type=mysqli_query($con,$grab_type);
                            if($grabbing_type){
                                while($row=mysqli_fetch_array($grabbing_type)){
                                    $qid=$row['quiz_pin_number'];
                                    $grab_type_number="SELECT result.quiz_pin_number FROM result WHERE result.quiz_pin_number='$qid'";
                                    $grabbing_type_number=mysqli_query($con,$grab_type_number);
                                    $num=0;
                                    if($grabbing_type_number){
                                        while($row=mysqli_fetch_array($grabbing_type_number)){
                                            $num+=1;
                                        }
                                    }
                                    echo "['".$qid."',".$num.",'#4b2387'],";

                                }
                            }    
                        }else{ 
                            if($_SESSION['chose_overall_stat']=="1"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list'])-6;
                            }else if($_SESSION['chose_overall_stat']=="2"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list']);
                            }
                            $starting_date=$_SESSION['date_list'][$start][0];
                            $grab_type="SELECT quiz.quiz_pin_number,quiz.user_id FROM quiz WHERE quiz.user_id='$uid'";
                            $grabbing_type=mysqli_query($con,$grab_type);
                            if($grabbing_type){
                                while($row=mysqli_fetch_array($grabbing_type)){
                                    $qid=$row['quiz_pin_number'];
                                    $grab_type_number="SELECT result.quiz_pin_number,result.date_time FROM result WHERE result.quiz_pin_number='$qid' AND result.date_time>='$starting_date'";
                                    $grabbing_type_number=mysqli_query($con,$grab_type_number);
                                    $num=0;
                                    if($grabbing_type_number){
                                        while($row=mysqli_fetch_array($grabbing_type_number)){
                                            $num+=1;
                                        }
                                    }
                                    echo "['".$qid."',".$num.",'#4b2387'],";

                                }
                            }
                        }
                    ?>
                    ]);
                var data_form = new google.visualization.arrayToDataTable([
                    ["Form", "Visitors", { role: "style" } ],
                    <?php
                        $uid=$_SESSION['userID'];
                        require 'connect_database.php';
                        if($_SESSION['chose_overall_stat']=="0"){
                            $grab_type="SELECT quiz.quiz_pin_number,quiz.user_id FROM quiz WHERE quiz.user_id='$uid'";
                            $grabbing_type=mysqli_query($con,$grab_type);
                            $f1=0;
                            $f2=0;
                            $f3=0;
                            $f4=0;
                            if($grabbing_type){
                                while($row=mysqli_fetch_array($grabbing_type)){
                                    $qid=$row['quiz_pin_number'];
                                    $grab_type_number="SELECT result.quiz_pin_number,result.user_id,pme_user.user_id,pme_user.user_form FROM result,pme_user WHERE result.quiz_pin_number='$qid' AND result.user_id=pme_user.user_id";
                                    $grabbing_type_number=mysqli_query($con,$grab_type_number);
                                    if($grabbing_type_number){
                                        while($row=mysqli_fetch_array($grabbing_type_number)){
                                            $form=$row['user_form'];
                                            if($form==1){
                                                $f1+=1;
                                            }else if($form==2){
                                                $f2+=1;
                                            }else if($form==3){
                                                $f3+=1;
                                            }else if($form==4){
                                                $f4+=1;
                                            }                                    
                                        }
                                    }
                                }
                                echo "['Form 1',".$f1.",'#4287f5'],";   
                                echo "['Form 2',".$f2.",'#4287f5'],";  
                                echo "['Form 3',".$f3.",'#4287f5'],";  
                                echo "['Form 4',".$f4.",'#4287f5'],"; 
                            } 
                        }else{ 
                            if($_SESSION['chose_overall_stat']=="1"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list'])-6;
                            }else if($_SESSION['chose_overall_stat']=="2"){
                                $start=array_search(array($_SESSION['ending_point']),$_SESSION['date_list']);
                            }
                            $starting_date=$_SESSION['date_list'][$start][0];
                            $grab_type="SELECT quiz.quiz_pin_number,quiz.user_id FROM quiz WHERE quiz.user_id='$uid'";
                            $grabbing_type=mysqli_query($con,$grab_type);
                            $f1=0;
                            $f2=0;
                            $f3=0;
                            $f4=0;
                            if($grabbing_type){
                                while($row=mysqli_fetch_array($grabbing_type)){
                                    $qid=$row['quiz_pin_number'];
                                    $grab_type_number="SELECT result.quiz_pin_number,result.date_time,result.user_id,pme_user.user_id,pme_user.user_form FROM result,pme_user WHERE result.quiz_pin_number='$qid' AND result.user_id=pme_user.user_id AND result.date_time>='$starting_date'";
                                    $grabbing_type_number=mysqli_query($con,$grab_type_number);
                                    if($grabbing_type_number){
                                        while($row=mysqli_fetch_array($grabbing_type_number)){
                                            $form=$row['user_form'];
                                            if($form==1){
                                                $f1+=1;
                                            }else if($form==2){
                                                $f2+=1;
                                            }else if($form==3){
                                                $f3+=1;
                                            }else if($form==4){
                                                $f4+=1;
                                            }
                                        }
                                    }
                                }
                                echo "['Form 1',".$f1.",'#4287f5'],";   
                                echo "['Form 2',".$f2.",'#4287f5'],";  
                                echo "['Form 3',".$f3.",'#4287f5'],";  
                                echo "['Form 4',".$f4.",'#4287f5'],";  
                            } 
                        }
                    ?>
                    ]);
            
                
                var main_visit = {
                    title: 'Total Daily Visitors for Quiz',
                    width:600,
                    height:400,
                    series:{
                        0: { color: '#de0404' }
                    },
                    lineWidth:5,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    animation:{
                    duration: 5000,
                    easing: 'in'
                    },
                    };
                
                var side_visit = {
                    title: 'Total Daily Visitors for Quiz',
                    width:300,
                    height:200,
                    series:{
                        0: { color: '#de0404' }
                    },
                    lineWidth:3,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'}
                    }
                    };
                var main_type = {
                    title: 'Percentage Distribution for Quiz Visited',
                    width:600,
                    height:400,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    animation:{
                    duration: 5000,
                    easing: 'in'
                    },
                    };
                
                var side_type = {
                    title: 'Percentage Distribution for Quiz Visited',
                    width:300,
                    height:200,
                    bar: {groupWidth: "95%"},
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'}
                    }
                    };
                var main_form = {
                    title: 'Age Demographic',
                    width:600,
                    height:400,
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    animation:{
                    duration: 5000,
                    easing: 'in'
                    },
                    };
                
                var side_form = {
                    title: 'Age Demographic',
                    width:300,
                    height:200,
                    bar: {groupWidth: "95%"},
                    legend: 'none',
                    backgroundColor:{
                        fill:'#c4c1b9',
                        fillOpacity:0.4,
                    },
                    vAxis: {
                        textStyle:{color: '#1c1c1c'}
                    },
                    hAxis: {
                        textStyle:{color: '#1c1c1c'}
                    }
                    };
                var data_total_type = new google.visualization.DataView(data_type);
                    data_total_type.setColumns([0, 1,
                                    { calc: "stringify",
                                        sourceColumn: 1,
                                        type: "string",
                                        role: "annotation" },
                                    2]);
                var data_total_form = new google.visualization.DataView(data_form);
                    data_total_form.setColumns([0, 1,
                                    { calc: "stringify",
                                        sourceColumn: 1,
                                        type: "string",
                                        role: "annotation" },
                                    2]);
                var state=<?php echo json_encode($_SESSION['overall_main']);?>;
                if(state==0){
                    var option_list=[main_visit,side_type,side_form];
                    var data_list=[data_total_visit,data_total_type,data_total_form];
                    var chart = new google.visualization.LineChart(document.getElementById('overall_chart1'));
                    chart.draw(data_list[0], option_list[0]);
                    var chart2 = new google.visualization.BarChart(document.getElementById('overall_chart2'));
                    chart2.draw(data_list[1], option_list[1]);
                    var chart3 = new google.visualization.BarChart(document.getElementById('overall_chart3'));
                    chart3.draw(data_list[2], option_list[2]);   
                }else if(state==1){
                    var option_list=[main_type,side_form,side_visit];
                    var data_list=[data_total_type,data_total_form,data_total_visit];
                    var chart = new google.visualization.BarChart(document.getElementById('overall_chart1'));
                    chart.draw(data_list[0], option_list[0]);
                    var chart2 = new google.visualization.BarChart(document.getElementById('overall_chart2'));
                    chart2.draw(data_list[1], option_list[1]);
                    var chart3 = new google.visualization.LineChart(document.getElementById('overall_chart3'));
                    chart3.draw(data_list[2], option_list[2]);    
                }else if(state==2){
                    var option_list=[main_form,side_visit,side_type];
                    var data_list=[data_total_form,data_total_visit,data_total_type];
                    var chart = new google.visualization.BarChart(document.getElementById('overall_chart1'));
                    chart.draw(data_list[0], option_list[0]);
                    var chart2 = new google.visualization.LineChart(document.getElementById('overall_chart2'));
                    chart2.draw(data_list[1], option_list[1]);
                    var chart3 = new google.visualization.BarChart(document.getElementById('overall_chart3'));
                    chart3.draw(data_list[2], option_list[2]); 
                }  
            }
            // functions to swtich statistics panel orientation
            var next_overall_chart=document.getElementById('overall_next_chart');
            function nextOverall(){
                var request=new XMLHttpRequest();
                    var $POST="add=1";
                    var url="action_switch_panel_overall.php";
                    request.open('POST',url,true);
                    request.setRequestHeader('Content-type','application/x-www-form-urlencoded');
                    request.send($POST);
                    request.onreadystatechange = function() {
                        if(request.readyState == 4 && request.status == 200) {
                            var someCallback = request.responseText;
                            if(someCallback=="success"){
                                location.reload();
                            }
                            
                        }
                    }   
            }            
            var next_quiz_chart=document.getElementById('quiz_next_chart');
            function nextQuiz(){
                var request=new XMLHttpRequest();
                    var $POST="add=1";
                    var url="action_switch_panel_quiz.php";
                    request.open('POST',url,true);
                    request.setRequestHeader('Content-type','application/x-www-form-urlencoded');
                    request.send($POST);
                    request.onreadystatechange = function() {
                        if(request.readyState == 4 && request.status == 200) {
                            var someCallback = request.responseText;
                            if(someCallback=="success"){
                                location.reload();
                            }
                            
                        }
                    }   
            }            
        </script>
       
   
    

    </div>
</div>