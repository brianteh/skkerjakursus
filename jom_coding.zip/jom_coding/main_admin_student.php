<div class="row content_admin">
    <div class="col-sm-2 nav_tab" style="height:auto;">
        <div class="row"><span class="" id="create_quiz"><center><a class="nav-link" href="content_admin_quiz.php" style="text-decoration:none;"><i class="	far fa-calendar"></i> Create Quiz</a></center></span></div>
        <div class="row"><span style="font-size:1.25rem;" class="" id="create_question"><center><a class="nav-link" href="content_admin_question.php" style="text-decoration:none;"><i class="fab fa-accusoft"></i> Create Question</a></center></span></div>
        <div class="row"><span class="" id="create_note"><center><a class="nav-link" href="content_admin_note.php" style="text-decoration:none;"><i class="fas fa-graduation-cap"></i> Create Note</a></center></span></div>
        <div class="row"><span class="" id="statistics"><center><a class="nav-link" href="content_admin_statistics.php" style="text-decoration:none;"><i class="fas fa-chart-bar"></i> Statistics</a></center></span></div>
        <div class="row"><span class="active_tabz" id="student"><center><a class="nav-link" href="content_admin_student.php" style="text-decoration:none;"><i class="fas fa-users"></i> Students</a></center></span></div>
    </div>  
    <div class="col-sm-10 main_content pages" style="display:block;height:auto;"> 
        <br>
        <Label style="color:white;font-size:1.5rem;"><i class="fas fa-user-plus"></i>  Add Users:</Label>
        <form action="action_import_user.php" method="POST" enctype="multipart/form-data">
            <input name="import_user" style="border-radius:25px;padding:20px;background-color:rgba(168, 168, 163, 0.37);color:white;" type="file"/> <button name="btn_import_user" type="submit" style="border-radius:25px;padding:20px;background-color:#1c1c1c;color:white;outline:none;border:2px solid #1c1c1c;margin-top:-4px;"><i class="fa fa-upload"></i></button>
        </form>
        <br><br><div class="border-line"></div>
        <br>
        <Label style="color:white;font-size:1.5rem;"><i class="fab fa-searchengin"></i>  Monitor Users:</Label>
            <div style="height:400px;overflow:auto;">
                <table border="0" class="table">
                    <tr style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
                        <th>No.</th>
                        <th>User id</th>
                        <th>Username</th>
                        <th>User Form</th>
                        <th>Action</th>
                    </tr>
                    <?php 
                        // show user which has the same class id but with 'user' status only
                        require 'connect_database.php';
                        $class_id=$_SESSION['class_id'];
                        $grab_student="SELECT * FROM pme_user WHERE acc_status='user' AND class_id='$class_id';";
                        $grabbing_student=mysqli_query($con,$grab_student);
                    if($grabbing_student){
                        $rank=1;
                        while($row=mysqli_fetch_array($grabbing_student)){
                            $a=$row['user_id'];
                            $b=$row['username'];
                            $c=$row['user_form'];
                           
                        
                    ?>
                        <tr border="0" style="background-color:white;">
                            <td><?php echo $rank; ?></td>
                            <td><?php echo $a; ?></td>
                            <td><?php echo $b; ?></td>
                            <td><?php echo $c; ?></td>
                            <!--PRINT PDF-->
                            <td><a href="content_student_data.php?user_id=<?php echo $a;?>"><i class="fas fa-eye"></i></a></td>
                        </tr>
                    <?php
                        $rank+=1;
                        }
                    }
                    ?> 
                </table>
            </div>
    </div>
</div>