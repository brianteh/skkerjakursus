<audio controls id="resultAudio"style="display:none;">
    <?php
        if($_SESSION['quiz_outcome']){
            echo ' <source src="music/victory.mp3" type="audio/mpeg">';
        }
    ?>
    <script>document.getElementById("resultAudio").play();</script>
</audio>
    
<div class="row" style="height:50px;"></div>
<div class="row">
<div class="col-sm-2"></div>
<div class="col-sm-8">
    <span style="color:white;font-size:1.5rem;"><i class="fa fa-institution"></i> Ranking results</span><br><br>
    <div style="height:300px;overflow:auto;">
    <table cellpadding="10" cellspacing="0" border="0" class="table">
        <tr cellpadding="10" cellspacing="0" border="0" style="border-bottom:2px solid #1C1C1C;border-top:2px solid #1C1C1C;color:white;background-color:#1C1C1C;">
            <th>Rank <i class="fa fa-trophy"></i></th>
            <th>Username <i class="fas fa-user-alt"></i></th>
            <th>Result <i class="far fa-clipboard"></i></th>
            <th>Accuracy <i class="fa fa-bullseye"></i></th>
            <th>Time used <i class="fa fa-history"></i></th>
        </tr>
        <?php
            require 'connect_database.php';
            if($_SESSION['quiz_type']=="builtin"){
                echo 
                '
                <tr  style="background-color:white;">
                    <td>None</td>
                    <td>'.$_SESSION['username'].'</td>
                    <td>'.$_SESSION['result_score'].'</td>
                    <td>'.$_SESSION['result_accuracy'].'</td>
                    <td>'.$_SESSION['time_used'].'</td>
                </tr>
                ';
            }else if($_SESSION['quiz_type']=="custom"){
                $pin=$_SESSION['quiz_code'];
                $grab_result="SELECT * FROM result,pme_user WHERE quiz_pin_number='$pin' AND result.user_id=pme_user.user_id ORDER BY result_score DESC,result_accuracy DESC,result_time_used ASC";
                $grabbing_result=mysqli_query($con,$grab_result);
                $rank=1;
                while($row=mysqli_fetch_array($grabbing_result)){
                    $result_score=$row['result_score'];
                    $result_time_used=$row['result_time_used'];
                    $result_accuracy=$row['result_accuracy'];
                    $user_id=$row['user_id'];
                    $username=$row['username'];
                    $wrong_ques=$row['result_wrong_question'];
                    if($_SESSION['time_used']==$result_time_used && $_SESSION['userID']==$user_id && $_SESSION['result_score']==$result_score && $_SESSION['wrong_answer_list']==$wrong_ques){
                        echo '<tr style="background-color:#535c66; color:white;">';
                    }else{
                        echo '<tr style="background-color:white; color:black;">';
                    }
                ?>
                
                    <td><?php echo $rank;?></td>
                    <td><?php echo $username;?></td>
                    <td><?php echo $result_score;?></td>
                    <td><?php echo $result_accuracy;?></td>
                    <td><?php echo $result_time_used;?></td>
                </tr>
        <?php
                $rank+=1;
                }
            }
            
        ?>
    </table>
    </div>
</div>
<div class="col-sm-2"></div>
</div>
<br>
<div class="row">
<div class="col-sm-2"></div>
<div class="col-sm-8">
<br>
<center>
<a href="content_quiz.php" class="result_btn" style="text-decoration:none;"><i class="fa fa-angle-right"></i> Play Again <i class="fa fa-angle-left"></i></a>
<br><br><br>
<a href="content_home.php" class="result_btn" style="text-decoration:none;"><i class="fa fa-home"></i> Home</a>
<br><br><br>
<?php
    require 'connect_database.php';
    foreach($_SESSION['question_seq'] as $question){
        $ques_no=array_search($question,$_SESSION['question_seq'])+1;
        $grab_answer="SELECT * FROM question WHERE question_id='$question'";
        $grabbing_answer=mysqli_query($con,$grab_answer);
        while($row=mysqli_fetch_array($grabbing_answer)){
            $show_content=$row['question_content'];
            $show_answer=$row['question_answer'];
            $show_select=$row['question_select'];
            $show_type=$row['question_type'];
        }
        if($show_type=="SUB"){
            // subjective show answer if correct
            if($_SESSION['current_answer_list'][$ques_no-1]==$show_answer){
                echo '
                <div class="row review_question_sub" style="background-color:#82e37d;border-radius:10px;height:150px;">
                <div class="col-sm-1"><br><span style="font-size:1.2rem;color:#205c1d;">'.$ques_no.'.</span></div>
                <div class="col-sm-10"><br>
                    <div class="row"><span style="font-size:1.2rem;color:#387d34;">'.$show_content.'</span></div><br><br>
                    <div class="row">
                        <div class="col-sm-0.5"></div>
                        <div class="col-sm-11">
                            <span style="font-size:1.2rem;">Your answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:green;"> '.$_SESSION['current_answer_list'][$ques_no-1].' </span>
                            <span style="margin-left:10px;"><i class="fa fa-angle-double-right" style="font-size:1.3rem;"></i></span>
                            <span style="font-size:1.2rem;">Correct answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:green;">'.$show_answer.'</span>
                        </div>
                        <div class="col-sm-0.5"></div>
                    </div>
                </div>
                <div class="col-sm-1"><br><i class="fa fa-check" style="border-radius:5px;padding:5px;height:25px;border:2px solid #afe8ac;color:#27ba20;"></i></div>
                </div><br>
                ';
            }else{
            // subjective show answer if wrong           
            echo '
            <div class="row review_question_sub" style="background-color:#f08662;border-radius:10px;height:150px;">
            <div class="col-sm-1"><br><span style="font-size:1.2rem;color:#450909;">'.$ques_no.'.</span></div>
            <div class="col-sm-10"><br>
                <div class="row"><span style="font-size:1.2rem;color:#8c1c1c;">'.$show_content.'</span></div><br><br>
                <div class="row">
                    <div class="col-sm-0.5"></div>
                    <div class="col-sm-11">
            ';          
            if($_SESSION['current_answer_list'][$ques_no-1]==""){
                echo'<span style="font-size:1.2rem;">Your answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:red;"> None </span>';
            }else{    
                echo'<span style="font-size:1.2rem;">Your answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:red;"> '.$_SESSION['current_answer_list'][$ques_no-1].' </span>';
            }  
            echo'
                        <span style="margin-left:10px;"><i class="fa fa-angle-double-right" style="font-size:1.3rem;"></i></span>
                        <span style="font-size:1.2rem;">Correct answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:red;">'.$show_answer.'</span>
                    </div>
                    <div class="col-sm-0.5"></div>
                </div>
            </div>
            <div class="col-sm-1"><br><i class="fa fa-close" style="border-radius:5px;padding:5px;height:25px;border:2px solid #e6a3a3;color:#b81106;"></i></div>
            </div><br>
            ';
            }
        }else if($show_type=="OBJ"){
            // objective show answer if correct
            if($_SESSION['current_answer_list'][$ques_no-1]==$show_answer){
                echo 
                '
                <div class="row review_question_sub" style="background-color:#82e37d;border-radius:10px;height:220px;">
                <div class="col-sm-1"><br><span style="font-size:1.2rem;color:#205c1d;">'.$ques_no.'.</span></div>
                <div class="col-sm-10"><br>
                    <div class="row"><span style="font-size:1.2rem;color:#387d34;">'.$show_content.'</span></div><br><br>
                    <div class="row">
                ';  
                $show_obj=preg_split("/-/",$show_select);
                foreach($show_obj as $select){
                    if($select==$show_answer){
                        echo '<div class="col-sm-'.(int)(12/count($show_obj)).'"><div style="background-color:white;border-radius:15px;border:0px solid white;padding:10px;"><span style="font-size:1.2rem;color:#387d34;">'.$select.'</span></div></div>'; 
                    }else{
                        echo '<div class="col-sm-'.(int)(12/count($show_obj)).'"><div style="border-radius:15px;border:2px solid white;padding:10px;"><span style="font-size:1.2rem;color:#387d34;">'.$select.'</span></div></div>'; 
                    }
                }

                echo '  
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-0.5"></div>
                        <div class="col-sm-11">
                            <span style="font-size:1.2rem;">Your answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:green;"> '.$_SESSION['current_answer_list'][$ques_no-1].' </span>
                            <span style="margin-left:10px;"><i class="fa fa-angle-double-right" style="font-size:1.3rem;"></i></span>
                            <span style="font-size:1.2rem;">Correct answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:green;">'.$show_answer.'</span>
                        </div>
                        <div class="col-sm-0.5"></div>
                    </div>
                </div>
                <div class="col-sm-1"><br><i class="fa fa-check" style="border-radius:5px;padding:5px;height:25px;border:2px solid #afe8ac;color:#27ba20;"></i></div>
                </div><br>
                ';
            }else{
            // objective show answer if wrong  
                echo 
                '
                <div class="row review_question_sub" style="background-color:#f08662;border-radius:10px;height:220px;">
                <div class="col-sm-1"><br><span style="font-size:1.2rem;color:#450909;">'.$ques_no.'.</span></div>
                <div class="col-sm-10"><br>
                    <div class="row"><span style="font-size:1.2rem;color:#8c1c1c;">'.$show_content.'</span></div><br><br>
                    <div class="row">
                ';  
                $show_obj=preg_split("/-/",$show_select);
                foreach($show_obj as $select){
                    if($select==$show_answer){
                        echo '<div class="col-sm-'.(int)(12/count($show_obj)).'"><div style="background-color:white;border-radius:15px;border:0px solid white;padding:10px;"><span style="font-size:1.2rem;color:#8c1c1c;">'.$select.'</span></div></div>'; 
                    }else{
                        echo '<div class="col-sm-'.(int)(12/count($show_obj)).'"><div style="border-radius:15px;border:2px solid white;padding:10px;"><span style="font-size:1.2rem;color:#8c1c1c;">'.$select.'</span></div></div>'; 
                    }
                }

                echo '  
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-0.5"></div>
                        <div class="col-sm-11">
                ';
                if($_SESSION['current_answer_list'][$ques_no-1]==""){
                    echo'<span style="font-size:1.2rem;">Your answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:red;"> None </span>';
                }else{    
                    echo'<span style="font-size:1.2rem;">Your answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:red;"> '.$_SESSION['current_answer_list'][$ques_no-1].' </span>';
                }  
                echo'
                            <span style="margin-left:10px;"><i class="fa fa-angle-double-right" style="font-size:1.3rem;"></i></span>
                            <span style="font-size:1.2rem;">Correct answer : </span><span style="font-size:1.2rem;background-color:white;padding:5px;border-radius:10px;color:red;">'.$show_answer.'</span>
                        </div>
                        <div class="col-sm-0.5"></div>
                    </div>
                </div>
                <div class="col-sm-1"><br><i class="fa fa-close" style="border-radius:5px;padding:5px;height:25px;border:2px solid #e6a3a3;color:#b81106;"></i></div>
                </div><br>
                ';
            }
        }
    }
?>
<div class="row"></div>
</center>
</div>
<div class="col-sm-2"></div>
</div>