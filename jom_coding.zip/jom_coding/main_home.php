<div class="row home">
    <div class="col-sm-3">
    </div>
    <div class="col-sm-6 search_panel">
    <br><br>
    <form method="POST">
        <input class="field" type="text" placeholder="Type your questions here" name="searchideas" style="width:550px;margin-right:0px;border-bottom-right-radius:0px;border-top-right-radius:0px;">
        <button style="margin-left:-5px;" type="submit" class="search_btn" name="search_btn">Search <i class="fas fa-search"></i></button>
    </form>
        <br>
        <?php
        require "connect_database.php";
        if(isset($_POST['search_btn'])){
            $search=$_POST['searchideas'];
            if(empty($search)){
            
            }
            else{
            // search field
            $search_query="SELECT * FROM note WHERE note_status='public' 
                           AND (note_topic LIKE '%$search%' OR note_title LIKE '%$search%' OR note_content LIKE '%$search%')";
            $searchResult=mysqli_query($con,$search_query);
            // show search content
            $counter=1;
            while($row=mysqli_fetch_array($searchResult)){
                $note_id=$row['note_id'];
                $topic=$row['note_topic'];
                $content=$row['note_content'];
                $title=$row['note_title'];
               
        ?>
        <br>
        <div class="row" id="search_result" style="box-shadow:0 10px 10px rgba(0,0,0,0.2);padding:15px;border:2px solid white;border-radius:15px;">
        <div class="col-sm-11"> 
        <span style="margin-left:0px;margin-right:auto;color:white;font-size:1.5rem;"><span><a style="font-size:1rem;color:rgba(244,244,244, 0.3):block;font-family:OCR A Std, monospace;" href="content_note_chosen.php?note_id=<?php echo $note_id;?>">Find out more..</a></span><br><?php echo "Topic : ".$topic."<br>Title : ".$title;?></span>
        <br>
        <br>
        <span id="<?php echo "content".$counter;?>" style="margin-left:0px;margin-right:auto;display:none;width:630px;height:200px;overflow:auto;"><?php echo $content;?></span>
        </div>
        <div class="col-sm-1" style="display:flex;justify-content:flex-end;color:#1c1c1c;"><i id="<?php echo "show_content".$counter;?>" style="font-size:1.3rem;" class="fas fa-angle-down"></i></div>
        
        <script>
            // click arrow up to close content & click arrow down to show content
            // all function are added with a counter to prevent function overload
            var <?php echo "show_content".$counter;?>=document.getElementById('<?php echo "show_content".$counter;?>'); 
            var <?php echo "content".$counter;?>=document.getElementById('<?php echo "content".$counter;?>');
            var a=0;
            <?php echo "show_content".$counter;?>.addEventListener("click",function(){
                if(a==0){
                    <?php echo "content".$counter;?>.style.display="block";
                    <?php echo "show_content".$counter;?>.className="fas fa-angle-up";
                    a=1;
                }else if(a==1){
                    <?php echo "content".$counter;?>.style.display="none";
                    <?php echo "show_content".$counter;?>.className="fas fa-angle-down";
                    a=0;
                }
            });
        </script>
        </div>
        <br>
        <?php 
                $counter+=1;       
            }
            }
        }
        ?>

        <br><br><br><br>
        <!--SEE RECENT NOTES by adding cookies-->
        <div>
        <svg class="rocket" width="238" height="168" viewBox="0 0 238 168" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M87 84.5C87 96.3741 69.0913 106 47 106C-3 91 0.999997 94 0.999997 94C17 78 31.9086 63.3281 54 63.3281C76.0914 63.3281 87 72.6258 87 84.5Z" fill="#EC6214"/>
        <ellipse cx="64.5" cy="83.5" rx="23.5" ry="13.5" fill="#EBB322"/>
        <path d="M132.053 47.7996L63.4474 87.9001L64.1644 6.4969L132.053 47.7996Z" fill="#E35454"/>
        <path d="M131.41 120.797L62.8046 160.897L63.5215 79.4941L131.41 120.797Z" fill="#E35454"/>
        <ellipse cx="147.231" cy="84.4347" rx="36.5" ry="89.5" transform="rotate(90.5046 147.231 84.4347)" fill="#446CD3"/>
        <path d="M146.588 120.93C96.2336 120.487 55.5573 103.786 55.7348 83.6288C55.9123 63.4712 96.8765 47.4898 147.231 47.9332C209.882 48.485 218.906 64.9067 218.728 85.0643C218.551 105.222 209.239 121.482 146.588 120.93Z" fill="#C4C4C4"/>
        <ellipse cx="165.217" cy="86.0931" rx="19" ry="28.5" transform="rotate(90.5046 165.217 86.0931)" fill="#5DB2BE"/>
        <path d="M170.06 103.934C154.321 103.795 141.636 95.1767 141.729 84.6837C141.821 74.1907 154.656 65.7969 170.395 65.9355C186.135 66.0741 198.819 74.6927 198.727 85.1857C198.634 95.6787 185.8 104.073 170.06 103.934Z" fill="#A9E5ED"/>
        <rect x="114.772" y="79.6486" width="8" height="69" transform="rotate(90.5046 114.772 79.6486)" fill="#E35454"/>
        </svg>
        </div>
    </div>   
    <div class="col-sm-3"><!-- ASSIGNMENT if possible--></div>
</div>