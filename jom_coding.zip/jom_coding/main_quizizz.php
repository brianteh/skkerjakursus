<div class="question">
    <audio controls id="quizAudio" style="display:none;">
    <?php 
    // different music by changing it in settings
    if($_SESSION['toggle-music']){   
        if($_SESSION['music']=="nature"){
            echo '<source src="music/nature_genre.mp3" type="audio/mpeg">';
        }else if($_SESSION['music']=='cyberpunk'){
            echo '<source src="music/space_genre.mp3" type="audio/mpeg">';
        }else if($_SESSION['music']=='chilling'){
            echo '<source src="music/lofi_genre.mp3" type="audio/mpeg">';
        }
    }
    ?>   
    </audio>
    <br>
    <form method="POST">
    <?php
        //question count and question answer manager
        if($_SESSION['ques_count'] < count($_SESSION['question_list'])){
            if(isset($_POST['end_q'])){
                // setting $_SESSION['current_answer'] --> $current_answer to update answer list
                if($_SESSION['question_type'][$_SESSION['ques_count']]=='SUB'){
                    $current_answer=$_POST['current'];
                    $_SESSION['current_answer']=$current_answer;
                    $_SESSION['current_answer_list'][$_SESSION['ques_count']]= $_SESSION['current_answer'];
                    $_SESSION['current_answer']="";
                }
                else if($_SESSION['question_type'][$_SESSION['ques_count']]=='OBJ'){
                    if($_SESSION['current_answer'] != ""){
                        $_SESSION['current_answer_list'][$_SESSION['ques_count']]= $_SESSION['current_answer'];
                        $_SESSION['current_answer']="";
                        $_SESSION['obj_count']=0;
                    }else{
                        $_SESSION['current_answer']="";
                        array_push($_SESSION['cust'],$_SESSION['current_answer']);
                        $_SESSION['current_answer_list'][$_SESSION['ques_count']]= $_SESSION['current_answer'];
                        $_SESSION['obj_count']=0;
                    }   
                }
                $_SESSION['time_used']=abs($_SESSION['timer'] - time());
                header("Location:../jom_coding/action_quiz_end.php");
                exit();
            }else if(isset($_POST['next_q'])){
                // setting  $_SESSION['current_answer'] --> $current_answer to update answer list
                if($_SESSION['ques_count']<count($_SESSION['question_list'])-1){
                    if($_SESSION['question_type'][$_SESSION['ques_count']]=='SUB'){
                        $current_answer=$_POST['current'];
                        $_SESSION['current_answer']=$current_answer;
                        $_SESSION['current_answer_list'][$_SESSION['ques_count']]=$_SESSION['current_answer'];
                        $_SESSION['current_answer']="";
                    }
                    else if($_SESSION['question_type'][$_SESSION['ques_count']]=='OBJ'){
                        if($_SESSION['current_answer'] !=""){
                            $_SESSION['current_answer_list'][$_SESSION['ques_count']]=$_SESSION['current_answer'];
                            $_SESSION['current_answer']="";
                            $_SESSION['obj_count']=0;
                        }else{
                            $_SESSION['current_answer']="";
                            $_SESSION['current_answer_list'][$_SESSION['ques_count']]= $_SESSION['current_answer'];
                            $_SESSION['obj_count']=0;
                        }           
                    }
                    $_SESSION['ques_count']=$_SESSION['ques_count']+1;
                    $_SESSION['count_down_sec']=$_SESSION['question_time_limit'][$_SESSION['ques_count']];
                }
            }
        }
    ?>
    <nav>
        <ul style="list-style: none;">
            <?php 
            if($_SESSION['toggle-music']){
                $color="#47c92a";
            }else{
                $color="#c93d2a";
            }
            ?>
            <li><a href="content_quiz.php?page=1" style="text-decoration:none;" class="btn_quit">QUIT</a></li>
            <li class="help_logo" style="transform:scale(1.3);position:relative;top:-20px;left:1100px;"><a href="content_faq.php" target="_blank"><img src="image/help.png"></a></li>
            <li><center><i id="toggle_music" class="fa fa-music music_button" style="background-color:<?php echo $color;?>;color:white;font-size:1.5rem;position:relative;left:950px;"></i></center></li>
        </ul>
        <script>
            // play or stop music
            var music_button=document.getElementById("toggle_music");
            var music=document.getElementById("quizAudio");
            var music_state=0;
            music.play();
            music_button.onclick=function(){
                if(music_state==0){
                    music.play();
                    music_state=1;
                    music_button.style.backgroundColor="#47c92a";
                }else if(music_state==1){
                    music.pause();
                    music_state=0;
                    music_button.style.backgroundColor="#c93d2a";
                }

            }
            
        </script>
    </nav>
    <br>
    <center>
    <div class="question_content">
        <span class="pointerboard"><img src="image/point.png">    <span><?php echo $_SESSION['ques_count']+1;?></span>/<span><?php echo count($_SESSION['question_list']);?></span></span>
        <br>
    <div>
        <?php
            // objective question manager
            function show_obj_option($list,$num){
                $objform=preg_split("/-/",$list[$num]);
                $obj_count=0;
                foreach($objform as $obj){
                    $obj_count+=1;
                    // content_quizizz.php?current=***&obj_count=***
                    echo "<li style='display:inline; margin-right:50px;'><a id='answer_op' style='text-decoration: none; color:white;' class='btn_answer' href='action_choose_obj.php?current=".$obj."&obj_count=".$obj_count."'>".$obj."</a></li>";
                }
            }
            // show question
            echo $_SESSION['question_list'][$_SESSION['ques_count']];
            if($_SESSION['question_picture'][$_SESSION['ques_count']]!='-'){
                echo '<br><img id="question_picture" style="margin-right:10px;" class="picture" src="question_photo/'.$_SESSION['question_picture'][$_SESSION['ques_count']].'">';
                // popup that zoom's in to the question picture 
                echo 
                '
                <div class="modal" id="error_window" style="display:none;">
                    <div class="modal-content">
                        <div class="row" style="background-color:#1c1c1c;width:598px;margin-left:0px;">
                            <div class="col-sm-11"><span style="margin-left:50px;">PICTURE</span></div>
                            <div class="col-sm-1"><i style="color:white;" id="close" class="fas fa-compress-arrows-alt"></i></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-2" style="height:600px;"></div>
                            <div class="col-sm-8" style="height:600px;"><img style="margin-left:-100px;height:600px;width:600px;" class="picture" src="question_photo/'.$_SESSION['question_picture'][$_SESSION['ques_count']].'"></div>
                            <div class="col-sm-2" style="height:600px;"></div>
                        </div>
                        
                    </div>
                </div>
                <script>
                    var pic=document.getElementById("question_picture");
                    var modal = document.getElementById("error_window");
                    var close = document.getElementById("close");
                    close.onclick = function() {
                    modal.style.display = "none";
                    }
                    window.onclick = function(event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                    }
                    pic.onclick=function(){
                        modal.style.display="block";
                    }
                </script>
                ';
            }
            echo "<br><br>";
            // question type manager
            if($_SESSION['question_type'][$_SESSION['ques_count']]=='SUB'){
                echo "<input autocomplete='off' style='border-radius:25px;padding:20px;border:none;outline:none;' name='current'/>";
            } 
            else if($_SESSION['question_type'][$_SESSION['ques_count']]=='OBJ'){
                echo "<ul style='list-style:none;'>";
                show_obj_option($_SESSION['question_select'],$_SESSION['ques_count']);
                echo "</ul>"; 
                // adding 'active' class to the selected answer
                if(!empty($_SESSION['obj_count'])){
                echo "<script>
                var btns=document.getElementsByClassName('btn_answer');
                btns[".(int)($_SESSION['obj_count']-1)."].className +=' active';
                </script>";
                }
            }
        ?>
    </div>     
    </div>
    </center>
    <br><br>
    <ul class="btn_que" style="list-style:none;">
        <li>
            <div id="countdown_img" style="margin-top:20px;background-image:url('image/time_4.png');height:102px;width:102px;background-position: center; background-repeat: no-repeat;background-size: cover;">
                <center><span id="countdown_sec"style="color:white;font-size:4.2rem;"><?php echo $_SESSION['count_down_sec'];?></span></center>
            </div> 
        </li>
        <?php 
            // last question: next->end
            if($_SESSION['ques_count']<count($_SESSION['question_list'])-1){
                echo "<li style='margin-left:950px;'><button id='btn_next' class='buttonz' type='submit' name='next_q'><span style='font-size:1.7rem;'><i class='fas fa-arrow-right'></i> Submit</span></button></li>";
            }else{
                echo "<li style='margin-left:950px;'><button class='buttonz' id='btn_next' type='submit' name='end_q'><span style='font-size:1.7rem;'><i class='fa fa-hourglass-end'></i> End</span></button></li>";
            }
        ?>
         <script>
                var img=document.getElementById("countdown_img");
                var countdown_sec=document.getElementById("countdown_sec");
                var btn_next=document.getElementById("btn_next");
                function count(){
                    // update timer via ajax request
                    var sec=countdown_sec.innerHTML;
                    var num=Math.ceil(sec/<?php $quarter_time=(int)$_SESSION['question_time_limit'][$_SESSION['ques_count']];echo $quarter_time/4;?>);
                    countdown_img.style.backgroundImage="url('image/time_"+num+".png')";
                    countdown_sec.innerHTML=sec-1;
                    var request=new XMLHttpRequest();
                    var url="action_add_sec.php";
                    request.open("POST",url,true);
                    request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                    var $POST="timeout=1";
                    request.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        var timeout = this.responseText;
                        if(timeout=="1"){
                            // time out will result in auto-click for next question
                            btn_next.click();
                        }    
                    }
                    };
                    request.send($POST);
                   
                    
                }
                setInterval(count,1000);
        </script>
    </ul>
    </form>
</div>

