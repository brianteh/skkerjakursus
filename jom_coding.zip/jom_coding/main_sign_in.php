<br><br>
<div class="sign_in_style row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8 sign_up_content">
                <br><br>
                <!--FORM FOR SIGN IN-->
                <form class="sign_in_form" action="action_sign_in2.php" method="POST">
                        <div class="row">    
                                <div class="col-sm-3"><b>Username:</b></div><label></label>
                                <div class="col-sm-9"><input class="fieldz" name="uid" type="text" required/></div>
                        </div>
                        <br><br>
                        <div class="row">
                                <div class="col-sm-3"><label><b>Password:</b></label></div>
                                <div class="col-sm-9"><input class="fieldz" name="password" type="password" required/></div>
                        </div>
                        <br><br>
                        <button style="width:140px;" name="sign_in_btn" type="submit"><i class="fa fa-arrow-circle-o-right"></i>  
                                <b>Sign In</b>
                        </button>
                </form>
                <br><br>
        </div>
        <div class="col-sm-2"></div>
</div>

