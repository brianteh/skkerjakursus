<?php
session_start();
// music on or off
$setting_op=$_POST["settings"];
if($setting_op=="music-off"){
    $_SESSION['toggle-music']=false;
}else if($setting_op=="music-on"){
    $_SESSION['toggle-music']=true;
}