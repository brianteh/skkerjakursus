<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physics Made Easy</title>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/2ded180867.js" crossorigin="anonymous"></script>
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link type="text/css" rel ="stylesheet" href="css/sign_form.css">
    <link type="text/css" rel ="stylesheet" href="css/quiz_form.css">
    <link type="text/css" rel ="stylesheet" href="css/structure.css">
    <link rel="icon" type="image/png" href="image/logo16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="image/logocon32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="image/logocon64x64.png" sizes="64x64">
    <link rel="icon" type="image/png" href="image/logocon96x96.png" sizes="96x96">
    
    <style>
        main{
            background-image:url('image/background6.png');
            height:1080px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .rocket{
            transform: scale(0.4);
            margin-left: 200px;
        }
        .rocket:hover{
            animation:travel 3s;
            transition:3s ease;
        }
        @keyframes travel{
            10%{
                transform: scale(0.4);
                transform:translateX(0%);
            }
            100%{
                transform: scale(0.4);
                transform:translateX(1000%);
            }
        }
    </style>
<body>
    <div class="bg_img">
    <center><a href="content_home.php"><img src="image/physics.jpg" ></a></center>
    </div>
   
    
 
    <div class="menu_item">
        <ul style="list-style: none;" >
            <li><a class="tabz" id="home_tab" style="text-decoration:none;" href="content_home.php"><i class="fas fa-home color_icon"></i> Home</a></li>
            <li><a class="tabz" id="quiz_tab" style="text-decoration:none;" href="content_quiz.php"><i class="fas fa-book color_icon"></i> Quiz</a></li>
            <li><a class="tabz" id="su_tab" style="text-decoration:none;" href="content_sign_up.php"><i class="fas fa-user-alt color_icon"></i> Sign up</a></li>
            
            <?php 
            // if not login(no menu tab), else (has menu tab)
            if($_SESSION['page_type'] !="none"){
                echo "<script>
                var cur_act=document.getElementsByClassName('tabz');
                cur_act[".$_SESSION['page_type']."].className='tabz active_tab';
                </script>";
            }
            else if($_SESSION['page_type']==0){
                echo "<script>
                var cur_act=document.getElementsByClassName('tabz');
                cur_act[".$_SESSION['page_type']."].className='tabz active_tab';
                </script>";
            }
            if($_SESSION['log_status']==0){
                echo '<li><a class="tab" style="text-decoration:none;" href="content_sign_in.php"><i class="fas fa-sign-in-alt color_icon"></i> Log in</a></li>';
            }
            else if($_SESSION['log_status']==1){
                echo '<li><a class="tab" style="text-decoration:none;" href="action_sign_out.php"><i class="fas fa-sign-out-alt color_icon"></i> Log out</a></li>';
                if($_SESSION['acc_status']=='admin'){
                    echo '
                        <img class="profile_picture" style="border-radius:50%;" src="user_photo/'.$_SESSION['profile_pic'].'"> <span class="username" style="font-size:0.8rem;">'.$_SESSION['username'].'</span>
                        <div class="dropdown">
                        <i class="fas fa-bars menubar dropbtn" onclick="myFunction()" title="Menu Bar" style="margin-left:10px;"></i>
                        <div id="myDropdown" class="dropdown-content" style="margin-left:10px;margin-top:33px;">
                            <a href="content_profile.php"><i class="fas fa-user-cog"></i> Profile</a>
                            <a href="content_admin_quiz.php" target="blank"><i class="fas fa-user-edit"></i> Admin</a>
                            <a href="content_settings.php"><i class="fa fa-cog"></i> Settings</a>
                        </div>
                        </div>
                        <script>
                            function myFunction() {
                                document.getElementById("myDropdown").classList.toggle("show");
                            }
                            window.onclick = function(event) {
                                if (!event.target.matches(".dropbtn")) {
                                    var dropdowns = document.getElementsByClassName("dropdown-content");
                                    var i;
                                    for (i = 0; i < dropdowns.length; i++) {
                                        var openDropdown = dropdowns[i];
                                        if (openDropdown.classList.contains("show")) {
                                            openDropdown.classList.remove("show");
                                        }
                                    }
                                }
                            }
                        </script>';
                }else if($_SESSION['acc_status']=='user'){
                    echo '
                        <img class="profile_picture" src="user_photo/'.$_SESSION['profile_pic'].'"> <span class="username" style="font-size:0.8rem;">'.$_SESSION['username'].'</span>
                        <div class="dropdown">
                        <i class="fas fa-bars menubar dropbtn" onclick="myFunction()" title="Menu Bar" style="margin-left:10px;"></i>
                        <div id="myDropdown" class="dropdown-content" style="margin-left:10px;margin-top:33px;">
                            <a href="content_profile.php"><i class="fas fa-user-cog"></i> Profile</a>
                            <a href="content_settings.php"><i class="fa fa-cog"></i> Settings</a>
                        </div>
                        </div>
                        <script>
                            function myFunction() {
                                document.getElementById("myDropdown").classList.toggle("show");
                            }
                            window.onclick = function(event) {
                                if (!event.target.matches(".dropbtn")) {
                                    var dropdowns = document.getElementsByClassName("dropdown-content");
                                    var i;
                                    for (i = 0; i < dropdowns.length; i++) {
                                        var openDropdown = dropdowns[i];
                                        if (openDropdown.classList.contains("show")) {
                                            openDropdown.classList.remove("show");
                                        }
                                    }
                                }
                            }
                        </script>';
                }
            }
            
           
            
            ?>
        </ul>
           
    </div>
           

        
  