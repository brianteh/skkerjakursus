<div class="row head_admin" style="position:fixed;width:100%;z-index:1000;">
    <div class="col-sm-1"><center><a href="content_home.php"><img class="logo" src="image/physics.jpg" autofocus="off"></a></center></div>
    <div class="col-sm-8"></div>
    <div class="col-sm-2" style="margin-top:10px;"><center><input id="search_field" class="search_field" type="text" placeholder="Type in any keywords"></center></div>
    <div class="col-sm-1" style="margin-top:10px;"><button id="search_btn" class="search_btn">Search</button></div>
</div>
<script src="js/filterfaq.js"></script>