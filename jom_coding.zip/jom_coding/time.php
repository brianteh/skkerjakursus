<?php
// process time for further usage
$current_time=getdate();
$time_stamp=(int)$current_time['hours'];
$time_stamp=$time_stamp+7;
$time_stamp=$time_stamp%24;
if($time_stamp<10){
  $time_stamp=(string)$time_stamp;
  $time_stamp="0".$time_stamp.":00:00";
}else{
  $time_stamp=(string)$time_stamp;
  $time_stamp=$time_stamp.":00:00";
}


$_SESSION['current_time']=$time_stamp;
$_SESSION['time_list']=[];
if (($time_file = fopen("calendar/time.csv", "r")) !== FALSE) 
{
  while (($hour = fgetcsv($time_file, 1000, ",")) !== FALSE) 
  {
    $_SESSION['time_list'][]=$hour;		
  }
  fclose($time_file);
}
?>